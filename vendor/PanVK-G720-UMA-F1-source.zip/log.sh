adb pull "$(adb shell ls /sdcard/Winlator/logs/* -t | head -1)" winlator_log.txt
adb pull "$(adb shell ls /sdcard/wrapper/logs/* -t | head -1)" wrapper_log.txt
