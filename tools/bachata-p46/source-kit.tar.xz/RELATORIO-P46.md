# Relatório P46 — Integração BCn privada (read-only)

**Data:** 2026-10-17

### Evidência executada
- P42 SHA256: `5f137e2111f86758ae386aa258cf401f276572cfd08aea947a64c1a22cc5570a`.
- Host privado P42: 75.323.616 bytes; SHA256 `5eee7ec0643bcc80addac60b2cb08b203eac0edcaaf2ac1b11219c8630e6e002`.
- Seção `.text` privada P42 SHA256 `f71b3ac83bb350f7de2835e3f4037b9d95d3fc080f1d9781e2271549f7964157`.
- P42 assinatura Android v2, 12 referências de certificado (1 Bionic + 11 GLIBC), 397 arquivos de runtime: **PASS** no gate P42.
- P31 substituído detectado via hash: não pode ser confundido com o host funcional.
- 10 testes Python locais sobre P42/P23/P31 e falhas sintéticas: **PASS**.
- 10 testes C++ para o caso BC3 sRGB 1024×1024 11 mipmaps: **PASS** em GCC e Clang ASan/UBSan.
- Contexto do erro real: `image_view.cpp:257` e mensagem `GPU BCn decoded image requires a matching sampled BC view` após fallback BC3 sRGB. Não houve prova de cópia GPU finalizada no log.

### Distinções obrigatórias
- P45 compilou no **core público**, sem provar execução no **GLIBC privado**.
- O executável privado está stripped e não contém uma implementação P45 comprovada.
- A referência de fonte `bachata-s4` também aparece na P31 pública; **não serve para provar identidade do host**.
- Testes C++ sintéticos validam regras de admissão, **não o comportamento do Vulkan em hardware**.

### Release gate
`BLOCKED_PRIVATE_GLIBC_BCN_PATCH_NOT_VERIFIED`.

**Novo APK:** NÃO. **P42 preservada:** SIM. **Outlast:** ainda não homologado. Para avançar, precisamos do **fonte privado F43DEV correspondente ao executável P42** ou de outra interface de integração comprovadamente equivalente.
