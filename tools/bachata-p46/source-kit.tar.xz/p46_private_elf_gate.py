#!/usr/bin/env python3
"""P46: fail-closed PRIVATE F43DEV BCn ABI/source release gate (source-only).

Do not treat a modified Android lib, a public shadPS4 ELF, or an assertion NOP
as a proof that the private GLIBC rendering path was fixed.

Read-only; never patches the APK or private ELF; only emits public-safe hashes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile

PRIVATE_ELF_PATH = 'host/shadps4-arm64-fex'
RUNTIME_PATH = 'assets/runtime/runtime.zip'
EXPECTED_P42_APK_SHA256 = '5f137e2111f86758ae386aa258cf401f276572cfd08aea947a64c1a22cc5570a'
EXPECTED_P42_PRIVATE_ELF_SHA256 = '5eee7ec0643bcc80addac60b2cb08b203eac0edcaaf2ac1b11219c8630e6e002'
EXPECTED_P42_PRIVATE_TEXT_SHA256 = 'f71b3ac83bb350f7de2835e3f4037b9d95d3fc080f1d9781e2271549f7964157'
OLD_BCN_ASSERT = b'GPU BCn decoded image requires a matching sampled BC view'
PRIVATE_SOURCE_SIGNATURE = b'/usr/src/bachata-s4/src/video_core/texture_cache/image_view.cpp'
KNOWN_P31_PUBLIC_ELF_SHA256 = '3906bd2db94e17afa236ad04bc48a06910f74208b6a547e6833a6040cc957902'
P45_STRINGS = (b'P45_BCN_LAYER_PROOF', b'P45 sampled BCn RGBA view rejected')
SOURCE_FILES = (
    'src/video_core/texture_cache/image.cpp',
    'src/video_core/texture_cache/image_view.cpp',
    'src/video_core/texture_cache/texture_cache.cpp',
    'src/video_core/texture_cache/tile_manager.cpp',
)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def elf_text(data):
    if len(data) < 64 or data[:4] != b'\x7fELF' or data[4:7] != b'\x02\x01\x01':
        raise ValueError('NOT_ELF64_LE')
    if struct.unpack_from('<H', data, 18)[0] != 183:
        raise ValueError('NOT_AARCH64')
    shoff = struct.unpack_from('<Q', data, 40)[0]
    shentsize, shnum, shstr = struct.unpack_from('<HHH', data, 58)
    if not shentsize or not shnum or shnum > 4096 or shentsize < 64 or shstr >= shnum or shoff + shnum*shentsize > len(data):
        raise ValueError('ELF_SECTION_TABLE_INVALID')
    def section(i):
        pos=shoff+i*shentsize
        return struct.unpack_from('<IIQQQQIIQQ',data,pos)
    string_sec=section(shstr)
    soff, ssize=string_sec[4],string_sec[5]
    if soff + ssize > len(data):raise ValueError('ELF_SHSTRTAB_INVALID')
    strings=data[soff:soff+ssize]
    for i in range(shnum):
        s=section(i)
        name_off=s[0]
        if name_off < len(strings) and strings[name_off:].split(b'\0',1)[0]==b'.text':
            off, size=s[4],s[5]
            if not size or off+size>len(data):raise ValueError('ELF_TEXT_INVALID')
            return data[off:off+size]
    raise ValueError('ELF_TEXT_MISSING')

def source_readiness(root):
    if root is None:
        return {'source_available':False,'source_anchor_count':0,'release_gate':'BLOCKED_PRIVATE_SOURCE_UNAVAILABLE'}
    root=Path(root)
    present=[f for f in SOURCE_FILES if (root/f).is_file()]
    if len(present) != len(SOURCE_FILES):
        return {'source_available':False,'present_files':present,'required_files':list(SOURCE_FILES),
                'release_gate':'BLOCKED_PRIVATE_SOURCE_INCOMPLETE'}
    # Presence of files alone cannot prove implementation or compatibility.
    return {'source_available':True,'present_files':present,'release_gate':'BLOCKED_PRIVATE_REBUILD_AND_HARDWARE_VALIDATION_REQUIRED'}

def analyze(apk, private_source=None):
    apk=Path(apk)
    with zipfile.ZipFile(apk) as app:
        if RUNTIME_PATH not in app.namelist():raise ValueError('APK_MISSING_RUNTIME_ZIP')
        with app.open(RUNTIME_PATH) as stream:
            with zipfile.ZipFile(stream) as runtime:
                if PRIVATE_ELF_PATH not in runtime.namelist():raise ValueError('RUNTIME_PRIVATE_ELF_MISSING')
                data=runtime.read(PRIVATE_ELF_PATH)
    txt=elf_text(data)
    elfhash,texthash=sha(data),sha(txt)
    original=elfhash==EXPECTED_P42_PRIVATE_ELF_SHA256
    private_source_status=source_readiness(private_source)
    return {
        'schema':'P46_F43DEV_PRIVATE_BCN_SOURCE_GATE_V1',
        'input_apk_sha256':sha(apk.read_bytes()),
        'runtime_elf_name':PRIVATE_ELF_PATH,
        'architecture':'AArch64-GLIBC',
        'elf_size':len(data),
        'elf_sha256':elfhash,
        'elf_text_sha256':texthash,
        'same_private_executable_as_functional_P42':original,
        'same_private_text_as_P42':texthash==EXPECTED_P42_PRIVATE_TEXT_SHA256,
        'old_imageview_assert_present':data.count(OLD_BCN_ASSERT)==1,
        'bachata_s4_source_path_seen_not_identity_proof':PRIVATE_SOURCE_SIGNATURE in data,
        'known_public_P31_substitution_detected':elfhash==KNOWN_P31_PUBLIC_ELF_SHA256,
        'public_p45_log_strings_present':[x.decode() for x in P45_STRINGS if x in data],
        'private_source':private_source_status,
        'p45_private_core_integrated_and_proven':False,
        'apk_bc_imageview_fix_hardware_verified':False,
        'release_gate':'BLOCKED_PRIVATE_GLIBC_BCN_PATCH_NOT_VERIFIED',
        'note':'An ELF text change or string/marker does not prove the P45 GPU upload ledger, fence completion or valid Vulkan sampled views.',
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--apk',required=True)
    ap.add_argument('--private-source')
    ap.add_argument('--out',required=True)
    ap.add_argument('--allow-blocked-report',action='store_true',help='Research only: allow exit 0 for known blocked candidate; does NOT authorize APK shipping')
    args=ap.parse_args()
    result=analyze(args.apk,args.private_source)
    Path(args.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['release_gate'])
    if not args.allow_blocked_report:raise SystemExit(3)

if __name__=='__main__':main()
