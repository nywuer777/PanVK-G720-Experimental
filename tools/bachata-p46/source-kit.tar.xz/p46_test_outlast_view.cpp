#include "p44_bcn_imageview_contract.hpp"
#include <array>
#include <iostream>
using namespace BachataP44;
static int passed=0;
void expect(bool v,const char* msg){if(!v){std::cerr<<"FAILED "<<msg<<'\n';std::exit(3);}++passed;}
int main(){
 constexpr unsigned mips=11;
 std::array<CompletedUpload,mips> proof{};
 for(unsigned mip=0;mip<mips;++mip){proof[mip]={
  .mip=mip,.layer=0,.width=MipDim(1024,mip),.height=MipDim(1024,mip),
  .generation=44,.completion_generation=44,.content_epoch=9,
  .decoded_format=Format::Rgba8Srgb,.decoder_succeeded=true,
  .guest_layout_verified=true,.gpu_copy_submitted=true,.gpu_fence_completed=true,
  .color_aspect_verified=true
 };}
 Request r{.guest=Format::Bc3Srgb,.allocated_backing=Format::Rgba8Srgb,
  .sampled=true,.storage=false,.depth=false,.color_aspect=true,
  .sampled_feature=true,.view_format_feature=true,
  .mutable_format=false,.compatible_mutation=true,.guest_is_tiled=true,
  .width=1024,.height=1024,.allocated_mips=mips,.allocated_layers=1,.samples=1,
  .base_mip=0,.mip_count=mips,.base_layer=0,.layer_count=1,
  .generation=44,.current_content_epoch=9,
  .uploads=proof.data(),.upload_count=proof.size()};
 expect(Resolve(r).verdict==Verdict::VerifiedDecodedRgbaView,"11 mip BC3 sRGB completed upload");
 proof[10].gpu_fence_completed=false;
 expect(Resolve(r).verdict==Verdict::RejectStaleUpload,"last mip unfinished GPU fence");
 proof[10].gpu_fence_completed=true;
 proof[10].content_epoch=8;
 expect(Resolve(r).verdict==Verdict::RejectDirtyAfterUpload,"outdated mip content epoch");
 proof[10].content_epoch=9;
 proof[10].decoder_succeeded=false;
 expect(Resolve(r).verdict==Verdict::RejectMissingUpload,"decoder failed on last mip");
 proof[10].decoder_succeeded=true;
 r.allocated_backing=Format::Rgba8Unorm;
 expect(Resolve(r).verdict==Verdict::RejectMutableFormat,"sRGB view must match actual backing");
 r.allocated_backing=Format::Rgba8Srgb;
 r.upload_count=10;
 expect(Resolve(r).verdict==Verdict::RejectMissingUpload,"missing final mip");
 r.upload_count=11;
 r.generation=0;
 expect(Resolve(r).verdict==Verdict::RejectMissingUpload,"missing generation");
 r.generation=44;
 r.storage=true;
 expect(Resolve(r).verdict==Verdict::RejectStorageOrDepth,"storage image rejected");
 r.storage=false;
 proof[3].layer=1;
 expect(Resolve(r).verdict==Verdict::RejectMissingUpload,"incorrect mip layer");
 proof[3].layer=0;
 r.current_content_epoch=0;
 expect(Resolve(r).verdict==Verdict::RejectDirtyAfterUpload,"unknown content epoch");
 std::cout << "P46_OUTLAST_BC3_SRGB_1024_11MIP_CONTRACT_PASS checks="<<passed<<"\n";
}
