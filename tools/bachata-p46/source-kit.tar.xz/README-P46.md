# P46 — Ponte segura BCn do core público para o GLIBC privado F43DEV

**Estado:** análise material + gate *fail closed*, ainda **sem patch binário privado** e **sem APK corrigido do Outlast**.

P42 é a base Android validada pelo usuário. P44/P45 foram testadas e compiladas **somente no core público**, que não atende automaticamente ao protocolo de inicialização privado F43DEV. Este kit torna explícito o que falta para integrar a correção sem repetir a regressão do P31.

## Constatações materiais

1. O host privado `assets/runtime/runtime.zip::host/shadps4-arm64-fex` da P42 tem **75.323.616 bytes**, ELF64 AArch64/GLIBC, é `stripped`, e contém uma mensagem de erro exclusiva do ramo BCn de `image_view.cpp:257`.
2. O SHA-256 de `.text` é `f71b3ac83bb350f7de2835e3f4037b9d95d3fc080f1d9781e2271549f7964157`, igual à versão original P42. Não há código P45 comprovado ali.
3. O P31 público também contém referência ao caminho de fonte `bachata-s4`, portanto **essa string não identifica o core privado**. A substituição P31 é detectada pelo SHA distinto e permanece barrada.
4. No relatório do Outlast, o último recurso antes do `assert` foi **BC3 sRGB, 1024×1024, 11 níveis**, backing indicado como `R8G8B8A8Srgb`. Não existe, no log, prova per-(mip,layer) de conclusão do upload e de `vkCreateImageView` com o formato certo.

## Como integrar no código-fonte privado

A implementação real exige modificar o **mesmo commit privado que gerou o GLIBC P42**:

1. `src/video_core/texture_cache/image.cpp`: escolher backing RGBA8 coerente UNORM/sRGB, sem alterar a semântica do formato guest BCn.
2. `src/video_core/texture_cache/tile_manager.cpp`: decodificar os blocos segundo a disposição linear/tiled real, com dimensão, pitch, mip e layer verificados. **Não aceitar apenas a seleção do fallback como prova de decode**.
3. `src/video_core/texture_cache/texture_cache.cpp`: controlar regiões completas `(mip,layer)`, invalidar prova após escritas/alias, e só marcar conclusão após a fence da cópia Vulkan verdadeira.
4. `src/video_core/texture_cache/image_view.cpp`: consultar o contrato P44 antes de `vkCreateImageView`; para backing RGBA escolher a view `R8G8B8A8Unorm/Srgb` realmente compatível, mantendo `asserts` para estados inválidos.
5. Preservar protocolos F43DEV V2, FEX/SAF e verificações de certificado do host P42, recompilar o GLIBC privado, construir o APK com a assinatura experimental autorizada e executar o gate de identidade P42. Só liberar para instalação após esses passos e testes de execução.

A localização desses quatro arquivos **não garante que as assinaturas/funções privadas coincidam com o core público**. A portabilidade deve ser validada na árvore privada compilável. Sem ela, não existe alteração segura do executável stripped que represente o ledger P45.

## Teste e gates

```bash
python3 p46_private_elf_gate.py --apk /caminho/P42.apk --out p46-report.json --allow-blocked-report
python3 -m unittest -v test_p46_portable.py
c++ -std=c++20 -O2 -Wall -Wextra -Werror -I. p46_test_outlast_view.cpp -o test-outlast && ./test-outlast
```

Na verificação real, rodar também o `host_identity_release_gate.py` do P42, exigindo `PASS_HOST_IDENTITY_STATIC_RELEASE_GATE`. O comando sem `--allow-blocked-report` retorna erro deliberadamente enquanto a integração privada não for comprovada; esta opção apenas permite salvar o relatório de pesquisa.

**NÃO INCLUIR:** chave de assinatura, dados de jogos, tokens SAF, arquivos privados ELF ou dump de memória no repositório público. **NÃO DESATIVAR:** verificações de ImageView/robust image, identidade F43DEV ou diagnóstico Vulkan.
