"""P46 source-only CI regression, no private APK or F43DEV binary uploaded."""
import pathlib,sys,tempfile,unittest,struct
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from p46_private_elf_gate import elf_text,source_readiness,SOURCE_FILES
class PortableGate(unittest.TestCase):
 def test_no_source(self):self.assertEqual(source_readiness(None)['release_gate'],'BLOCKED_PRIVATE_SOURCE_UNAVAILABLE')
 def test_partial_source(self):
  with tempfile.TemporaryDirectory() as d:
   f=pathlib.Path(d)/SOURCE_FILES[0];f.parent.mkdir(parents=True);f.write_text('mock')
   self.assertEqual(source_readiness(d)['release_gate'],'BLOCKED_PRIVATE_SOURCE_INCOMPLETE')
 def test_all_source_not_enough_for_release(self):
  with tempfile.TemporaryDirectory() as d:
   for name in SOURCE_FILES:
    f=pathlib.Path(d)/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('mock')
   self.assertEqual(source_readiness(d)['release_gate'],'BLOCKED_PRIVATE_REBUILD_AND_HARDWARE_VALIDATION_REQUIRED')
 def test_broken_elf(self):
  with self.assertRaisesRegex(ValueError,'NOT_ELF64_LE'):elf_text(b'hello')
 def test_other_arch_elf(self):
  d=bytearray(64);d[:7]=b'\x7fELF\x02\x01\x01';struct.pack_into('<H',d,18,62)
  with self.assertRaisesRegex(ValueError,'NOT_AARCH64'):elf_text(d)
 def test_invalid_elf_sections(self):
  d=bytearray(64);d[:7]=b'\x7fELF\x02\x01\x01';struct.pack_into('<H',d,18,183)
  with self.assertRaisesRegex(ValueError,'ELF_SECTION_TABLE_INVALID'):elf_text(d)
if __name__=='__main__':unittest.main()
