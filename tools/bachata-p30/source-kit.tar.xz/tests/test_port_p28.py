import unittest, tempfile, sys, subprocess, json, hashlib
from pathlib import Path
ROOT=Path(__file__).parents[1]/'source'
sys.path.insert(0,str(ROOT))
import port_renderer_p25 as p25
import port_renderer_p27 as p27
import port_renderer_p28 as p28

class PortP28(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.f={
    'src/video_core/texture_cache/image.h': '#pragma once\n'+p25.OLD_IMAGE_HEADER+'\n    void Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer, u64 offset);\n',
    'src/video_core/texture_cache/image_view.cpp': '#include "video_core/texture_cache/image.h"\n'+p25.OLD_VIEW_HEAD+'\n',
    'src/video_core/renderer_vulkan/vk_rasterizer.cpp': '#include <array>\n'+p25.OLD_RASTER_ANCHOR+'\n',
    'src/video_core/texture_cache/image.cpp': '''void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,
                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {}
void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,
                   u64 offset) {
    SetBackingSamples(info.num_samples, false);
        .size = info.guest_size,
        .size = info.guest_size,
}
void Image::Download(xxx) {}
''',
    'CMakeLists.txt': '               src/video_core/renderer_vulkan/vk_rasterizer.cpp\n'
  }
 def test_transform(self):
  self.assertEqual(len(p28.transform(self.f)),5)
 def test_async_cmake(self):
  self.assertIn('p28_vk_async_upload.cpp',p28.transform(self.f)['CMakeLists.txt'])
 def test_blocking_p27_unmodified(self):
  c=p28.transform(self.f)['CMakeLists.txt']
  self.assertIn('p27_vk_decoded_upload.cpp',c)
 def test_pin(self):self.assertEqual(p25.EXPECTED_UPSTREAM,'be6bc2e9c60799e071dd2fafa6216e8d80ec619c')
 def test_new_files(self):
  for f in p28.P28_FILES:self.assertTrue((ROOT/f).exists(),f)
 def test_unique_anchor(self):
  bad=dict(self.f);bad['CMakeLists.txt']*=2
  with self.assertRaises(ValueError):p28.transform(bad)
 def test_reapplying(self):
  with self.assertRaises(ValueError):p28.transform(p28.transform(self.f))
 def test_source_not_mutated(self):
  data=dict(self.f);p28.transform(data);self.assertEqual(data,self.f)
 def test_no_disable_assert(self):
  source='\n'.join((ROOT/f).read_text() for f in p28.P28_FILES)
  self.assertNotIn('NDEBUG',source)
  self.assertNotIn('abort_bypass',source)
 def test_no_wait(self):
  s=(ROOT/'p28_vk_async_upload.cpp').read_text()
  self.assertNotIn('scheduler.Finish(',s)
  self.assertNotIn('scheduler.Flush(',s)
  self.assertIn('scheduler.IsFree(',s)
  self.assertIn('scheduler.CurrentTick()',s)
 def test_staging_lifetime(self):
  s=(ROOT/'p28_vk_async_upload.cpp').read_text()
  self.assertIn('staging.use_count()!=1',s)
  self.assertIn('scheduler.DeferOperation([keep_alive=std::move(staging)]()',s)
 def test_generation(self):
  s=(ROOT/'p28_vk_async_upload.cpp').read_text()
  self.assertIn('generation<=journal.generation',s)
  self.assertIn('journal.state==BachataP26::UploadJournal::State::UploadSubmitted',s)
 def test_format(self):
  s=(ROOT/'p28_vk_async_upload.cpp').read_text()
  self.assertIn('ci.format!=rgba',s)
  self.assertIn('ci.imageType!=vk::ImageType::e2D',s)
 def test_not_attest_before_gpu(self):
  s=(ROOT/'p28_vk_async_upload.cpp').read_text()
  self.assertIn('submitted && scheduler.IsFree(ticket.timeline_tick)',s)
  self.assertIn('completed_after_gpu_fence(',s)
 def test_privacy(self):
  s='\n'.join((ROOT/f).read_text() for f in p28.P28_FILES)
  for phrase in ['--bachata-saf-token','runtime-control.sock','--bachata-contract']:
   self.assertNotIn(phrase,s)
 def test_cli_write(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   for rel,txt in self.f.items():
    path=root/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(txt)
   cmd=[sys.executable,str(ROOT/'port_renderer_p28.py'),'--source-root',str(root),
        '--out',str(root/'a.diff'),'--synthetic-fixture']
   a=subprocess.run(cmd,capture_output=True,text=True)
   self.assertEqual(a.returncode,0,a.stderr)
   self.assertFalse(json.loads(a.stdout)['full_core_compiled'])
   self.assertEqual((root/'CMakeLists.txt').read_text(),self.f['CMakeLists.txt'])
   b=subprocess.run(cmd+['--write'],capture_output=True,text=True)
   self.assertEqual(b.returncode,0,b.stderr)
   self.assertTrue((root/'src/video_core/renderer_vulkan/p28_vk_async_upload.cpp').exists())
   c=subprocess.run(cmd+['--write'],capture_output=True,text=True)
   self.assertNotEqual(c.returncode,0)
if __name__=='__main__':unittest.main(verbosity=2)
