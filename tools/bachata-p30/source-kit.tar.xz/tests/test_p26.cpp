#include "p26_bcn_decoder.hpp"
#include "p26_alias_dispatch_gate.hpp"
#include "p26_upload_attestation.hpp"
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <random>
#include <vector>
using namespace BachataP26;
static int passed=0;
#define CHECK(x) do { if(!(x)) { std::fprintf(stderr,"FAIL %s line %d\n",#x,__LINE__); return 1;} ++passed; } while(0)
static std::array<uint8_t,8> RedGreenBlock() {return {0x00,0xf8,0xe0,0x07,0xe4,0xe4,0xe4,0xe4};}
int main(){
    auto block=RedGreenBlock();
    std::array<uint8_t,64> rgba{};
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,4,4,8,rgba)==DecodeStatus::Ok);
    CHECK(rgba[0]==255 && rgba[1]==0 && rgba[2]==0 && rgba[3]==255);
    CHECK(rgba[4]==0 && rgba[5]==255 && rgba[6]==0 && rgba[7]==255);
    CHECK(rgba[8]==170 && rgba[9]==85 && rgba[10]==0 && rgba[11]==255);
    CHECK(rgba[12]==85 && rgba[13]==170 && rgba[14]==0 && rgba[15]==255);
    CHECK(rgba[16]==255 && rgba[20]==0);
    CHECK(DecodeLevel(BcnFormat::BC1_RGB,block,4,4,8,rgba)==DecodeStatus::Ok);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,0,4,8,rgba)==DecodeStatus::EmptyExtent);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,4,0,8,rgba)==DecodeStatus::EmptyExtent);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,16385,4,8,rgba)==DecodeStatus::ExtentTooLarge);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,4,4,7,rgba)==DecodeStatus::BadStride);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,std::span<const uint8_t>(block.data(),7),4,4,8,rgba)==DecodeStatus::TruncatedInput);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,4,4,8,std::span<uint8_t>(rgba.data(),63))==DecodeStatus::SmallOutput);
    std::array<uint8_t,8> transparent={0,0,0xff,0xff,0xff,0xff,0xff,0xff};
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,transparent,4,4,8,rgba)==DecodeStatus::Ok);
    CHECK(rgba[3]==0 && rgba[0]==0 && rgba[1]==0 && rgba[2]==0);
    CHECK(DecodeLevel(BcnFormat::BC1_RGB,transparent,4,4,8,rgba)==DecodeStatus::Ok);
    CHECK(rgba[3]==255 && rgba[0]==0);
    // Four-color interpolation for BC3 even if color0 <= color1.
    std::array<uint8_t,16> bc3{};
    bc3[0]=255;bc3[1]=0;
    uint64_t indices=0;
    for(int i=0;i<16;i++)indices |= uint64_t(i%8) << (3*i);
    for(int i=0;i<6;i++)bc3[2+i]=static_cast<uint8_t>(indices>>(i*8));
    bc3[8]=0;bc3[9]=0;bc3[10]=0xff;bc3[11]=0xff;
    bc3[12]=0xe4;bc3[13]=0xe4;bc3[14]=0xe4;bc3[15]=0xe4;
    CHECK(DecodeLevel(BcnFormat::BC3,bc3,4,4,16,rgba)==DecodeStatus::Ok);
    CHECK(rgba[3]==255 && rgba[7]==0 && rgba[11]==218 && rgba[15]==182);
    CHECK(rgba[0]==0 && rgba[4]==255); // black, then white
    CHECK(rgba[8]==85 && rgba[12]==170); // BC3 4-color mode
    bc3[0]=0; bc3[1]=255;
    CHECK(DecodeLevel(BcnFormat::BC3,bc3,4,4,16,rgba)==DecodeStatus::Ok);
    CHECK(rgba[3]==0 && rgba[7]==255 && rgba[11]==51 && rgba[15]==102);
    CHECK(rgba[6*4+3]==0 && rgba[7*4+3]==255);
    std::array<uint8_t,32> npot{};
    std::copy(block.begin(),block.end(),npot.begin());
    std::copy(block.begin(),block.end(),npot.begin()+16);
    std::array<uint8_t,60> out_npot{};
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,npot,3,5,16,out_npot)==DecodeStatus::Ok);
    CHECK(out_npot[3]==255 && out_npot[4]==0 && out_npot[3*4]==255);
    CHECK(out_npot[4*3*4]==255 && out_npot[4*3*4+3]==255);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,npot,3,5,7,out_npot)==DecodeStatus::BadStride);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,std::span<const uint8_t>(npot.data(),23),3,5,16,out_npot)==DecodeStatus::TruncatedInput);
    auto trunc=DecodeMipChain(BcnFormat::BC1_RGB,npot,8,8,2);
    CHECK(trunc.status==DecodeStatus::TruncatedInput && trunc.mips.empty());
    std::vector<uint8_t> two_mips(40);
    for(int i=0;i<5;i++)std::copy(block.begin(),block.end(),two_mips.begin()+i*8);
    auto ok=DecodeMipChain(BcnFormat::BC1_RGBA,two_mips,8,8,2);
    CHECK(ok.status==DecodeStatus::Ok && ok.mips.size()==2);
    CHECK(ok.mips[0].width==8 && ok.mips[0].height==8 && ok.mips[0].rgba.size()==256);
    CHECK(ok.mips[1].width==4 && ok.mips[1].height==4 && ok.mips[1].rgba.size()==64);
    CHECK(ok.mips[1].rgba[3]==255);
    CHECK(DecodeMipChain(BcnFormat::BC1_RGBA,two_mips,8,8,0).status==DecodeStatus::UnsupportedMipChain);
    CHECK(DecodeMipChain(BcnFormat::BC1_RGBA,two_mips,8,8,16).status==DecodeStatus::UnsupportedMipChain);
    CHECK(DecodeMipChain(BcnFormat::BC1_RGBA,two_mips,16384,16384,1).status==DecodeStatus::ExtentTooLarge);
    CHECK(DecodeLevel(BcnFormat::BC1_RGBA,block,16384,16384,32768,rgba)==DecodeStatus::ExtentTooLarge);
    CHECK(DecodeMipChain(BcnFormat::BC3,bc3,4,4,1).status==DecodeStatus::Ok);
    CHECK(DecodeLevel(static_cast<BcnFormat>(255), block, 4,4,8,rgba)==DecodeStatus::UnsupportedFormat);
    CHECK(DecodeMipChain(static_cast<BcnFormat>(255), block,4,4,1).status==DecodeStatus::UnsupportedFormat);
    // Reuse and failure to complete are disallowed by upload state machine.
    UploadJournal journal;
    CHECK(!journal.began(0,1));
    CHECK(!journal.began(17,1));
    CHECK(journal.began(2,1));
    CHECK(!journal.proof().bcn_decode_completed);
    CHECK(!journal.submitted(true,true));
    CHECK(journal.decoded_level(0));
    CHECK(!journal.all_mips_decoded());
    CHECK(!journal.decoded_level(2));
    CHECK(journal.decoded_level(1));
    CHECK(journal.all_mips_decoded());
    CHECK(!journal.submitted(true,false));
    CHECK(journal.submitted(true,true));
    CHECK(!journal.completed_after_gpu_fence(false,true,true,true,true,true));
    CHECK(!journal.proof().bcn_decode_completed);
    CHECK(journal.completed_after_gpu_fence(true,true,true,true,true,true));
    CHECK(journal.proof().bcn_decode_completed);
    CHECK(journal.proof().decoded_mips_all_uploaded);
    CHECK(journal.proof().mutable_create_flag);
    journal.invalidate();
    CHECK(!journal.proof().bcn_decode_completed);
    CHECK(!journal.began(1,1));
    CHECK(journal.began(1,2));
    CHECK(!journal.proof().decoded_mips_all_uploaded);
    // Minecraft reported a sampled image and storage image with overlapping guest ranges.
    BachataP25::Descriptor aliases[2]={
       {{0x10000000ULL,0x200000ULL},BachataP25::DescriptorAccess::Sample,true},
       {{0x10000000ULL,0x280000ULL},BachataP25::DescriptorAccess::StorageAtomic,true}};
    auto hazard=BachataP25::FindFirstHazard(aliases,2);
    CHECK(hazard.kind==HazardKind::ReadWriteOverlap);
    DispatchEvidence evidence{};
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockUnknownSemantics);
    CHECK(!DecideDispatch(hazard.kind,evidence).may_dispatch);
    evidence.read_dependency=ReadDependency::EntryStateOnly;
    evidence.atomic_ordering=AtomicOrdering::CrossInvocationOrCrossDispatch;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockUnsupportedAtomicAliasing);
    evidence.atomic_ordering=AtomicOrdering::None;
    evidence.shader_uses_dynamic_alias_indices=true;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockUnknownSemantics);
    evidence.shader_uses_dynamic_alias_indices=false;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockMissingSnapshotMechanism);
    evidence.full_sampled_subresources_copied=true;
    evidence.snapshot_is_distinct_gpu_allocation=true;
    evidence.transfer_copy_scheduled_before_dispatch=true;
    evidence.transfer_write_to_shader_read_barrier=true;
    evidence.sampled_descriptors_rebound_to_snapshot=true;
    evidence.original_storage_bindings_preserved=true;
    evidence.storage_layout_access_and_queue_ownership_preserved=true;
    evidence.sample_and_storage_format_compatible=true;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::SnapshotPlanWithProofOnly);
    CHECK(DecideDispatch(hazard.kind,evidence).must_preserve_original_storage);
    evidence.overlapping_storage_writers=true;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockUnsupportedStorageAliasing);
    evidence.overlapping_storage_writers=false;
    evidence.read_dependency=ReadDependency::ReadsIntermediateWrites;
    CHECK(DecideDispatch(hazard.kind,evidence).action==DispatchAction::BlockUnsupportedAtomicAliasing);
    CHECK(DecideDispatch(HazardKind::WriteWriteOverlap,evidence).may_dispatch==false);
    CHECK(DecideDispatch(HazardKind::InvalidRange,evidence).action==DispatchAction::BlockInvalid);
    CHECK(DecideDispatch(HazardKind::None,DispatchEvidence{}).may_dispatch);
    // Fuzz malformed/truncated block lengths; no out-of-bounds reads under sanitizers.
    std::mt19937 gen(0x26bc3);
    for (int i=0;i<1000;i++) {
        std::array<uint8_t,16> random{};
        for(auto& x:random)x=static_cast<uint8_t>(gen()&255);
        const size_t cut=gen()%16;
        DecodeStatus s=DecodeLevel(BcnFormat::BC3,std::span<const uint8_t>(random.data(),cut),
                                    4,4,16,rgba);
        CHECK(s==DecodeStatus::TruncatedInput);
    }
    std::printf("P26 PASS assertions=%d\n",passed);
}
