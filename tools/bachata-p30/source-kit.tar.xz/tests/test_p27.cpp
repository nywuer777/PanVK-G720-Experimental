#include "p27_upload_plan.hpp"
#include "p27_shader_dependency.hpp"
#include <array>
#include <iostream>
#include <stdexcept>
#include <algorithm>
using namespace BachataP27;
#define CHECK(x) do {++checks; if(!(x)) throw std::runtime_error(#x); }while(0)
int main(){
  int checks=0;
  std::array<uint8_t,8> red{0x00,0xf8,0xe0,0x07,0,0,0,0};
  std::array<uint8_t,16> alpha{};
  alpha[0]=255;alpha[1]=0;
  std::copy(red.begin(),red.end(),alpha.begin()+8);
  std::array<CompressedSubresource,1> one{{{0,0,4,4,8,red}}};
  auto plan=BuildPlan(BcnFormat::BC1_RGBA,false,4,4,1,1,one);
  CHECK(plan.status==PlanStatus::Ok);CHECK(plan.staging.size()==64);
  CHECK(plan.staging[0]==255 && plan.staging[1]==0 && plan.staging[2]==0 && plan.staging[3]==255);
  CHECK(plan.regions[0].offset==0 && plan.regions[0].bytes==64);
  DestinationProof dst{true,true,true,true,true,true,true,true};
  CHECK(MaySubmit(plan,dst));
  dst.exact_srgb_match=false;CHECK(!MaySubmit(plan,dst));dst.exact_srgb_match=true;
  dst.destination_rgba8=false;CHECK(!MaySubmit(plan,dst));dst.destination_rgba8=true;
  dst.external_staging_buffer_sufficient=false;CHECK(!MaySubmit(plan,dst));dst.external_staging_buffer_sufficient=true;
  dst.external_staging_buffer_mapped=false;CHECK(!MaySubmit(plan,dst));dst.external_staging_buffer_mapped=true;
  dst.transfer_dst_usage=false;CHECK(!MaySubmit(plan,dst));dst.transfer_dst_usage=true;
  dst.sampled_image_feature=false;CHECK(!MaySubmit(plan,dst));dst.sampled_image_feature=true;
  dst.dimension_and_subresource_match=false;CHECK(!MaySubmit(plan,dst));dst.dimension_and_subresource_match=true;
  dst.color_aspect=false;CHECK(!MaySubmit(plan,dst));dst.color_aspect=true;
  CHECK(MaySubmit(plan,dst));
  CHECK(BuildPlan(BcnFormat::BC3,true,4,4,1,1,
     std::array<CompressedSubresource,1>{{{0,0,4,4,16,alpha}}}).status==PlanStatus::Ok);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,4,4,0,1,one).status==PlanStatus::InvalidShape);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,4,4,1,0,one).status==PlanStatus::InvalidShape);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,4,4,17,1,one).status==PlanStatus::InvalidShape);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,4,4,1,65,one).status==PlanStatus::InvalidShape);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,0,4,1,1,one).status==PlanStatus::InvalidShape);
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,4,4,1,1,{}).status==PlanStatus::InvalidShape);
  std::array<CompressedSubresource,2> layers{{{0,0,4,4,8,red},{0,1,4,4,8,red}}};
  auto lp=BuildPlan(BcnFormat::BC1_RGB,false,4,4,1,2,layers);
  CHECK(lp.status==PlanStatus::Ok);CHECK(lp.staging.size()==128);
  CHECK(lp.regions[1].offset==64);CHECK(lp.regions[1].layer==1);
  CHECK(MaySubmit(lp,dst));
  auto bad=layers;bad[1].layer=0;
  CHECK(BuildPlan(BcnFormat::BC1_RGB,false,4,4,1,2,bad).status==PlanStatus::DuplicateSubresource);
  bad=layers;bad[1].width=5;
  CHECK(BuildPlan(BcnFormat::BC1_RGB,false,4,4,1,2,bad).status==PlanStatus::InvalidShape);
  bad=layers;bad[1].row_stride=0;
  CHECK(BuildPlan(BcnFormat::BC1_RGB,false,4,4,1,2,bad).status==PlanStatus::MalformedBlocks);
  bad=layers;bad[1].blocks={};
  CHECK(BuildPlan(BcnFormat::BC1_RGB,false,4,4,1,2,bad).status==PlanStatus::MalformedBlocks);
  std::array<CompressedSubresource,2> mips{{{0,0,8,8,16,{}},{1,0,4,4,8,red}}};
  std::array<uint8_t,32> four{};for(size_t i=0;i<four.size();i+=8)std::copy(red.begin(),red.end(),four.begin()+i);
  mips[0].blocks=four;
  auto mp=BuildPlan(BcnFormat::BC1_RGB,true,8,8,2,1,mips);
  CHECK(mp.status==PlanStatus::Ok);CHECK(mp.srgb);
  CHECK(mp.regions[0].bytes==256 && mp.regions[1].bytes==64);
  CHECK(mp.regions[1].offset==256 && mp.staging.size()==320);
  CHECK(MaySubmit(mp,dst));
  mips[1].row_stride=7; CHECK(BuildPlan(BcnFormat::BC1_RGB,true,8,8,2,1,mips).status==PlanStatus::MalformedBlocks);
  // A 64-megapixel RGBA decoded source would exceed the 256MiB cap or
  // be rejected before huge allocation.
  std::array<CompressedSubresource,1> huge{{{0,0,16384,16384,32768,{}}}};
  CHECK(BuildPlan(BcnFormat::BC1_RGBA,false,16384,16384,1,1,huge).status==PlanStatus::BudgetExceeded);
  ShaderEvidence prov{true,true,true,true};
  const std::array<Op,2> ordered{{{ImageOp::SampledRead,23,false},{ImageOp::StorageWrite,24,false}}};
  auto safe=Analyze(ordered,prov,23,24);
  CHECK(safe.verified);CHECK(safe.reads==BachataP26::ReadDependency::EntryStateOnly);
  CHECK(safe.atomics==BachataP26::AtomicOrdering::None);
  const std::array<Op,2> reversed{{{ImageOp::StorageWrite,24,false},{ImageOp::SampledRead,23,false}}};
  auto uns=Analyze(reversed,prov,23,24);
  CHECK(uns.verified);CHECK(uns.reads==BachataP26::ReadDependency::ReadsIntermediateWrites);
  const std::array<Op,2> atomic{{{ImageOp::SampledRead,23,false},{ImageOp::StorageAtomic,24,false}}};
  CHECK(!Analyze(atomic,prov,23,24).verified);
  CHECK(Analyze(atomic,prov,23,24).atomics==BachataP26::AtomicOrdering::CrossInvocationOrCrossDispatch);
  auto weak=prov;weak.single_invocation_or_proven_disjoint_writes=false;
  CHECK(!Analyze(ordered,weak,23,24).verified);
  weak=prov;weak.single_basic_block=false;CHECK(!Analyze(ordered,weak,23,24).verified);
  weak=prov;weak.no_loops_or_calls=false;CHECK(!Analyze(ordered,weak,23,24).verified);
  weak=prov;weak.no_hidden_writes_or_indirect_alias=false;CHECK(!Analyze(ordered,weak,23,24).verified);
  const std::array<Op,2> dyn{{{ImageOp::SampledRead,23,true},{ImageOp::StorageWrite,24,false}}};
  CHECK(!Analyze(dyn,prov,23,24).verified);
  const std::array<Op,3> barrier{{{ImageOp::SampledRead,23,false},{ImageOp::MemoryBarrier,1,false},{ImageOp::StorageWrite,24,false}}};
  CHECK(!Analyze(barrier,prov,23,24).verified);
  CHECK(!Analyze({},prov,23,24).verified);
  // P26 Minecraft evidence: same base but different spans; no shader provenance.
  const auto conflict=BachataP25::FindFirstHazard<4>(
      std::array<BachataP25::Descriptor,2>{{{{0x100000000ull,0x200000ull},BachataP25::DescriptorAccess::Sample,true},
       {{0x100000000ull,0x280000ull},BachataP25::DescriptorAccess::StorageAtomic,true}}}.data(),2);
  CHECK(conflict.kind==BachataP25::HazardKind::ReadWriteOverlap);
  CHECK(!Analyze(atomic,{},23,24).verified);
  std::cout<<"P27 portable: "<<checks<<" checks OK\n";
}
