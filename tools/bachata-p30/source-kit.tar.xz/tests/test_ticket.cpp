// SPDX-License-Identifier: GPL-2.0-or-later
#include "p28_async_ticket.hpp"
#include <cassert>
#include <iostream>
using BachataP28::Ticket;
using BachataP28::PollState;
using BachataP28::PollStatus;
static unsigned checks=0;
#define CHECK(x) do { ++checks; assert(x); } while(0)
int main(){
 Ticket t{.timeline_tick=50,.image_uid=234,.backing_tag=567,.generation=12,
          .mip_levels=7,.array_layers=2,.active=true};
 CHECK(PollState(t,50,false,234,567,12,true)==PollStatus::NotSubmitted);
 CHECK(t.active);
 CHECK(PollState(t,49,true,234,567,12,true)==PollStatus::NotSubmitted);
 CHECK(PollState(t,51,false,234,567,12,true)==PollStatus::GpuPending);
 CHECK(t.active);
 CHECK(PollState(t,51,true,234,567,12,true)==PollStatus::Completed);
 CHECK(!t.active);
 CHECK(PollState(t,52,true,234,567,12,true)==PollStatus::InvalidTicket);
 {
  auto s=Ticket{50,234,567,12,7,2,true};
  CHECK(PollState(s,51,true,999,567,12,true)==PollStatus::StaleImage);
  CHECK(!s.active);
 }
 {
  auto s=Ticket{50,234,567,12,7,2,true};
  CHECK(PollState(s,51,true,234,999,12,true)==PollStatus::StaleImage);
 }
 {
  auto s=Ticket{50,234,567,12,7,2,true};
  CHECK(PollState(s,51,true,234,567,13,true)==PollStatus::StaleImage);
 }
 {
  auto s=Ticket{50,234,567,12,7,2,true};
  CHECK(PollState(s,51,true,234,567,12,false)==PollStatus::StaleImage);
 }
 {
  auto s=Ticket{0,234,567,12,7,2,true};
  CHECK(PollState(s,51,true,234,567,12,true)==PollStatus::InvalidTicket);
 }
 {
  auto s=Ticket{50,234,567,0,7,2,true};
  CHECK(PollState(s,51,true,234,567,0,true)==PollStatus::InvalidTicket);
 }
 {
  auto s=Ticket{50,234,567,12,7,2,false};
  CHECK(PollState(s,51,true,234,567,12,true)==PollStatus::InvalidTicket);
 }
 for(unsigned i=1;i<=128;i++) {
  auto s=Ticket{static_cast<uint64_t>(i),100,200,i,1,1,true};
  CHECK(PollState(s,i,false,100,200,i,true)==PollStatus::NotSubmitted);
  CHECK(PollState(s,i+1,false,100,200,i,true)==PollStatus::GpuPending);
  CHECK(PollState(s,i+1,true,100,200,i,true)==PollStatus::Completed);
 }
 std::cout<<"P28_TICKET_PASS checks="<<checks<<"\n";
}
