import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import p29_build_gate as p29

KIT=Path(__file__).resolve().parents[1]/'source'

class BuildGate(unittest.TestCase):
    def test_01_pinned_revision(self):
        self.assertEqual(len(p29.PIN),40)
    def test_02_pin_sha(self):
        self.assertEqual(len(p29.REQUIRED_BLOBS),5)
    def test_03_kit_complete(self):
        self.assertEqual(len(p29.verify_kit(KIT)),16)
    def test_04_kit_hashes_deterministic(self):
        d=p29.verify_kit(KIT)
        self.assertEqual(d['port_renderer_p28.py'],p29.digest_file(KIT/'port_renderer_p28.py'))
    def test_05_missing_kit(self):
        with self.assertRaisesRegex(p29.GateFailure,'SOURCE_KIT_MISSING'):
            p29.verify_kit(Path('/definitely/not/existing/p29kit'))
    def test_06_missing_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            k=Path(tmp)
            with self.assertRaisesRegex(p29.GateFailure,'SOURCE_KIT_INCOMPLETE'):
                p29.verify_kit(k)
    def test_07_no_fake_build_without_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=p29.execute(kit=KIT,root=None,output=Path(tmp))
            self.assertEqual(out['status'],'BLOCKED')
            self.assertEqual(out['failure_code'],'SOURCE_CHECKOUT_REQUIRED')
            self.assertFalse(out['full_core_compile_attempted'])
    def test_08_preflight(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=p29.execute(kit=KIT,root=None,output=Path(tmp),preflight_only=True)
            self.assertTrue(out['kit_validated'])
            self.assertEqual(out['status'],'OFFLINE_PREFLIGHT_ONLY')
            self.assertTrue((Path(tmp)/'P29_RESULT.json').exists())
    def test_09_conflicting_flags(self):
        with self.assertRaisesRegex(p29.GateFailure,'INCOMPATIBLE_MODE'):
            p29.execute(kit=KIT,root=None,output=Path('/tmp/should_not_exist_p29'),preflight_only=True,build=True)
    def test_10_no_git(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(p29.GateFailure,'NOT_A_GIT_CHECKOUT'):
                p29.verify_checkout(Path(tmp))
    def test_11_wrong_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            subprocess.run(['git','init','-q',str(d)],check=True)
            (d/'file').write_text('x')
            subprocess.run(['git','-C',str(d),'add','file'],check=True)
            subprocess.run(['git','-C',str(d),'-c','user.name=Test','-c','user.email=test@local','commit','-qm','test'],check=True)
            with self.assertRaisesRegex(p29.GateFailure,'WRONG_SOURCE_REVISION'):
                p29.verify_checkout(d)
    def test_12_tracked_dirty(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'.git').mkdir()
            with mock.patch.object(p29,'run_cmd',side_effect=[p29.PIN,' M changed']):
                with self.assertRaisesRegex(p29.GateFailure,'DIRTY_CHECKOUT'):
                    p29.verify_checkout(d)
    def test_13_wrong_blob(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'.git').mkdir()
            with mock.patch.object(p29,'run_cmd',side_effect=[p29.PIN,'','deadbeef']):
                with self.assertRaisesRegex(p29.GateFailure,'SOURCE_BLOB_MISMATCH'):
                    p29.verify_checkout(d)
    def test_14_missing_submodules(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'.git').mkdir()
            b=[p29.PIN,'']+list(p29.REQUIRED_BLOBS.values())
            with mock.patch.object(p29,'run_cmd',side_effect=b):
                with self.assertRaisesRegex(p29.GateFailure,'BUILD_SCRIPT_MISSING'):
                    p29.verify_checkout(d)
    def test_15_build_not_attempted_if_checkout_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=p29.execute(kit=KIT,root=Path(tmp),output=Path(tmp)/'out',build=True)
            self.assertFalse(out['full_core_compile_attempted'])
            self.assertFalse(out['full_core_compile_passed'])
    def test_16_refuses_wrong_arch_elf(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            src=d/'a.c';src.write_text('int main(void){return 0;}')
            elf=d/'a';subprocess.run(['cc',str(src),'-o',str(elf)],check=True)
            with elf.open('ab') as f:f.write(b'\x00'*110000)
            with self.assertRaisesRegex(p29.GateFailure,'WRONG_ELF_ARCHITECTURE'):
                p29.verify_elf(elf,d)
    def test_17_refuses_missing_elf(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            with self.assertRaisesRegex(p29.GateFailure,'BUILT_ELF_MISSING_OR_EMPTY'):
                p29.verify_elf(d/'absent',d)
    def test_18_failed_command_rejected(self):
        with self.assertRaisesRegex(p29.GateFailure,'COMMAND_FAILED'):
            p29.run_cmd(['false'])
    def test_19_sha_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)/'test';d.write_bytes(b'abc')
            self.assertEqual(p29.digest_file(d),hashlib.sha256(b'abc').hexdigest())
    def test_20_p29_never_claims_games_fixed(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=p29.execute(kit=KIT,root=None,output=Path(tmp),preflight_only=True)
            self.assertFalse(out['outlast_fixed'])
            self.assertFalse(out['minecraft_fixed'])
            self.assertFalse(out['f43dev_apk_modified'])
    def test_21_no_public_apk_upload(self):
        self.assertNotIn('apk',str(p29.SOURCE_FILES).lower())
    def test_22_check_build_requires_kit(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            out=p29.execute(kit=d,root=None,output=d/'evidence',build=True)
            self.assertEqual(out['status'],'BLOCKED')
            self.assertIn('SOURCE_KIT_INCOMPLETE',out['failure_code'])

if __name__=='__main__':unittest.main(verbosity=2)
