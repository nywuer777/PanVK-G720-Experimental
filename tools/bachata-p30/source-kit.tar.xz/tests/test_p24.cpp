#include "../source/p24_compatibility.hpp"
#include <cstdlib>
#include <iostream>
using namespace BachataP24;
static int count = 0;
#define CHECK(e) do { ++count; if (!(e)) { std::cerr << "FAILED line " << __LINE__ << ": " #e "\n"; std::exit(1); } } while(0)
static constexpr DecodedViewRequest BC(PixelFormat g, PixelFormat b, bool decoded=true,
                                       uint32_t mip=1, uint32_t layers=1) {
  return {g,b,decoded,true,false,0,mip,mip,0,layers,layers};
}
static constexpr AliasRequest Alias(GuestMemoryRange a, GuestMemoryRange b) {
    return {a,b,true,true,false,false,false,false,false};
}
int main() {
    constexpr auto bc1u = BC(PixelFormat::Bc1Unorm,PixelFormat::Rgba8Unorm, true, 6);
    constexpr auto bc1s = BC(PixelFormat::Bc1Srgb,PixelFormat::Rgba8Srgb, true, 10);
    constexpr auto bc3s = BC(PixelFormat::Bc3Srgb,PixelFormat::Rgba8Srgb, true, 10);
    CHECK(ResolveDecodedBcnSampledView(bc1u).allowed());
    CHECK(ResolveDecodedBcnSampledView(bc1s).allowed());
    CHECK(ResolveDecodedBcnSampledView(bc3s).allowed());
    CHECK(ResolveDecodedBcnSampledView(BC(PixelFormat::Bc3Unorm,PixelFormat::Rgba8Unorm)).allowed());
    CHECK(ResolveDecodedBcnSampledView(bc1u).sampled_format==PixelFormat::Rgba8Unorm);
    CHECK(ResolveDecodedBcnSampledView(bc1s).sampled_format==PixelFormat::Rgba8Srgb);
    CHECK(ResolveDecodedBcnSampledView(bc3s).mip_levels==10);
    CHECK(ResolveDecodedBcnSampledView(bc1u).mip_levels==6);
    CHECK(!ResolveDecodedBcnSampledView(BC(PixelFormat::Bc1Unorm,PixelFormat::Rgba8Unorm,false)).allowed());
    CHECK(!ResolveDecodedBcnSampledView(BC(PixelFormat::Bc1Unorm,PixelFormat::Bc1Unorm)).allowed());
    CHECK(ResolveDecodedBcnSampledView(BC(PixelFormat::Unknown,PixelFormat::Rgba8Unorm)).status==ViewStatus::UnsupportedFormat);
    CHECK(ResolveDecodedBcnSampledView(BC(PixelFormat::Bc1Srgb,PixelFormat::Rgba8Unorm)).status==ViewStatus::MutableFormatNotAuthorized);
    auto mutable_view=BC(PixelFormat::Bc1Srgb,PixelFormat::Rgba8Unorm); mutable_view.mutable_compatible_view_confirmed=true;
    CHECK(ResolveDecodedBcnSampledView(mutable_view).allowed());
    CHECK(ResolveDecodedBcnSampledView(mutable_view).requires_reinterpretation);
    CHECK(ResolveDecodedBcnSampledView(mutable_view).sampled_format==PixelFormat::Rgba8Srgb);
    auto missing_mip=bc1u; missing_mip.mip_levels=0;
    CHECK(ResolveDecodedBcnSampledView(missing_mip).status==ViewStatus::InvalidRange);
    auto exceeded_mip=bc3s; exceeded_mip.base_mip=1;
    CHECK(ResolveDecodedBcnSampledView(exceeded_mip).status==ViewStatus::InvalidRange);
    auto subrange=bc3s; subrange.base_mip=2; subrange.mip_levels=6;
    CHECK(ResolveDecodedBcnSampledView(subrange).allowed());
    CHECK(ResolveDecodedBcnSampledView(subrange).base_mip==2);
    auto overflow_layer=bc1u; overflow_layer.base_layer=1;
    CHECK(ResolveDecodedBcnSampledView(overflow_layer).status==ViewStatus::InvalidRange);
    auto multilayer=BC(PixelFormat::Bc3Srgb,PixelFormat::Rgba8Srgb,true,6,3);
    CHECK(ResolveDecodedBcnSampledView(multilayer).allowed());
    multilayer.base_layer=1; multilayer.layer_count=2;
    CHECK(ResolveDecodedBcnSampledView(multilayer).allowed());
    auto not_sampled=bc1u; not_sampled.sampled_usage=false;
    CHECK(ResolveDecodedBcnSampledView(not_sampled).status==ViewStatus::UnsupportedFormat);
    CHECK(IsBc(PixelFormat::Bc1Srgb));
    CHECK(!IsBc(PixelFormat::Rgba8Srgb));
    CHECK(IsSrgb(PixelFormat::Bc3Srgb));
    CHECK(!IsSrgb(PixelFormat::Bc3Unorm));
    CHECK(IsRgba(PixelFormat::Rgba8Srgb));
    constexpr GuestMemoryRange read{0x100000ULL,0x200000},write{0x100000ULL,0x280000};
    CHECK(ValidRange(read));
    CHECK(Overlap(read,write));
    CHECK(Overlap(write,read));
    auto a=Alias(read,write);
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::BlockNoReadSnapshot);
    CHECK(!ClassifyStorageImageAlias(a).safe_to_continue_without_snapshot());
    a.can_create_independent_read_snapshot=true;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::BlockNoReadSnapshot);
    a.can_schedule_copy_before_draw=true;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::BlockNoReadSnapshot);
    a.can_sync_copy_and_shader_reads=true;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::SnapshotRequired);
    CHECK(ClassifyStorageImageAlias(a).needs_pre_draw_read_snapshot);
    CHECK(ClassifyStorageImageAlias(a).must_preserve_storage_writes);
    a.storage_atomics=true;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::SnapshotRequired);
    a.multiple_overlapping_storage_outputs=true;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::BlockUnsupportedStorageAlias);
    a.multiple_overlapping_storage_outputs=false;
    a.sampled_reads=false;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::NoConflict);
    a.sampled_reads=true; a.storage_writes=false; a.storage_atomics=false;
    CHECK(ClassifyStorageImageAlias(a).status==AliasStatus::NoConflict);
    auto b=Alias({100,10},{110,10});
    CHECK(!Overlap(b.sampled,b.storage));
    CHECK(ClassifyStorageImageAlias(b).safe_to_continue_without_snapshot());
    b=Alias({100,11},{110,10});
    CHECK(Overlap(b.sampled,b.storage));
    CHECK(ClassifyStorageImageAlias(b).status==AliasStatus::BlockNoReadSnapshot);
    b=Alias({0,1},{0,1});
    CHECK(Overlap(b.sampled,b.storage));
    b=Alias({UINT64_MAX-1,4},{1,1});
    CHECK(ClassifyStorageImageAlias(b).status==AliasStatus::BlockInvalidRange);
    b=Alias({0,0},{1,1});
    CHECK(ClassifyStorageImageAlias(b).status==AliasStatus::BlockInvalidRange);
    b=Alias({10,5},{100,50});
    CHECK(ClassifyStorageImageAlias(b).status==AliasStatus::NoConflict);
    CHECK(!ClassifyStorageImageAlias(b).needs_pre_draw_read_snapshot);
    auto large=Alias({UINT64_MAX-100,40},{UINT64_MAX-70,20});
    CHECK(Overlap(large.sampled,large.storage));
    std::cout << "P24 synthetic source compatibility checks passed: " << count << "/" << count << "\n";
}
