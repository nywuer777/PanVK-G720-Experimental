import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import port_renderer_p25 as p

class TestPort(unittest.TestCase):
    def setUp(self):
        self.mock={
            'src/video_core/texture_cache/image.h':'#pragma once\n'+p.OLD_IMAGE_HEADER+'\n',
            'src/video_core/texture_cache/image_view.cpp':'#include "video_core/texture_cache/image.h"\n'+p.OLD_VIEW_HEAD+'\n',
            'src/video_core/renderer_vulkan/vk_rasterizer.cpp':'first pass\n'+p.OLD_RASTER_ANCHOR+'\n'}
    def test_01_injection_h(self):
        self.assertIn('p25_decode_proof',p.transform(dict(self.mock))['src/video_core/texture_cache/image.h'])
    def test_02_view_guard(self):
        self.assertIn('PlanBcnView',p.transform(dict(self.mock))['src/video_core/texture_cache/image_view.cpp'])
    def test_03_always_check_decode(self):
        self.assertIn('answer.may_create_view()',p.transform(dict(self.mock))['src/video_core/texture_cache/image_view.cpp'])
    def test_04_no_assert_removed(self):
        s=p.transform(dict(self.mock))['src/video_core/texture_cache/image_view.cpp']
        self.assertNotIn('#define ASSERT',s)
    def test_05_audit_opt_in(self):
        s=p.transform(dict(self.mock))['src/video_core/renderer_vulkan/vk_rasterizer.cpp']
        self.assertIn('#ifdef BACHATA_P25_GPU_AUDIT',s)
    def test_06_audit_no_addresses(self):
        s=p.transform(dict(self.mock))['src/video_core/renderer_vulkan/vk_rasterizer.cpp']
        self.assertNotIn('{:#x}',s)
    def test_07_wrong_image_header(self):
        d=dict(self.mock); d['src/video_core/texture_cache/image.h']=d['src/video_core/texture_cache/image.h'].replace('State state;','State fields;')
        with self.assertRaises(ValueError):p.transform(d)
    def test_08_duplicate_anchor(self):
        d=dict(self.mock); d['src/video_core/texture_cache/image_view.cpp']+=p.OLD_VIEW_HEAD
        with self.assertRaises(ValueError):p.transform(d)
    def test_09_missing_raster(self):
        d=dict(self.mock); d['src/video_core/renderer_vulkan/vk_rasterizer.cpp']='empty'
        with self.assertRaises(ValueError):p.transform(d)
    def test_10_source_unchanged(self):
        d=dict(self.mock);p.transform(dict(d))
        self.assertEqual(d['src/video_core/texture_cache/image_view.cpp'],self.mock['src/video_core/texture_cache/image_view.cpp'])
    def test_11_fail_idempotence(self):
        d=p.transform(dict(self.mock))
        with self.assertRaises(ValueError):p.transform(d)
    def test_12_guard_lower_case_token(self):
        self.assertNotIn('--bachata-saf-token',str(p.NEW_RASTER_ANCHOR))
    def test_13_detect_one_callsite(self):
        self.assertEqual(p.NEW_RASTER_ANCHOR.count('FindFirstHazard'),1)
    def test_14_decoder_proof_is_false_by_default(self):
        self.assertIn('p25_decode_proof{}',p.NEW_IMAGE_HEADER)
    def test_15_explicit_format_mapping(self):
        for x in ['eBc1RgbaUnormBlock','eBc3SrgbBlock','eR8G8B8A8Srgb']:
            self.assertIn(x,p.NEW_VIEW_HEAD)
    def test_16_mutable_compatibility(self):
        self.assertIn('IsVulkanFormatCompatible',p.NEW_VIEW_HEAD)
    def test_17_full_pin(self):
        self.assertEqual(len(p.EXPECTED_UPSTREAM),40)
    def test_18_invalid_range(self):
        self.assertIn('image.backing->image.image_ci.mipLevels',p.NEW_VIEW_HEAD)
    def test_19_no_shader_hazard_auto_fix(self):
        s=p.NEW_RASTER_ANCHOR
        for bad in ['barrier2(', 'BindDescriptor', 'CopyImage(']:self.assertNotIn(bad,s)
    def test_20_gated_logging(self):
        self.assertIn('classification-only',p.NEW_RASTER_ANCHOR)

if __name__=='__main__':unittest.main(verbosity=2)
