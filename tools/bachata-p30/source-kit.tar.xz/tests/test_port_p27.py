import sys,unittest,tempfile,json,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'source'))
import port_renderer_p25 as p25
import port_renderer_p27 as p27
ROOT=Path(__file__).parents[1]/'source'
class TestPortP27(unittest.TestCase):
 def setUp(self):
  self.mock={
   'src/video_core/texture_cache/image.h':'#pragma once\n'+p25.OLD_IMAGE_HEADER+'\n    void Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer, u64 offset);\n',
   'src/video_core/texture_cache/image_view.cpp':'#include "video_core/texture_cache/image.h"\n'+p25.OLD_VIEW_HEAD+'\n',
   'src/video_core/renderer_vulkan/vk_rasterizer.cpp':'#include <array>\n'+p25.OLD_RASTER_ANCHOR+'\n',
   'src/video_core/texture_cache/image.cpp':'''void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,
                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {}
void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,
                   u64 offset) {
    SetBackingSamples(info.num_samples, false);
        .size = info.guest_size,
        .size = info.guest_size,
}
void Image::Download(xxx) {}
''',
   'CMakeLists.txt':'               src/video_core/renderer_vulkan/vk_rasterizer.cpp\n',
  }
 def test_01_transform(self):self.assertEqual(len(p27.transform(self.mock)),5)
 def test_02_upload_size(self):
  txt=p27.transform(self.mock)['src/video_core/texture_cache/image.cpp']
  self.assertEqual(txt.count('.size = upload_source_bytes'),2)
  self.assertIn('journal.invalidate()',txt)
  self.assertIn('vk::AccessFlagBits2::eShaderWrite',txt)
 def test_03_fallback_unchanged(self):
  self.assertIn('decoded_source_bytes ? decoded_source_bytes : info.guest_size',p27.transform(self.mock)['src/video_core/texture_cache/image.cpp'])
 def test_04_header(self):self.assertIn('decoded_source_bytes = 0',p27.transform(self.mock)['src/video_core/texture_cache/image.h'])
 def test_05_cmake(self):self.assertIn('p27_vk_decoded_upload.cpp',p27.transform(self.mock)['CMakeLists.txt'])
 def test_06_strict_reapply(self):
  with self.assertRaises(ValueError):p27.transform(p27.transform(self.mock))
 def test_07_duplicate_anchor(self):
  m=dict(self.mock);m['CMakeLists.txt']*=2
  with self.assertRaises(ValueError):p27.transform(m)
 def test_08_no_mutation(self):
  old=self.mock.copy();p27.transform(self.mock);self.assertEqual(old,self.mock)
 def test_09_headers(self):
  for fn in p27.HEADERS:self.assertTrue((ROOT/fn).exists(),fn)
 def test_10_privacy(self):
  code=''.join((ROOT/f).read_text() for f in p27.HEADERS)
  for key in ('--bachata-saf-token','runtime-control.sock','--bachata-contract'):
   self.assertNotIn(key,code)
 def test_11_no_assert_bypass(self):
  code=''.join(p27.transform(self.mock).values())
  self.assertNotIn('NDEBUG',code)
  self.assertNotIn('ignore_assert',code)
 def test_12_journal_after_upload(self):
  c=(ROOT/'p27_vk_decoded_upload.cpp').read_text()
  self.assertLess(c.index('image.Upload('),c.index('journal.began('))
  self.assertLess(c.index('scheduler.Finish()'),c.index('completed_after_gpu_fence('))
 def test_13_vulkan_entrypoints(self):
  c=(ROOT/'p27_vk_decoded_upload.cpp').read_text()
  self.assertIn('vmaFlushAllocation(',c)
  self.assertIn('vk::BufferImageCopy',c)
  self.assertIn('BlockedBacking',c)
 def test_14_pinned_source(self):self.assertEqual(p25.EXPECTED_UPSTREAM,'be6bc2e9c60799e071dd2fafa6216e8d80ec619c')
 def test_15_cli_fixture(self):
  with tempfile.TemporaryDirectory() as t:
   t=Path(t)
   for name,code in self.mock.items():
    f=t/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(code)
   cmd=[sys.executable,str(ROOT/'port_renderer_p27.py'),'--source-root',str(t),'--out',str(t/'p27.diff'),'--synthetic-fixture']
   first=subprocess.run(cmd,capture_output=True,text=True)
   self.assertEqual(first.returncode,0,first.stderr)
   self.assertTrue(json.loads(first.stdout)['source_changes'])
   self.assertEqual((t/'CMakeLists.txt').read_text(),self.mock['CMakeLists.txt'])
   second=subprocess.run(cmd+['--write'],capture_output=True,text=True)
   self.assertEqual(second.returncode,0,second.stderr)
   self.assertIn('p27_vk_decoded_upload.cpp',(t/'CMakeLists.txt').read_text())
   self.assertTrue((t/'src/video_core/renderer_vulkan/p27_upload_plan.hpp').is_file())
   third=subprocess.run(cmd+['--write'],capture_output=True,text=True)
   self.assertNotEqual(third.returncode,0)
if __name__=='__main__':unittest.main(verbosity=2)
