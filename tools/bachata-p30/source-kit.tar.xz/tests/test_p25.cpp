#include "../source/p25_runtime_binding_gate.hpp"
#include <array>
#include <cstdlib>
#include <iostream>
using namespace BachataP25;
static int checks = 0;
#define CHECK(X) do { ++checks; if(!(X)) { std::cerr<<"P25 CHECK FAILED line "<<__LINE__<<": "#X"\n";std::exit(1); } } while(0)
constexpr Provenance full_proof = {true,true,true,true,true,true,true,true};
static ViewInputs base(PixelFormat guest,PixelFormat backing,uint32_t mips=10) {
    return {guest,backing,true,false,0,mips,mips,0,1,1,full_proof};
}
int main(){
  using V=ViewVerdict;
  auto a=base(PixelFormat::Bc1Unorm,PixelFormat::Rgba8Unorm,6);
  auto b=base(PixelFormat::Bc1Srgb,PixelFormat::Rgba8Srgb,10);
  auto c=base(PixelFormat::Bc3Srgb,PixelFormat::Rgba8Srgb,10);
  auto d=base(PixelFormat::Bc3Unorm,PixelFormat::Rgba8Unorm,6);
  CHECK(PlanBcnView(a).verdict==V::UseRgba8View);
  CHECK(PlanBcnView(b).verdict==V::UseRgba8View);
  CHECK(PlanBcnView(c).verdict==V::UseRgba8View);
  CHECK(PlanBcnView(d).verdict==V::UseRgba8View);
  CHECK(PlanBcnView(a).view_format==PixelFormat::Rgba8Unorm);
  CHECK(PlanBcnView(c).view_format==PixelFormat::Rgba8Srgb);
  CHECK(!PlanBcnView(c).alters_original_selection);
  a.proof.bcn_decode_completed=false;
  CHECK(PlanBcnView(a).verdict==V::BlockMissingDecodeEvidence);
  a.proof=full_proof; a.proof.decoded_mips_all_uploaded=false;
  CHECK(PlanBcnView(a).verdict==V::BlockMissingDecodeEvidence);
  a.proof=full_proof; a.proof.source_extent_matches_rgba=false;
  CHECK(PlanBcnView(a).verdict==V::BlockMissingDecodeEvidence);
  a.proof=full_proof; a.proof.color_aspect=false;
  CHECK(PlanBcnView(a).verdict==V::BlockMissingDecodeEvidence);
  a.proof=full_proof; a.proof.host_sampled_feature=false;
  CHECK(PlanBcnView(a).verdict==V::BlockInsufficientVulkanSupport);
  a.proof=full_proof; a.proof.host_view_format_feature=false;
  CHECK(PlanBcnView(a).verdict==V::BlockInsufficientVulkanSupport);
  a.proof=full_proof; a.sampled=false;
  CHECK(PlanBcnView(a).verdict==V::BlockBackingFormat);
  a.sampled=true; a.storage=true;
  CHECK(PlanBcnView(a).verdict==V::BlockBackingFormat);
  a.storage=false; a.actual_host_backing=PixelFormat::Bc1Unorm;
  CHECK(PlanBcnView(a).verdict==V::BlockBackingFormat);
  a=base(PixelFormat::Bc1Srgb,PixelFormat::Rgba8Unorm);
  a.proof.mutable_create_flag=false;
  CHECK(PlanBcnView(a).verdict==V::BlockSrgbMutation);
  a.proof=full_proof; a.proof.mutable_view_is_compatible=false;
  CHECK(PlanBcnView(a).verdict==V::BlockSrgbMutation);
  a.proof=full_proof;
  CHECK(PlanBcnView(a).may_create_view());
  CHECK(PlanBcnView(a).alters_original_selection);
  CHECK(PlanBcnView(a).view_format==PixelFormat::Rgba8Srgb);
  a.base_mip=1;
  CHECK(PlanBcnView(a).verdict==V::BlockInvalidRange);
  a.base_mip=0;a.mip_count=0;
  CHECK(PlanBcnView(a).verdict==V::BlockInvalidRange);
  a.mip_count=1;a.base_layer=1;
  CHECK(PlanBcnView(a).verdict==V::BlockInvalidRange);
  a.base_layer=0;a.layer_count=2;
  CHECK(PlanBcnView(a).verdict==V::BlockInvalidRange);
  a.layer_count=1;a.allocated_layers=0;
  CHECK(PlanBcnView(a).verdict==V::BlockInvalidRange);
  auto ordinary=base(PixelFormat::Unknown, PixelFormat::Rgba8Unorm);
  CHECK(PlanBcnView(ordinary).verdict==V::PassThrough);
  CHECK(!PlanBcnView(ordinary).alters_original_selection);
  constexpr std::array<Descriptor,2> mc = {{{{0x10000000ull,0x200000},DescriptorAccess::Sample,true},
                                            {{0x10000000ull,0x280000},DescriptorAccess::StorageAtomic,true}}};
  static_assert(FindFirstHazard(mc.data(),mc.size()).kind == HazardKind::ReadWriteOverlap);
  CHECK(FindFirstHazard(mc.data(),mc.size()).left==0);
  CHECK(FindFirstHazard(mc.data(),mc.size()).right==1);
  CHECK(NeedsShaderSemanticProof(FindFirstHazard(mc.data(),mc.size()).kind));
  constexpr std::array<Descriptor,2> unoverlap = {{{{0,10},DescriptorAccess::Sample,true},
            {{10,10},DescriptorAccess::StorageWrite,true}}};
  CHECK(FindFirstHazard(unoverlap.data(),unoverlap.size()).kind==HazardKind::None);
  auto s=mc; s[1].access=DescriptorAccess::Sample;
  CHECK(FindFirstHazard(s.data(),s.size()).kind==HazardKind::None);
  s=mc;s[0].access=DescriptorAccess::StorageWrite;
  CHECK(FindFirstHazard(s.data(),s.size()).kind==HazardKind::WriteWriteOverlap);
  s[0].has_valid_image=false;
  CHECK(FindFirstHazard(s.data(),s.size()).kind==HazardKind::None);
  s[0].has_valid_image=true;s[0].guest={UINT64_MAX-1,5};
  CHECK(FindFirstHazard(s.data(),s.size()).kind==HazardKind::InvalidRange);
  s=mc;s[0].guest={0,0};
  CHECK(FindFirstHazard(s.data(),s.size()).kind==HazardKind::InvalidRange);
  CHECK(FindFirstHazard<1>(mc.data(),mc.size()).kind==HazardKind::TooManyDescriptors);
  CHECK(FindFirstHazard<64>(nullptr,1).kind==HazardKind::InvalidRange);
  CHECK(FindFirstHazard<64>(nullptr,0).kind==HazardKind::None);
  constexpr std::array<Descriptor,3> three = {{{{100,2},DescriptorAccess::Sample,true},
     {{102,3},DescriptorAccess::Sample,true}, {{100,2},DescriptorAccess::StorageWrite,true}}};
  CHECK(FindFirstHazard(three.data(),three.size()).kind==HazardKind::ReadWriteOverlap);
  CHECK(FindFirstHazard(three.data(),three.size()).left==0);
  CHECK(FindFirstHazard(three.data(),three.size()).right==2);
  CHECK(!NeedsShaderSemanticProof(HazardKind::None));
  std::cout<<"P25 policy tests "<<checks<<"/"<<checks<<" passed\n";
}
