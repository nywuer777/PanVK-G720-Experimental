import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
import port_renderer_p25 as p25
import port_renderer_p26 as p26

class TestPortP26(unittest.TestCase):
    def setUp(self):
        self.mock={
            p26.RELS[0]:'#pragma once\n'+p25.OLD_IMAGE_HEADER+'\n',
            p26.RELS[1]:'#include "video_core/texture_cache/image.h"\n'+p25.OLD_VIEW_HEAD+'\n',
            p26.RELS[2]:'first pass\n'+p25.OLD_RASTER_ANCHOR+'\n'}
    def test_01_fields(self):
        p=p26.transform(self.mock)
        self.assertIn('p26_upload_journal',p[p26.RELS[0]])
        self.assertNotIn('p25_decode_proof{}',p[p26.RELS[0]])
    def test_02_view_provenance(self):
        v=p26.transform(self.mock)[p26.RELS[1]]
        self.assertIn('p26_upload_journal.proof()',v)
        self.assertIn('answer.may_create_view()',v)
        self.assertIn('IsVulkanFormatCompatible',v)
    def test_03_alias_audit(self):
        s=p26.transform(self.mock)[p26.RELS[2]]
        self.assertIn('BachataP26::DecideDispatch(p25_hazard.kind, {})',s)
        self.assertIn('#ifdef BACHATA_P25_GPU_AUDIT',s)
        self.assertIn('gpu_rewrite=0',s)
        self.assertNotIn('{:#x}',s)
    def test_04_fail_closed_missing_header(self):
        m=dict(self.mock);m[p26.RELS[0]]='invalid'
        with self.assertRaises(ValueError):p26.transform(m)
    def test_05_fail_closed_duplicate(self):
        m=dict(self.mock);m[p26.RELS[1]]+=p25.OLD_VIEW_HEAD
        with self.assertRaises(ValueError):p26.transform(m)
    def test_06_fail_closed_repeat(self):
        with self.assertRaises(ValueError):p26.transform(p26.transform(self.mock))
    def test_07_no_original_modification(self):
        before=dict(self.mock);p26.transform(self.mock)
        self.assertEqual(before,self.mock)
    def test_08_headers_present(self):
        p=Path(__file__).resolve().parents[1]/'source'
        for name in ('p24_compatibility.hpp','p25_runtime_binding_gate.hpp','p26_bcn_decoder.hpp',
            'p26_alias_dispatch_gate.hpp','p26_upload_attestation.hpp'):
            self.assertTrue((p/name).is_file())
    def test_09_no_spoof(self):
        s=''.join(p26.transform(self.mock).values())
        self.assertNotIn('return true; // skip',s)
        self.assertNotIn('disable_host',s)
    def test_10_no_gpu_proof_claim(self):
        self.assertIn('full_core_compiled',Path(p26.__file__).read_text())
        self.assertIn('private_f43dev_apk_modified',Path(p26.__file__).read_text())
    def test_11_default_no_completed_proof(self):
        h=(Path(__file__).resolve().parents[1]/'source/p26_upload_attestation.hpp').read_text()
        self.assertIn('State state = State::Fresh',h)
    def test_12_protection_against_alias_unsafe_rewrite(self):
        s=p26.transform(self.mock)[p26.RELS[2]]
        self.assertNotIn('vkCmdCopyImage',s)
        self.assertNotIn('vkCmdPipelineBarrier2',s)
    def test_13_dryrun_and_write_fixture(self):
        from subprocess import run
        from json import loads
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for rel,s in self.mock.items():
                p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
            script=Path(p26.__file__)
            diff=root/'patch.diff'
            cmd=[sys.executable,str(script),'--source-root',str(root),'--out',str(diff),'--synthetic-fixture']
            result=run(cmd,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertTrue(diff.read_text().startswith('--- a/'))
            self.assertTrue(loads(result.stdout)['dry_run'])
            for rel,s in self.mock.items():self.assertEqual((root/rel).read_text(),s)
            result=run(cmd+['--write'],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertFalse(loads(result.stdout)['dry_run'])
            self.assertIn('p26_upload_journal',(root/p26.RELS[0]).read_text())
            self.assertTrue((root/'src/video_core/renderer_vulkan/p26_bcn_decoder.hpp').exists())
            result=run(cmd+['--write'],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
if __name__ == '__main__':unittest.main(verbosity=2)
