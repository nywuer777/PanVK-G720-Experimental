#!/usr/bin/env python3
"""P36 opcode-provenance for actual Shader::ImageResource and diagnostic BindTextures.

Pinned public shadPS4 source ONLY. Does not change Vulkan semantics or build APK.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p35 as p35
import port_renderer_p25 as p25

RESOURCE='src/shader_recompiler/resource.h'
TRACK='src/shader_recompiler/ir/passes/resource_tracking_pass.cpp'
RASTER='src/video_core/renderer_vulkan/vk_rasterizer.cpp'
HEADER='src/video_core/renderer_vulkan/p36_resource_intent.hpp'
ROOT_FILES=[*p35.FILES,RESOURCE,TRACK]
PIN={RESOURCE:'2ac5463d5bc5d215933234ded10dde379c8fa526',TRACK:'b2ca29f6d0073c80dc80848f64a993ae6ba593f8'}

def once(body,old,new,key):
    n=body.count(old)
    if n!=1:raise ValueError(f'P36_{key}_ANCHOR_COUNT_{n}')
    return body.replace(old,new,1)

def transform(inputs):
    out=p35.transform({k:inputs[k] for k in p35.FILES})
    out[RESOURCE]=inputs[RESOURCE]
    out[TRACK]=inputs[TRACK]
    res=out[RESOURCE]
    res=once(res,'    bool is_atomic{};\n    bool is_array{};',
        '    bool is_atomic{};\n    // P36 true opcode provenance from ResourceTrackingPass (not inferred from descriptor type).\n'
        '    bool is_read{};\n    bool is_sampled{};\n    bool is_array{};','resource_fields')
    out[RESOURCE]=res
    track=out[TRACK]
    track=once(track,'        image.is_atomic |= desc.is_atomic;\n        image.is_written |= desc.is_written;',
        '        image.is_atomic |= desc.is_atomic;\n        image.is_written |= desc.is_written;\n'
        '        image.is_read |= desc.is_read;\n        image.is_sampled |= desc.is_sampled;',
        'aggregation')
    track=once(track,'    const bool is_written = inst.GetOpcode() == IR::Opcode::ImageWrite || is_atomic;',
        '    const bool is_written = inst.GetOpcode() == IR::Opcode::ImageWrite || is_atomic;\n'
        '    // P36: atomics are read/modify/write. ImageQuery is metadata only.\n'
        '    const bool is_sampled = inst.GetOpcode() == IR::Opcode::ImageSampleRaw;\n'
        '    const bool is_read = is_sampled || inst.GetOpcode() == IR::Opcode::ImageRead || is_atomic;',
        'ir_instruction_intent')
    track=once(track,'        .is_atomic = is_atomic,\n        .is_array = bool(inst_info.is_array),',
        '        .is_atomic = is_atomic,\n        .is_read = is_read,\n'
        '        .is_sampled = is_sampled,\n        .is_array = bool(inst_info.is_array),',
        'resource_provenance')
    out[TRACK]=track
    rast=out[RASTER]
    rast=once(rast,'#include "video_core/renderer_vulkan/p35_image_alias_probe.hpp"',
              '#include "video_core/renderer_vulkan/p35_image_alias_probe.hpp"\n'
              '#include "video_core/renderer_vulkan/p36_resource_intent.hpp"','includes')
    anchor='    // Second pass to re-bind images that were updated after binding'
    insert='''    // P36_SHADER_OPCODE_PROVENANCE: fail-closed diagnosis of the exact IR-derived
    // ImageRead/ImageSampleRaw/ImageWrite/ImageAtomic intents for active bound resources.
    // This cannot infer per-invocation ordering. NO descriptor, shader, or sync rewrites.
    if (VideoCore::StagingVerbose()) {
        std::array<BachataP36::Binding, BachataP36::MaxBindings> p36_bindings{};
        std::size_t index=0;
        bool overflow=false;
        for (const auto& resource : stage.images) {
            const auto sharp=resource.GetSharp(stage);
            const u32 count=sharp.GetDataFmt()==AmdGpu::DataFormat::FormatInvalid
                ? 1u : resource.NumBindings(stage);
            if (count>BachataP36::MaxBindings ||
                index>BachataP36::MaxBindings-count ||
                index>image_bindings.size() ||
                count>image_bindings.size()-index) {
                overflow=true;
                break;
            }
            for (u32 local=0;local<count;++local,++index) {
                const auto& [image_id,image_desc]=image_bindings[index];
                if (!image_id)continue;
                const auto& resource_image=texture_cache.GetImage(image_id);
                p36_bindings[index]={
                    .begin=static_cast<std::uint64_t>(resource_image.info.guest_address),
                    .bytes=static_cast<std::uint64_t>(resource_image.info.guest_size),
                    .read=resource.is_read,
                    .sampled=resource.is_sampled,
                    .write=resource.is_written,
                    .atomic=resource.is_atomic,
                    .dynamic_mip=resource.mip_fallback_mode==
                        Shader::MipStorageFallbackMode::DynamicIndex,
                    .valid=true,
                };
                (void)image_desc; // The shader IR, not view type, proves read/write intent.
            }
        }
        const auto p36_result=overflow || image_bindings.size()>BachataP36::MaxBindings
            ? BachataP36::Result{BachataP36::Hazard::CapacityExceeded}
            : index!=image_bindings.size()
                ? BachataP36::Result{BachataP36::Hazard::MetadataMismatch}
                : BachataP36::Inspect(
                    std::span<const BachataP36::Binding>(p36_bindings.data(),index),index);
        if (p36_result.kind!=BachataP36::Hazard::None) {
            static std::atomic<u32> p36_observations{0};
            const u32 count=p36_observations.fetch_add(1,std::memory_order_relaxed);
            if (count<16 || count%256==0) {
                LOG_WARNING(Render_Vulkan,
                    "P36_SHADER_PROVENANCE kind={} pair={} {} intra={} atomic={} "
                    "dynamicMip={} irProven=1 descriptorRewrite=0 shaderRewrite=0 "
                    "synchronizationRewrite=0",
                    static_cast<unsigned>(p36_result.kind),p36_result.lhs,
                    p36_result.rhs,p36_result.intra_resource ? 1 : 0,
                    p36_result.atomic_overlap ? 1 : 0,
                    p36_result.dynamic_mip ? 1 : 0);
            }
        }
    }
'''
    rast=once(rast,anchor,insert+anchor,'real_bindtextures_hook')
    out[RASTER]=rast
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path('p36-port.diff'))
    p.add_argument('--write',action='store_true')
    p.add_argument('--synthetic-fixture',action='store_true')
    a=p.parse_args()
    if not a.synthetic_fixture:
        def git(*args):return subprocess.run(['git','-C',str(a.source_root),*args],capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD') != p25.EXPECTED_UPSTREAM:raise ValueError('P36_WRONG_SOURCE_REVISION')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P36_DIRTY_SOURCE')
        for rel,sha in {**p35.p34.p33.p28.IMAGE_SHA_PIN,**PIN}.items():
            if git('hash-object',rel)!=sha:raise ValueError('P36_PINNED_SOURCE_DRIFT:'+rel)
    src={k:(a.source_root/k).read_text() for k in ROOT_FILES}
    dst=transform(src)
    headers={f'src/video_core/renderer_vulkan/{n}':Path(__file__).with_name(n)
             for n in (*p35.p34.p33.p28.p27.HEADERS,*p35.p34.p33.p28.P28_FILES,
                       'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                       'p35_image_alias_probe.hpp','p36_resource_intent.hpp')}
    for k,f in headers.items():
        if not f.is_file() or (a.source_root/k).exists():raise ValueError('P36_HEADER_CONFLICT:'+k)
    diff=''.join(''.join(difflib.unified_diff(src[k].splitlines(True),dst[k].splitlines(True),
          fromfile='a/'+k,tofile='b/'+k)) for k in ROOT_FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(diff)
    if a.write:
        for k,v in dst.items():
            f=a.source_root/k
            f.parent.mkdir(parents=True,exist_ok=True)
            f.write_text(v)
        for path,f in headers.items():
            dest=a.source_root/path
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(f,dest)
    print(json.dumps({'phase':'P36_IR_PROVENANCE_SOURCE_ONLY',
        'source_revision':p25.EXPECTED_UPSTREAM,'shader_ir_intents':True,
        'image_query_is_not_texel_read':True,'atomics_are_rmw':True,
        'shader_or_descriptor_changed':False,'outlast_fixed':False,
        'minecraft_fixed':False,'apk_built':False,
        'patch_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
