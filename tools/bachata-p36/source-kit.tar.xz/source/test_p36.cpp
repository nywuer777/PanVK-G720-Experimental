#include "p36_resource_intent.hpp"
#include <array>
#include <cassert>
#include <iostream>
#include <limits>
using namespace BachataP36;
int main() {
  unsigned n=0;
  auto ck=[&](bool v){assert(v);++n;};
  auto make=[](std::uint64_t at,std::uint64_t len,bool read,bool sample,bool write,bool atom=false,bool dynamic=false) {
    return Binding{at,len,read,sample,write,atom,dynamic,true};
  };
  std::array<Binding,2> a{make(100,100,true,true,false),make(150,100,false,false,true)};
  auto r=Inspect(a,a.size()); ck(r.kind==Hazard::CrossReadWrite); ck(r.lhs==0&&r.rhs==1);
  ck(!r.intra_resource);ck(!r.atomic_overlap);ck(!r.safe_to_rewrite);
  a[0]=make(100,50,true,true,false);ck(Inspect(a,2).kind==Hazard::None);
  a[0]=make(100,100,true,true,true);ck(Inspect(a,2).kind==Hazard::SameResourceReadWrite);
  a[0]=make(100,100,true,false,true,true);a[1]=make(300,100,false,false,true);
  ck(Inspect(a,2).kind==Hazard::None); // standalone atomic remains legal
  a[1]=make(180,100,true,true,false,true); // invalid atomic metadata
  ck(Inspect(a,2).kind==Hazard::InvalidRange);
  a[1]=make(180,100,true,true,true,true);
  r=Inspect(a,2);ck(r.kind==Hazard::CrossAtomic);ck(r.atomic_overlap);
  a[0]=make(100,100,false,false,true); a[1]=make(180,100,false,false,true);
  ck(Inspect(a,2).kind==Hazard::CrossWriteWrite);
  a[1]=make(180,100,true,false,false);ck(Inspect(a,2).kind==Hazard::CrossReadWrite);
  a[1].dynamic_mip=true;r=Inspect(a,2);ck(r.dynamic_mip);
  a[0].valid=false;ck(Inspect(a,2).kind==Hazard::None);
  a[0]=make(0,12,true,true,false);ck(Inspect(a,2).kind==Hazard::InvalidRange);
  a[0]=make(UINT64_MAX-2,5,true,true,false);ck(Inspect(a,2).kind==Hazard::InvalidRange);
  a[0]=make(100,0,true,true,false);ck(Inspect(a,2).kind==Hazard::InvalidRange);
  a[0]=make(100,50,false,true,false);ck(Inspect(a,2).kind==Hazard::InvalidRange);
  a[0]=make(100,100,true,true,false);ck(Inspect(a,1).kind==Hazard::MetadataMismatch);
  ck(Inspect({},0).kind==Hazard::None);
  std::array<Binding,65> over{};ck(Inspect(over,65).kind==Hazard::CapacityExceeded);
  for(unsigned i=1;i<=128;++i) {
    a[0]=make(100,100+i,true,true,false);a[1]=make(200,100,false,false,true);
    ck(Inspect(a,2).kind==Hazard::CrossReadWrite);
  }
  std::cout << "P36_RESOURCE_ACCESS_PROVENANCE_PASS checks=" << n << "\n";
}
