# Bachata F43DEV V2 — P36: proveniência de acesso IR / shader (fonte experimental)

**Alvo de fonte**: `zenithblue-oss/shadps4-arm64` commit `be6bc2e9c60799e071dd2fafa6216e8d80ec619c`. **Não é o core privado da P23**, que continua intacto.

## Alterações

- `ResourceTrackingPass`: preserva `is_read`, `is_plain_read` e `is_sampled` por `Shader::ImageResource`, derivando a intenção diretamente de opcodes `ImageRead`, `ImageSampleRaw`, `ImageWrite` e `ImageAtomic*`.
- `BindTextures`: classificador opcional de sobreposição para recursos efetivamente vinculados. Sinaliza leitura+escrita no mesmo descritor, sobreposição cruzada e operações atômicas, sem expor endereços dos jogos, texturas, tokens, dados do shader ou strings de usuário.
- `ImageQuery*` é apenas metadado; não conta como leitura de texel. Operação atômica isolada não é tratada como conflito automaticamente; operações atômicas combinadas com leituras comuns no mesmo recurso são sinalizadas.
- Limite de 64 recursos, validação de intervalos semiabertos, overflow, índices e assinaturas de recurso inconsistentes. Frequência máxima de log: 16 primeiros eventos e depois um em cada 256.
- Não altera o código SPIR-V, views, descritores, barreiras Vulkan, ordem de comandos, nem resolução. Diagnóstico ativado apenas via `BACHATA_STAGING_VERBOSE`.

**Limitação crítica:** provar se um shader pode observar leitura após escrita entre invocações requer análise de fluxo/semântica e teste real, não somente a lista de opcodes ou os intervalos de memória. **`minecraft_fixed=false` e `outlast_fixed=false`**. Não substituir `shadps4-arm64-fex` da P23 por um binário público recompilado sem auditoria da identidade host, SAF e outros recursos.

## Testes

```
g++ -std=c++20 -Wall -Wextra -Werror -O2 -I. test_p36.cpp -o /tmp/p36 && /tmp/p36
clang++ -std=c++20 -O1 -Wall -Wextra -Werror -fsanitize=address,undefined -I. test_p36.cpp -o /tmp/p36san && /tmp/p36san
python3 -m unittest discover -s . -p 'test_port_p3*.py' -q
```

## Patch

```
python3 port_renderer_p36.py --source-root /path/to/shadps4-arm64-pinned --out p36-port.diff --write
```

O portador exige revisão exata, hashes dos sete arquivos-base, source tree limpo e ausência de headers experimentais prévios. Compilação GLIBC e uso em hardware são gates distintos. Não contém APK, chave, jogo, token ou runtime binário.
