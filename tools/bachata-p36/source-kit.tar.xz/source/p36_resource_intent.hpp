// SPDX-License-Identifier: GPL-2.0-or-later
// P36: Shader::ImageResource access provenance applied to overlapping Vulkan image bindings.
// Observable only. Does NOT authorize snapshots, barriers, descriptor rewrites or assertion removal.
#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>

namespace BachataP36 {
constexpr std::size_t MaxBindings = 64;
enum class Hazard : std::uint8_t {
    None, SameResourceReadWrite, CrossReadWrite, CrossAtomic,
    CrossWriteWrite, InvalidRange, MetadataMismatch, CapacityExceeded
};
struct Binding {
    std::uint64_t begin{};
    std::uint64_t bytes{};
    bool read{};
    bool sampled{};
    bool write{};
    bool atomic{};
    bool dynamic_mip{};
    bool valid{};
};
struct Result {
    Hazard kind{Hazard::None};
    std::uint32_t lhs{};
    std::uint32_t rhs{};
    bool intra_resource{};
    bool atomic_overlap{};
    bool dynamic_mip{};
    bool safe_to_rewrite{false}; // Fixed FALSE pending per-invocation proof.
};
constexpr bool Valid(const Binding& b) {
    if (!b.valid) return true;
    if (b.begin == 0 || b.bytes == 0 || b.begin > UINT64_MAX - b.bytes) return false;
    // atomic must be a read/modify/write; sampled implies reads.
    if ((b.atomic && (!b.read || !b.write)) || (b.sampled && !b.read)) return false;
    return true;
}
constexpr bool Overlap(const Binding& a, const Binding& b) {
    return a.begin < b.begin + b.bytes && b.begin < a.begin + a.bytes;
}
constexpr Result Inspect(std::span<const Binding> spans, std::size_t metadata_count) {
    if (spans.size() > MaxBindings) return {Hazard::CapacityExceeded};
    if (spans.size() != metadata_count) return {Hazard::MetadataMismatch};
    // Prevalidate ALL bindings, not only those before the first hazard.
    for (std::size_t i=0; i<spans.size(); ++i) {
        if (!Valid(spans[i])) return {Hazard::InvalidRange,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(i)};
    }
    for (std::size_t i=0; i<spans.size(); ++i) {
        const auto& a=spans[i];
        if (!a.valid) continue;
        // Atomics by themselves are valid; mixed read+write without an atomic
        // requires shader-level ordering analysis even within one descriptor.
        if (a.read && a.write && !a.atomic)
            return {Hazard::SameResourceReadWrite,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(i),true,false,a.dynamic_mip,false};
        for (std::size_t j=i+1; j<spans.size(); ++j) {
            const auto& b=spans[j];
            if (!b.valid || !Overlap(a,b)) continue;
            const bool read_write=(a.read && b.write)||(b.read && a.write);
            const bool write_write=a.write && b.write;
            if (!read_write && !write_write) continue;
            const bool atom=a.atomic || b.atomic;
            const Hazard kind=atom ? Hazard::CrossAtomic :
                read_write ? Hazard::CrossReadWrite : Hazard::CrossWriteWrite;
            return {kind,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(j),false,atom,a.dynamic_mip||b.dynamic_mip,false};
        }
    }
    return {};
}
} // namespace BachataP36
