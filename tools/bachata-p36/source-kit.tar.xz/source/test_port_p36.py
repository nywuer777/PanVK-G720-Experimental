import json
import sys
import tempfile
import subprocess
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import port_renderer_p36 as p36
from test_port_p33 import P33Port

class P36PortTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        t=P33Port();t.setUpClass()
        cls.fixture={**t.f,
          p36.RESOURCE:'struct ImageResource {\n    bool is_atomic{};\n    bool is_array{};\n};',
          p36.TRACK:'''auto& image=image_resources[index];
        image.is_atomic |= desc.is_atomic;
        image.is_written |= desc.is_written;
const bool is_atomic = IsImageAtomicInstruction(inst);
    const bool is_written = inst.GetOpcode() == IR::Opcode::ImageWrite || is_atomic;
ImageResource image_res = {
        .is_atomic = is_atomic,
        .is_array = bool(inst_info.is_array),
};
'''}
    def test_opcode_provenance_insertions(self):
        d=p36.transform(self.fixture)
        t=d[p36.TRACK]
        for s in ['is_sampled = inst.GetOpcode() == IR::Opcode::ImageSampleRaw',
                  'inst.GetOpcode() == IR::Opcode::ImageRead || is_atomic',
                  'image.is_read |= desc.is_read','image.is_sampled |= desc.is_sampled']:
            self.assertIn(s,t)
        self.assertIn('bool is_read{};',d[p36.RESOURCE])
        self.assertIn('bool is_sampled{};',d[p36.RESOURCE])
    def test_provenance_active_at_runtime(self):
        s=p36.transform(self.fixture)[p36.RASTER]
        for mark in ['P36_SHADER_OPCODE_PROVENANCE','stage.images','resource.is_read',
          'resource.is_sampled','resource.is_atomic','BachataP36::Inspect','P36_SHADER_PROVENANCE',
          'synchronizationRewrite=0','VideoCore::StagingVerbose()']:
            self.assertIn(mark,s)
    def test_no_semantic_rewrites_and_no_game_addresses_in_log(self):
        s=p36.transform(self.fixture)[p36.RASTER]
        tail=s[s.index('"P36_SHADER_PROVENANCE kind='):]
        log=tail[:310]
        self.assertNotIn('guest_address',log)
        self.assertNotIn('pgm_hash',log)
        self.assertNotIn('user_data',log)
        self.assertNotIn('shaderBytes',log)
        self.assertNotIn('vkCmdPipelineBarrier',s[s.index('P36_SHADER_OPCODE_PROVENANCE'):s.index('    // Second pass')])
    def test_output_same_for_other_subsystems(self):
        d=p36.transform(self.fixture)
        prev=p36.p35.transform({k:self.fixture[k] for k in p36.p35.FILES})
        for k in ('src/video_core/texture_cache/image.cpp','src/video_core/texture_cache/image_view.cpp',
                  'src/video_core/texture_cache/texture_cache.cpp','CMakeLists.txt'):
            self.assertEqual(d[k],prev[k])
    def test_source_unmodified(self):
        saved=self.fixture.copy();p36.transform(self.fixture);self.assertEqual(saved,self.fixture)
    def test_double_apply_blocked(self):
        with self.assertRaises(ValueError):p36.transform(p36.transform(self.fixture))
    def test_missing_resource_anchor_blocked(self):
        f=self.fixture.copy();f[p36.RESOURCE]='bad source'
        with self.assertRaises(ValueError):p36.transform(f)
    def test_duplicate_resource_anchor_blocked(self):
        f=self.fixture.copy();f[p36.RESOURCE]*=2
        with self.assertRaises(ValueError):p36.transform(f)
    def test_missing_tracking_anchor_blocked(self):
        f=self.fixture.copy();f[p36.TRACK]='bad source'
        with self.assertRaises(ValueError):p36.transform(f)
    def test_synthetic_fixture_application(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for rel,body in self.fixture.items():
                f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
            cmd=[sys.executable,str(Path(p36.__file__)),'--synthetic-fixture',
                 '--source-root',str(root),'--out',str(root/'p36.diff')]
            o=json.loads(subprocess.run(cmd,check=True,text=True,capture_output=True).stdout)
            self.assertTrue(o['shader_ir_intents']);self.assertFalse(o['minecraft_fixed'])
            self.assertEqual((root/p36.RESOURCE).read_text(),self.fixture[p36.RESOURCE])
            subprocess.run(cmd+['--write'],check=True,text=True,capture_output=True)
            self.assertTrue((root/p36.HEADER).is_file())
            self.assertNotEqual(subprocess.run(cmd+['--write'],text=True,capture_output=True).returncode,0)
    def test_no_false_fix_claim(self):
        src=Path(p36.__file__).read_text()
        for term in ["'minecraft_fixed':False","'outlast_fixed':False","'apk_built':False"]:
            self.assertIn(term,src)

if __name__=='__main__':unittest.main()
