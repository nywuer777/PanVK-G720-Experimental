#!/usr/bin/env python3
"""P38 opt-in inter-dispatch shader-image write->image access barrier.

Public pinned source only. Does NOT fix within-dispatch image aliasing,
shader atomics, texture views or Minecraft's robust-image blocker.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import port_renderer_p37 as p37
import port_renderer_p25 as p25

RASTER=p37.RASTER
RASTER_H='src/video_core/renderer_vulkan/vk_rasterizer.h'
HEADER='src/video_core/renderer_vulkan/p38_interdispatch_barrier.hpp'
EXPECTED_HEADER_SHA='a1dc5fd35250455404fd3b1156101f12492d9d24'
ROOT_FILES=[*p37.ROOT_FILES,RASTER_H]

def exactly_one(src, anchor, replacement, label):
    n=src.count(anchor)
    if n!=1:
        raise ValueError(f'P38_{label}_ANCHOR_COUNT_{n}')
    return src.replace(anchor,replacement,1)

SCAN_AND_BARRIER='''    // P38_INTERDISPATCH_SHADER_IMAGE_BARRIER: optional synchronization only
    // BETWEEN submitted draw/dispatch commands in the SAME Vulkan queue.
    // All evidence is from the P36 IR accesses/P37 intra-block provenance.
    // This cannot repair intra-dispatch aliasing, workgroup races or SPIR-V
    // atomic ordering; the existing robust-image guard stays untouched.
    BachataP38::Intent p38_intent{};
    for (const auto* p38_stage : pipeline->GetStages()) {
        if (!p38_stage) continue;
        for (const auto& p38_res : p38_stage->images) {
            p38_intent.reads |= p38_res.is_read;
            p38_intent.writes |= p38_res.is_written;
            p38_intent.atomic |= p38_res.is_atomic;
            p38_intent.untrusted |= p38_res.p37_order_untrusted;
            const u32 p38_local_hazards=BachataP37::WriteAfterRead |
                BachataP37::ReadAfterWrite | BachataP37::WriteAfterWrite |
                BachataP37::MixedAtomicPlain | BachataP37::AtomicChain |
                BachataP37::CrossBlockUnknown | BachataP37::InvalidBinding |
                BachataP37::CountSaturated;
            p38_intent.unresolved_intra_dispatch |=
                (p38_res.p37_order_mask & p38_local_hazards) != 0 ||
                (p38_res.is_plain_read && p38_res.is_written);
        }
    }
    const auto p38_decision=BachataP38::Plan(
        BachataP38::Enabled(),p38_pending_shader_image_write,p38_intent);
    if (p38_decision.insert_interdispatch_barrier) {
        // End any active rendering scope before inserting a sync2 barrier.
        scheduler.EndRendering();
        const vk::MemoryBarrier2 p38_shader_barrier{
            .srcStageMask=vk::PipelineStageFlagBits2::eAllCommands,
            .srcAccessMask=vk::AccessFlagBits2::eShaderWrite,
            .dstStageMask=vk::PipelineStageFlagBits2::eAllCommands,
            .dstAccessMask=vk::AccessFlagBits2::eShaderRead |
                           vk::AccessFlagBits2::eShaderWrite,
        };
        scheduler.CommandBuffer().pipelineBarrier2(vk::DependencyInfo{
            .memoryBarrierCount=1,
            .pMemoryBarriers=&p38_shader_barrier,
        });
    }
    p38_pending_shader_image_write=p38_decision.pending_shader_image_write;
    if (VideoCore::StagingVerbose() &&
        (p38_decision.insert_interdispatch_barrier ||
         p38_decision.intra_dispatch_unresolved)) {
        static std::atomic<u32> p38_reports{0};
        const u32 p38_seq=p38_reports.fetch_add(1,std::memory_order_relaxed);
        if (p38_seq<16 || p38_seq%256==0) {
            LOG_WARNING(Render_Vulkan,
                "P38_INTERDISPATCH barrier={} optedIn={} priorWritePending={} "
                "intraDispatchUnresolved={} trusted={} "
                "sameDispatchFix=0 aliasSnapshot=0 descriptorRewrite=0",
                p38_decision.insert_interdispatch_barrier ? 1 : 0,
                BachataP38::Enabled() ? 1 : 0,
                p38_pending_shader_image_write ? 1 : 0,
                p38_decision.intra_dispatch_unresolved ? 1 : 0,
                p38_decision.valid_evidence ? 1 : 0);
        }
    }

'''

def transform(src):
    out=p37.transform({key:src[key] for key in p37.ROOT_FILES})
    out[RASTER_H]=src[RASTER_H]
    rast=out[RASTER]
    rast=exactly_one(rast,
        '#include "shader_recompiler/ir/p37_ir_sequence.hpp"',
        '#include "shader_recompiler/ir/p37_ir_sequence.hpp"\n'
        '#include "video_core/renderer_vulkan/p38_interdispatch_barrier.hpp"',
        'INCLUDE')
    anchor='''    if (IsComputeImageCopy(pipeline) || IsComputeMetaClear(pipeline) ||
        IsComputeImageClear(pipeline)) {
        return false;
    }

    set_write_index = 0;'''
    rast=exactly_one(rast,anchor,anchor.replace('    set_write_index = 0;',SCAN_AND_BARRIER+'    set_write_index = 0;'),'BIND_RESOURCES')
    out[RASTER]=rast
    head=out[RASTER_H]
    head=exactly_one(head,'    bool fault_process_pending{};',
        '    // P38: queue-order history, NOT an intra-shader or aliasing proof.\n'
        '    bool p38_pending_shader_image_write{};\n'
        '    bool fault_process_pending{};','TRACKER_FIELD')
    out[RASTER_H]=head
    return out

def run():
    p=argparse.ArgumentParser()
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path('p38.diff'))
    p.add_argument('--write',action='store_true')
    p.add_argument('--synthetic-fixture',action='store_true')
    a=p.parse_args()
    if not a.synthetic_fixture:
        def git(*items):
            return subprocess.run(['git','-C',str(a.source_root),*items],
                                  capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD') != p25.EXPECTED_UPSTREAM:
            raise ValueError('P38_WRONG_PUBLIC_COMMIT')
        if git('status','--porcelain','--untracked-files=no'):
            raise ValueError('P38_DIRTY_SOURCE')
        for path,digest in {**p37.p36.p35.p34.p33.p28.IMAGE_SHA_PIN,
                            **p37.p36.PIN,RASTER_H:EXPECTED_HEADER_SHA}.items():
            if git('hash-object',path)!=digest:
                raise ValueError('P38_SOURCE_HASH_DRIFT:'+path)
    src={path:(a.source_root/path).read_text() for path in ROOT_FILES}
    dst=transform(src)
    additions={f'src/video_core/renderer_vulkan/{h}':Path(__file__).with_name(h)
        for h in (*p37.p36.p35.p34.p33.p28.p27.HEADERS,
                  *p37.p36.p35.p34.p33.p28.P28_FILES,
                  'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                  'p35_image_alias_probe.hpp','p36_resource_intent.hpp','p38_interdispatch_barrier.hpp')}
    additions[p37.HEADER]=Path(__file__).with_name('p37_ir_sequence.hpp')
    for rel,f in additions.items():
        if not f.is_file() or (a.source_root/rel).exists():
            raise ValueError('P38_HEADER_CONFLICT:'+rel)
    diff=''.join(''.join(difflib.unified_diff(src[path].splitlines(True),dst[path].splitlines(True),
        fromfile='a/'+path,tofile='b/'+path)) for path in ROOT_FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(diff)
    if a.write:
        for path,body in dst.items():
            dest=a.source_root/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(body)
        for rel,f in additions.items():
            dest=a.source_root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
    print(json.dumps({'phase':'P38_OPTIONAL_INTERDISPATCH_SHADER_BARRIER',
       'public_revision':p25.EXPECTED_UPSTREAM,'barrier_off_by_default':True,
       'barrier_between_dispatches_only':True,'intra_dispatch_alias_fixed':False,
       'minecraft_fixed':False,'outlast_fixed':False,'apk_produced':False,
       'diff_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))

if __name__=='__main__':run()
