#include "p38_interdispatch_barrier.hpp"
#include <cassert>
#include <cstdio>
using namespace BachataP38;
int main() {
    unsigned tests=0;
    auto expect=[&](bool b) { if(!b) std::abort(); ++tests; };
    const Intent no{};
    const Intent read{.reads=true};
    const Intent write{.writes=true};
    const Intent atomic{.reads=true,.writes=true,.atomic=true};
    const Intent both{.reads=true,.writes=true,.unresolved_intra_dispatch=true};
    auto a=Plan(false,true,read);
    expect(!a.insert_interdispatch_barrier);expect(a.pending_shader_image_write);
    auto b=Plan(true,true,read);
    expect(b.insert_interdispatch_barrier);expect(!b.pending_shader_image_write);
    auto c=Plan(true,false,write);
    expect(!c.insert_interdispatch_barrier);expect(c.pending_shader_image_write);
    auto d=Plan(true,c.pending_shader_image_write,read);
    expect(d.insert_interdispatch_barrier);expect(!d.pending_shader_image_write);
    auto e=Plan(true,true,no);
    expect(!e.insert_interdispatch_barrier);expect(e.pending_shader_image_write);
    auto f=Plan(true,e.pending_shader_image_write,atomic);
    expect(f.insert_interdispatch_barrier);expect(f.pending_shader_image_write);
    auto g=Plan(true,false,both);
    expect(!g.insert_interdispatch_barrier);expect(g.intra_dispatch_unresolved);
    expect(!AuthorizesSameDispatchAliasFix(g));expect(!AuthorizesReplacingRobustImageGuard(g));
    auto h=Plan(true,true,both);
    expect(h.insert_interdispatch_barrier);expect(h.intra_dispatch_unresolved);
    expect(!h.authorizes_snapshot);expect(!h.authorizes_shader_rewrite);
    auto i=Plan(true,true,Intent{.reads=true,.untrusted=true});
    expect(i.insert_interdispatch_barrier);expect(i.intra_dispatch_unresolved);
    expect(!i.valid_evidence);expect(!AuthorizesReplacingRobustImageGuard(i));
    for(unsigned mask=0;mask<256;++mask) for(unsigned prev=0;prev<2;++prev)
        for(unsigned active=0;active<2;++active) {
            Intent in{.reads=bool(mask&1),.writes=bool(mask&2),
                      .atomic=bool(mask&4),.unresolved_intra_dispatch=bool(mask&8),
                      .untrusted=bool(mask&16)};
            auto out=Plan(active,prev,in);
            expect(out.insert_interdispatch_barrier==(active&&prev&&(in.reads||in.writes||in.atomic)));
            expect(out.pending_shader_image_write==((prev&&!out.insert_interdispatch_barrier)||in.writes||in.atomic));
            expect(out.intra_dispatch_unresolved==(in.unresolved_intra_dispatch||in.untrusted));
            expect(!out.authorizes_snapshot&&!out.authorizes_shader_rewrite);
            expect(!AuthorizesSameDispatchAliasFix(out));
        }
    std::printf("P38_INTERDISPATCH_POLICY_PASS checks=%u\n", tests);
}
