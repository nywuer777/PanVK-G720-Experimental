import json,subprocess,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p38 as p38
from test_port_p37 import P37PortTest
class P38PortTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        P37PortTest.setUpClass()
        cls.fixture=P37PortTest.fixture.copy()
        cls.fixture[p38.RASTER_H]='''#pragma once
struct Rasterizer {
    bool fault_process_pending{};
};
'''
        original=cls.fixture[p38.RASTER]
        anchor='''    // Second pass to re-bind images that were updated after binding'''
        cls.fixture[p38.RASTER]=original+'''
bool Rasterizer::BindResources(const Pipeline* pipeline) {
    if (IsComputeImageCopy(pipeline) || IsComputeMetaClear(pipeline) ||
        IsComputeImageClear(pipeline)) {
        return false;
    }

    set_write_index = 0;
}
'''
    def test_barrier_declared_optin(self):
        out=p38.transform(self.fixture)[p38.RASTER]
        for token in ['P38_INTERDISPATCH_SHADER_IMAGE_BARRIER','BachataP38::Enabled()',
                      'p38_pending_shader_image_write','scheduler.EndRendering()',
                      'pipelineBarrier2(vk::DependencyInfo','eShaderRead','eShaderWrite']:
            self.assertIn(token,out)
    def test_no_intrashader_promise(self):
        s=p38.transform(self.fixture)[p38.RASTER]
        for token in ['sameDispatchFix=0','aliasSnapshot=0','descriptorRewrite=0']:
            self.assertIn(token,s)
    def test_trace_existing_unmodified(self):
        out=p38.transform(self.fixture)
        old=p38.p37.transform(self.fixture)
        for file in ['src/video_core/texture_cache/image.cpp',
                     'src/video_core/texture_cache/texture_cache.cpp',
                     'src/shader_recompiler/ir/passes/resource_tracking_pass.cpp',
                     'src/shader_recompiler/resource.h']:
            self.assertEqual(out[file],old[file])
    def test_refuse_double_patch(self):
        with self.assertRaises(ValueError):p38.transform(p38.transform(self.fixture))
    def test_missing_anchor(self):
        fake=self.fixture.copy();fake[p38.RASTER]=fake[p38.RASTER].replace('    set_write_index = 0;','')
        with self.assertRaises(ValueError):p38.transform(fake)
    def test_missing_header_field(self):
        fake=self.fixture.copy();fake[p38.RASTER_H]='bad'
        with self.assertRaises(ValueError):p38.transform(fake)
    def test_duplicate_anchor(self):
        fake=self.fixture.copy();fake[p38.RASTER_H]+='    bool fault_process_pending{};'
        with self.assertRaises(ValueError):p38.transform(fake)
    def test_dryrun_write_and_collision(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name,body in self.fixture.items():
                f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
            cmd=[sys.executable,str(Path(p38.__file__)),'--source-root',str(root),
                 '--out',str(root/'p38.diff'),'--synthetic-fixture']
            result=json.loads(subprocess.run(cmd,text=True,capture_output=True,check=True).stdout)
            self.assertTrue(result['barrier_off_by_default']);self.assertFalse(result['minecraft_fixed'])
            self.assertFalse((root/p38.HEADER).exists())
            subprocess.run(cmd+['--write'],capture_output=True,text=True,check=True)
            self.assertTrue((root/p38.HEADER).exists())
            self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True).returncode,0)
    def test_source_checks(self):
        s=Path(p38.__file__).read_text()
        self.assertIn('EXPECTED_HEADER_SHA',s)
        self.assertIn('P38_WRONG_PUBLIC_COMMIT',s)
        self.assertIn('P38_DIRTY_SOURCE',s)
        self.assertIn('P38_SOURCE_HASH_DRIFT',s)
        self.assertIn("'intra_dispatch_alias_fixed':False",s)

if __name__=='__main__':unittest.main()
