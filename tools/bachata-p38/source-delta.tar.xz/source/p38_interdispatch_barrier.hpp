// SPDX-License-Identifier: GPL-2.0-or-later
// P38: Opt-in *between-dispatch* Vulkan shader-image memory dependency only.
// NEVER authorizes intra-dispatch aliasing, snapshots or shader/descriptor rewriting.
#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstring>

namespace BachataP38 {
struct Intent {
    bool reads{};
    bool writes{};
    bool atomic{};
    bool unresolved_intra_dispatch{};
    bool untrusted{};
};
struct Decision {
    bool insert_interdispatch_barrier{};
    bool pending_shader_image_write{};
    bool intra_dispatch_unresolved{};
    bool valid_evidence{};
    bool authorizes_snapshot{false};
    bool authorizes_shader_rewrite{false};
};
// The environment switch is intentionally opt-in and sampled once; a value other
// than the literal "1" cannot accidentally activate the experimental barrier.
inline bool Enabled() noexcept {
    static const bool enabled = []() noexcept {
        const char* value = std::getenv("BACHATA_P38_INTERDISPATCH_BARRIER");
        return value != nullptr && std::strcmp(value, "1") == 0;
    }();
    return enabled;
}
constexpr Decision Plan(bool opt_in, bool previous_image_write, Intent current) noexcept {
    const bool has_access = current.reads || current.writes || current.atomic;
    const bool barrier = opt_in && previous_image_write && has_access;
    // A barrier only orders commands across dispatch/draw boundaries. It cannot
    // repair an aliasing hazard within a shader invocation or workgroup.
    const bool unresolved = current.unresolved_intra_dispatch || current.untrusted;
    // Preserve write history across draws with no image accesses. After a
    // barrier, the prior writes have been ordered against the current command.
    const bool pending = (previous_image_write && !barrier) || current.writes || current.atomic;
    return {barrier, pending, unresolved, !current.untrusted, false, false};
}
constexpr bool AuthorizesSameDispatchAliasFix(const Decision&) noexcept { return false; }
constexpr bool AuthorizesReplacingRobustImageGuard(const Decision&) noexcept { return false; }
} // namespace BachataP38
