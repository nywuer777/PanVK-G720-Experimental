// SPDX-License-Identifier: GPL-2.0-or-later
// P33 public-core linear BCn fallback acceptance gate. No Vulkan state here.
#pragma once
#include <cstddef>
#include <cstdint>
#include <limits>
#include <algorithm>

namespace BachataP33 {
enum class Format : uint8_t { Unsupported, Bc1Rgb, Bc1Rgba, Bc3 };
enum class Gate : uint8_t { Eligible, UnsupportedFormat, TiledOrVolume, Shape, Bytes, InvalidLayout, HostUnavailable };
struct Input {
    Format format = Format::Unsupported;
    bool srgb = false;
    bool tiled = false;
    bool volume = false;
    bool image_format_supported = true;
    bool rgba_host_supported = false;
    uint32_t width=0, height=0, mips=0, layers=0, samples=0;
    uint32_t guest_bits=0;
};
struct Mip {
    size_t offset=0, bytes=0;
    uint32_t pitch_pixels=0;
    uint32_t height_pixels=0;
};
constexpr bool Mul(size_t a, size_t b, size_t& out) {
    if (b && a > std::numeric_limits<size_t>::max()/b) return false;
    out=a*b;return true;
}
constexpr Gate Eligible(const Input& in) {
    if (in.format==Format::Unsupported) return Gate::UnsupportedFormat;
    if (in.tiled || in.volume) return Gate::TiledOrVolume;
    if (!in.width || !in.height || in.width>16384 || in.height>16384 ||
        !in.mips || in.mips>16 || in.layers!=1 || in.samples!=1) return Gate::Shape;
    if ((in.format==Format::Bc3 ? in.guest_bits!=128 : in.guest_bits!=64)) return Gate::Bytes;
    if (in.image_format_supported || !in.rgba_host_supported) return Gate::HostUnavailable;
    return Gate::Eligible;
}
struct LayoutResult { Gate gate=Gate::InvalidLayout; size_t row_stride=0, required_bytes=0; };
constexpr LayoutResult CheckMip(const Input& in, const Mip& m, size_t guest_size, uint32_t level) {
    if (Eligible(in)!=Gate::Eligible || level>=in.mips) return {};
    const uint32_t w=std::max(1u,in.width>>level), h=std::max(1u,in.height>>level);
    if ((m.pitch_pixels & 3u) || m.pitch_pixels < ((w+3u)/4u)*4u ||
        m.height_pixels < ((h+3u)/4u)*4u ||
        m.offset>guest_size || m.bytes>guest_size-m.offset) return {};
    size_t row=0, last_row=0, need=0;
    const size_t bs=(in.format==Format::Bc3 ? 16u : 8u), blocks=(w+3u)/4u;
    if (!Mul(size_t(m.pitch_pixels)/4u,bs,row) ||
        !Mul(size_t((h+3u)/4u)-1u,row,last_row) ||
        !Mul(blocks,bs,need) || last_row>std::numeric_limits<size_t>::max()-need)
        return {};
    need+=last_row;
    if (need>m.bytes) return {};
    return {Gate::Eligible,row,need};
}
} // namespace BachataP33
