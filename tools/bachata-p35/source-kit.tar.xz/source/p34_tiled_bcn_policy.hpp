// SPDX-License-Identifier: GPL-2.0-or-later
// P34 restricted BCn 1D-tiled detile -> CPU decode gate; no Vulkan calls here.
#pragma once
#include "p33_bcn_linear_policy.hpp"
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
namespace BachataP34 {
enum class Status : unsigned char { Eligible, WrongFormat, UnsupportedTiling, Shape,
                                   HostUnavailable, ScratchTooSmall, InvalidMip, Overflow };
struct Input {
    BachataP33::Format format=BachataP33::Format::Unsupported;
    bool is_tiled=false;
    bool exactly_1d_tiled_thin1=false;
    bool volume=false;
    bool host_bcn_supported=true;
    bool host_rgba_supported=false;
    uint32_t width=0,height=0,mips=0,layers=0,samples=0,guest_bits=0;
    size_t guest_bytes=0;
};
constexpr Status Eligible(const Input& in) {
    if(in.format==BachataP33::Format::Unsupported) return Status::WrongFormat;
    if(!in.is_tiled || !in.exactly_1d_tiled_thin1 || in.volume)
        return Status::UnsupportedTiling;
    if(!in.width||!in.height||in.width>16384||in.height>16384||
       !in.mips||in.mips>16||in.layers!=1||in.samples!=1)
        return Status::Shape;
    if((in.format==BachataP33::Format::Bc3 ? in.guest_bits!=128 : in.guest_bits!=64))
        return Status::WrongFormat;
    if(in.host_bcn_supported||!in.host_rgba_supported) return Status::HostUnavailable;
    // TileManager's dispatch count is (guestBytes/(bitsPerBlock/8))/64.
    // If zero, it would submit an invalid compute dispatch and leave data unreadable.
    const size_t block_bytes=in.guest_bits/8u;
    if(in.guest_bytes<64*block_bytes || in.guest_bytes>256u*1024u*1024u ||
       in.guest_bytes%(64*block_bytes)!=0)
        return Status::ScratchTooSmall;
    return Status::Eligible;
}
struct Mip {size_t offset=0,bytes=0;uint32_t pitch_pixels=0,height_pixels=0;};
// The TileManager reports mip pitches in BLOCKS after constructing its compute
// parameters. ImageInfo keeps PIXEL pitch; feed that here, then validate the
// linearized block-row offset/range before CPU decode.
constexpr Status ValidateMip(const Input& in,const Mip& m,uint32_t mip) {
    if(Eligible(in)!=Status::Eligible || mip>=in.mips) return Status::InvalidMip;
    const uint32_t w=std::max(1u,in.width>>mip),h=std::max(1u,in.height>>mip);
    const uint32_t cols=(w+3u)/4u,rows=(h+3u)/4u;
    if(m.pitch_pixels%4u || m.pitch_pixels/4u<cols || m.height_pixels/4u<rows)
        return Status::InvalidMip;
    if(m.offset>in.guest_bytes || m.bytes>in.guest_bytes-m.offset) return Status::InvalidMip;
    const size_t block_bytes=in.guest_bits/8u;
    size_t stride{};
    if(!BachataP33::Mul(m.pitch_pixels/4u,block_bytes,stride))return Status::Overflow;
    size_t before{};
    if(!BachataP33::Mul(rows-1u,stride,before))return Status::Overflow;
    if(cols>std::numeric_limits<size_t>::max()/block_bytes)return Status::Overflow;
    const size_t needed=cols*block_bytes;
    if(before>std::numeric_limits<size_t>::max()-needed)return Status::Overflow;
    return before+needed<=m.bytes ? Status::Eligible : Status::InvalidMip;
}
}
