#!/usr/bin/env python3
"""Fail-closed, source-only P25 port to pinned public ARM64 core.

NOT a port into the unmatched F43DEV binary; no asserts removed, no APK signed.
Default audit mode only; --write must be explicitly supplied. Does not read private files.
"""
import argparse
import difflib
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

EXPECTED_UPSTREAM = 'be6bc2e9c60799e071dd2fafa6216e8d80ec619c'
SOURCE_FOLDER = Path('src/video_core')

OLD_IMAGE_HEADER = 'struct BackingImage {\n        UniqueImage image;\n        State state;'
NEW_IMAGE_HEADER = '''struct BackingImage {
        UniqueImage image;
        // P25: decoder must explicitly attest that BCn texels have been fully
        // transformed into RGBA before a decoded sampled view is permitted.
        BachataP25::Provenance p25_decode_proof{};
        State state;'''

OLD_VIEW_HEAD = '    const vk::ImageViewCreateInfo image_view_ci = {'
NEW_VIEW_HEAD = '''    // P25: explicit BCn-decoder provenance; original upstream has no setter.
    // A decoded image view is not legal merely because a format resembles RGBA.
    const auto to_p25_format = [](vk::Format fmt) -> BachataP24::PixelFormat {
        switch (fmt) {
        case vk::Format::eBc1RgbaUnormBlock:
        case vk::Format::eBc1RgbUnormBlock: return BachataP24::PixelFormat::Bc1Unorm;
        case vk::Format::eBc1RgbaSrgbBlock:
        case vk::Format::eBc1RgbSrgbBlock: return BachataP24::PixelFormat::Bc1Srgb;
        case vk::Format::eBc3UnormBlock: return BachataP24::PixelFormat::Bc3Unorm;
        case vk::Format::eBc3SrgbBlock: return BachataP24::PixelFormat::Bc3Srgb;
        case vk::Format::eR8G8B8A8Unorm: return BachataP24::PixelFormat::Rgba8Unorm;
        case vk::Format::eR8G8B8A8Srgb: return BachataP24::PixelFormat::Rgba8Srgb;
        default: return BachataP24::PixelFormat::Unknown;
        }
    };
    const auto p25_guest_format = to_p25_format(format);
    const auto p25_host_format = to_p25_format(image.backing->image.image_ci.format);
    if (BachataP24::IsBc(p25_guest_format) && BachataP24::IsRgba(p25_host_format)) {
        // The source revision audited in P25 has no BCn decode completion hook.
        // The default proof is therefore FALSE; no fictitious repair is claimed.
        auto proof = image.backing->p25_decode_proof;
        proof.host_sampled_feature = instance.IsFormatSupported(
            image.backing->image.image_ci.format, vk::FormatFeatureFlagBits2::eSampledImage);
        const vk::Format desired = BachataP24::IsSrgb(p25_guest_format)
            ? vk::Format::eR8G8B8A8Srgb : vk::Format::eR8G8B8A8Unorm;
        proof.host_view_format_feature = instance.IsFormatSupported(
            desired, vk::FormatFeatureFlagBits2::eSampledImage);
        proof.mutable_create_flag = static_cast<bool>(
            image.backing->image.image_ci.flags & vk::ImageCreateFlagBits::eMutableFormat);
        proof.mutable_view_is_compatible =
            image.backing->image.image_ci.format == desired ||
            IsVulkanFormatCompatible(image.backing->image.image_ci.format, desired);
        const BachataP25::ViewInputs request{
            p25_guest_format, p25_host_format, !info.is_storage, info.is_storage,
            info.range.base.level, info.range.extent.levels,
            image.backing->image.image_ci.mipLevels,
            info.range.base.layer, info.range.extent.layers,
            image.backing->image.image_ci.arrayLayers, proof};
        const auto answer = BachataP25::PlanBcnView(request);
        ASSERT_MSG(answer.may_create_view(),
                   "P25 decoded BCn sampled view blocked: missing verified decoder or format proof");
        ASSERT_MSG(instance.GetSupportedFormat(desired, image.format_features) == desired,
                   "P25 RGBA view format does not satisfy required features");
        format = desired;
    }

    const vk::ImageViewCreateInfo image_view_ci = {'''

OLD_RASTER_ANCHOR = '    // Second pass to re-bind images that were updated after binding'
NEW_RASTER_ANCHOR = '''#ifdef BACHATA_P25_GPU_AUDIT
    // P25 opt-in source audit ONLY: detection does not authorize snapshot,
    // descriptor rewrites or additional barriers. Do not log guest addresses.
    boost::container::small_vector<BachataP25::Descriptor, 32> p25_desc;
    for (const auto& [img_id, img_desc] : image_bindings) {
        if (!img_id) {
            p25_desc.emplace_back(BachataP25::Descriptor{{},
                BachataP25::DescriptorAccess::Sample, false});
            continue;
        }
        const auto& img = texture_cache.GetImage(img_id);
        const bool is_storage = img_desc.type == VideoCore::TextureCache::BindingType::Storage;
        p25_desc.emplace_back(BachataP25::Descriptor{
            {static_cast<uint64_t>(img.info.guest_address),
             static_cast<uint64_t>(img.info.guest_size)},
            is_storage ? BachataP25::DescriptorAccess::StorageWrite
                       : BachataP25::DescriptorAccess::Sample, true});
    }
    const auto p25_hazard = BachataP25::FindFirstHazard<4096>(
        p25_desc.data(), p25_desc.size());
    if (p25_hazard.kind != BachataP25::HazardKind::None) {
        // No addresses, image contents or private arguments are emitted.
        LOG_WARNING(Render_Vulkan, "P25_BIND_HAZARD type={} pair={} {}, classification-only",
                    static_cast<unsigned>(p25_hazard.kind), p25_hazard.left, p25_hazard.right);
    }
#endif
    // Second pass to re-bind images that were updated after binding'''


def replace_one(text, old, new, name):
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{name}: expected one anchor; got {count}')
    return text.replace(old, new, 1)


def transform(mapping):
    h = mapping['src/video_core/texture_cache/image.h']
    h = replace_one(h, '#pragma once\n', '#pragma once\n#include "video_core/renderer_vulkan/p25_runtime_binding_gate.hpp"\n', 'image.h header')
    h = replace_one(h, OLD_IMAGE_HEADER, NEW_IMAGE_HEADER, 'image.h backing')
    mapping['src/video_core/texture_cache/image.h'] = h

    v = mapping['src/video_core/texture_cache/image_view.cpp']
    v = replace_one(v, '#include "video_core/texture_cache/image.h"',
        '#include "video_core/texture_cache/image.h"\n#include "video_core/texture_cache/host_compatibility.h"',
        'image_view.cpp include')
    v = replace_one(v, OLD_VIEW_HEAD, NEW_VIEW_HEAD, 'image_view.cpp view creation')
    mapping['src/video_core/texture_cache/image_view.cpp'] = v

    r = mapping['src/video_core/renderer_vulkan/vk_rasterizer.cpp']
    r = replace_one(r, OLD_RASTER_ANCHOR, NEW_RASTER_ANCHOR, 'vk_rasterizer.cpp pass')
    mapping['src/video_core/renderer_vulkan/vk_rasterizer.cpp'] = r
    return mapping


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--out', type=Path, default=Path('p25-port.diff'))
    ap.add_argument('--write', action='store_true', help='Mutate pinned public core sources, no binaries')
    ap.add_argument('--synthetic-fixture', action='store_true', help='Test-only mocked tree, no Git check')
    args = ap.parse_args()
    if not args.synthetic_fixture:
        g = subprocess.run(['git','-C',str(args.source_root),'rev-parse','HEAD'],
                           capture_output=True, text=True, check=True).stdout.strip()
        if g != EXPECTED_UPSTREAM:
            raise ValueError(f'WRONG_SOURCE_REVISION (expected {EXPECTED_UPSTREAM})')
    rels = ['src/video_core/texture_cache/image.h',
            'src/video_core/texture_cache/image_view.cpp',
            'src/video_core/renderer_vulkan/vk_rasterizer.cpp']
    source = {rel:(args.source_root/rel).read_text() for rel in rels}
    output = transform(dict(source))
    additions = {
        'src/video_core/renderer_vulkan/p24_compatibility.hpp':Path(__file__).with_name('p24_compatibility.hpp'),
        'src/video_core/renderer_vulkan/p25_runtime_binding_gate.hpp':Path(__file__).with_name('p25_runtime_binding_gate.hpp')}
    for rel,p in additions.items():
        if (args.source_root/rel).exists():raise ValueError(f'EXISTING_TARGET_BLOCKED {rel}')
    diff = ''.join(''.join(difflib.unified_diff(source[k].splitlines(True),output[k].splitlines(True),
         fromfile='a/'+k,tofile='b/'+k)) for k in rels)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(diff)
    if args.write:
        for rel,text in output.items(): (args.source_root/rel).write_text(text)
        for rel,p in additions.items():
            dest=args.source_root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    print(json.dumps({'revision':EXPECTED_UPSTREAM,'patched_files':rels,
          'added_files':list(additions),'dry_run':not args.write,
          'patch_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
