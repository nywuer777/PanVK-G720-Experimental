import sys,unittest,tempfile,subprocess,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_port_p33 import P33Port
import port_renderer_p34 as p34
ROOT=Path(__file__).resolve().parent
class P34SourcePort(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  t=P33Port();t.setUpClass();cls.fixture=t.f
 def test_fallback_provenance(self):
  im=p34.transform(self.fixture)['src/video_core/texture_cache/image.cpp']
  for marker in ('p34_tiled_bcn_fallback','Array1DTiledThin1',
                 'IsFormatSupported(p33_rgba,format_features)',
                 'P34_BCN_1D_TILED_RGBA_SELECTED'):
   self.assertIn(marker,im)
 def test_active_upload_and_detile(self):
  tc=p34.transform(self.fixture)['src/video_core/texture_cache/texture_cache.cpp']
  for marker in ('P34_GPUTILE_DETILE_READBACK','tile_manager.DetileImage(',
                 'cmdbuf.copyBuffer(', 'scheduler.Finish()',
                 'vmaInvalidateAllocation(', 'BachataP27::UploadDecodedToRgba(',
                 'BachataP34::ValidateMip(', 'P34_BCN_UPLOAD_ACTIVE'):
   self.assertIn(marker,tc)
 def test_protection(self):
  p=p34.transform(self.fixture)
  tc=p['src/video_core/texture_cache/texture_cache.cpp']
  self.assertIn('ImageFlagBits::GpuModified',tc)
  self.assertIn('image.info.array_mode==AmdGpu::ArrayMode::Array1DTiledThin1',tc)
  self.assertIn('srcStageMask=vk::PipelineStageFlagBits2::eComputeShader',tc)
  self.assertIn('dstStageMask=vk::PipelineStageFlagBits2::eHost',tc)
  self.assertIn('P25 decoded BCn sampled view blocked',p['src/video_core/texture_cache/image_view.cpp'])
  self.assertIn('P26_ALIAS_POLICY',p['src/video_core/renderer_vulkan/vk_rasterizer.cpp'])
 def test_fail_double(self):
  with self.assertRaises(ValueError):p34.transform(p34.transform(self.fixture))
 def test_duplicate_anchor_fails(self):
  f=self.fixture.copy();f['src/video_core/texture_cache/texture_cache.cpp']*=2
  with self.assertRaises(ValueError):p34.transform(f)
 def test_missing_anchor_fails(self):
  f=self.fixture.copy();f['src/video_core/texture_cache/image.cpp']='broken'
  with self.assertRaises(ValueError):p34.transform(f)
 def test_not_mutate_input(self):
  before=self.fixture.copy();p34.transform(self.fixture);self.assertEqual(before,self.fixture)
 def test_synthetic_write(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)
   for name,data in self.fixture.items():
    dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(data)
   cmd=[sys.executable,str(ROOT/'port_renderer_p34.py'),'--source-root',str(root),
        '--out',str(root/'P34.patch'),'--synthetic-fixture']
   x=subprocess.run(cmd,capture_output=True,text=True,check=True)
   self.assertTrue(json.loads(x.stdout)['tiled_1d_detile_readback_hooked'])
   self.assertEqual((root/'src/video_core/texture_cache/texture_cache.cpp').read_text(),self.fixture['src/video_core/texture_cache/texture_cache.cpp'])
   subprocess.run(cmd+['--write'],capture_output=True,text=True,check=True)
   self.assertTrue((root/'src/video_core/renderer_vulkan/p34_tiled_bcn_policy.hpp').exists())
   self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True).returncode,0)
 def test_no_p23_changes(self):
  s=(ROOT/'port_renderer_p34.py').read_text()
  for v in ('apktool','apksigner','robustImageAccess2','HOST_IDENTITY_ACCEPT_ANY',
            'bypass_assertions','--bachata-saf-token'):
   self.assertNotIn(v,s)
 def test_tiled_policy_requires_dispatch_multiple(self):
  s=(ROOT/'p34_tiled_bcn_policy.hpp').read_text()
  self.assertIn('guest_bytes%(64*block_bytes)!=0',s)
 def test_no_device_claim(self):
  s=(ROOT/'port_renderer_p34.py').read_text()
  self.assertIn("'outlast_fixed':False",s)
  self.assertIn("'minecraft_fixed':False",s)
if __name__=='__main__': unittest.main(verbosity=2)
