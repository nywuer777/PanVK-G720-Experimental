# P35 — Relatório de execução

- P33: core público AArch64/GLIBC compilou no GitHub Actions, job concluído com sucesso, execução 39051744190.
- P34: no início da P35, o pré-build público passou; o build AArch64/GLIBC ainda estava em execução, run 39053510985.
- P35: inserção real de diagnóstico somente em `Rasterizer::BindTextures()`, classificando overlap e sinalizando recursos atômicos e mip dinâmico usando metadados do shader. Execução restrita ao modo `StagingVerbose()`; sem endereços do jogo nos logs.
- P35: testes C++ 56/56 com GCC, Clang ASan/UBSan. Python `test_port_p3*.py` 53 testes OK. Ainda não é validação em hardware.
- P23 funcional preservada SHA-256 `2806f93e9f4346dda5c796462c3d916fb021e2dc942fa2e7366dc78c265c62b6`.
- P35 Minecraft fixed = false; Outlast fixed = false; APK compilado = não.
- Aplicação no fork privado F43DEV não comprovada; não substituir o binário P23.
