#!/usr/bin/env python3
"""Source-only P27 port on pinned upstream be6bc2e9 (NOT F43DEV executable).

Extends P26 with a *callable* Vulkan upload adapter and a corrected upload-byte
barrier, compiled only by a future full-source build. No automatic BCn fallback.
"""
import argparse, difflib, hashlib, json, shutil, subprocess
from pathlib import Path
import port_renderer_p26 as p26
import port_renderer_p25 as p25

BASE = 'src/video_core/'
SRC_CPP = BASE + 'texture_cache/image.cpp'
SRC_H = BASE + 'texture_cache/image.h'
CMAKE = 'CMakeLists.txt'
RELS = p26.RELS + [SRC_CPP, CMAKE]
HEADERS = ('p24_compatibility.hpp','p25_runtime_binding_gate.hpp',
           'p26_bcn_decoder.hpp','p26_alias_dispatch_gate.hpp','p26_upload_attestation.hpp',
           'p27_upload_plan.hpp','p27_shader_dependency.hpp','p27_vk_decoded_upload.hpp',
           'p27_vk_decoded_upload.cpp')

def replace_once(c,old,new,label):
    n=c.count(old)
    if n!=1:raise ValueError(f'{label}: required single anchor; got {n}')
    return c.replace(old,new,1)

def transform(inputs):
    result=p26.transform({key:inputs[key] for key in p26.RELS})
    h=result[SRC_H]
    h=replace_once(h,
      'void Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer, u64 offset);',
      'void Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,\n'
      '                u64 offset, u64 decoded_source_bytes = 0);', 'upload api')
    result[SRC_H]=h
    cpp=inputs[SRC_CPP]
    # Any future GPU write invalidates decoded provenance, even when the
    # image remains bound. A later upload must re-attest after GPU completion.
    cpp=replace_once(cpp,
      'void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,\n'
      '                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {',
      'void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,\n'
      '                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {\n'
      '    constexpr vk::AccessFlags2 writes = vk::AccessFlagBits2::eShaderWrite |\n'
      '        vk::AccessFlagBits2::eColorAttachmentWrite |\n'
      '        vk::AccessFlagBits2::eDepthStencilAttachmentWrite |\n'
      '        vk::AccessFlagBits2::eTransferWrite;\n'
      '    if (backing && (dst_mask & writes)) backing->p26_upload_journal.invalidate();',
      'write transition invalidation')
    cpp=replace_once(cpp,
      'void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,\n                   u64 offset) {\n    SetBackingSamples(info.num_samples, false);',
      'void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,\n'
      '                   u64 offset, u64 decoded_source_bytes) {\n'
      '    // Every general upload invalidates prior decoded-BCn provenance.\n'
      '    if (backing) backing->p26_upload_journal.invalidate();\n'
      '    const u64 upload_source_bytes = decoded_source_bytes ? decoded_source_bytes : info.guest_size;\n'
      '    SetBackingSamples(info.num_samples, false);', 'upload definition')
    # Restrict byte-size replacements to the upload function, keeping other paths untouched.
    start=cpp.index('void Image::Upload(');end=cpp.index('void Image::Download(',start)
    segment=cpp[start:end]
    old_size='        .size = info.guest_size,'
    if segment.count(old_size)!=2:
        raise ValueError(f'upload barrier sizes: expected exactly 2; got {segment.count(old_size)}')
    segment=segment.replace(old_size,'        .size = upload_source_bytes,')
    cpp=cpp[:start]+segment+cpp[end:]
    result[SRC_CPP]=cpp
    cmake=inputs[CMAKE]
    cmake=replace_once(cmake,'               src/video_core/renderer_vulkan/vk_rasterizer.cpp',
        '               src/video_core/renderer_vulkan/vk_rasterizer.cpp\n'
        '               src/video_core/renderer_vulkan/p27_vk_decoded_upload.cpp',
        'cmake source')
    result[CMAKE]=cmake
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root',type=Path,required=True)
    ap.add_argument('--out',type=Path,default=Path('p27-port.diff'))
    ap.add_argument('--write',action='store_true')
    ap.add_argument('--synthetic-fixture',action='store_true',help='offline-only test fixture')
    args=ap.parse_args()
    if not args.synthetic_fixture:
        ref=subprocess.run(['git','-C',str(args.source_root),'rev-parse','HEAD'],
            capture_output=True,text=True,check=True).stdout.strip()
        if ref!=p25.EXPECTED_UPSTREAM:raise ValueError('WRONG_SOURCE_REVISION')
        dirty=subprocess.run(['git','-C',str(args.source_root),'status','--porcelain',
                              '--untracked-files=no'],capture_output=True,text=True,check=True)
        if dirty.stdout.strip(): raise ValueError('DIRTY_SOURCE_WORKTREE')
    original={rel:(args.source_root/rel).read_text() for rel in RELS}
    patch=transform(original)
    additions={f'{BASE}renderer_vulkan/{name}':Path(__file__).with_name(name) for name in HEADERS}
    for k in additions:
        if (args.source_root/k).exists(): raise ValueError('EXISTING_TARGET_BLOCKED: '+k)
    diff=''.join(''.join(difflib.unified_diff(original[k].splitlines(True),patch[k].splitlines(True),
        fromfile='a/'+k,tofile='b/'+k)) for k in RELS)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(diff)
    if args.write:
        for rel,value in patch.items():(args.source_root/rel).write_text(value)
        for rel,src in additions.items():
            dst=args.source_root/rel;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
    print(json.dumps({'stage':'P27','source_pin':p25.EXPECTED_UPSTREAM,'write':args.write,
        'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),
        'source_changes':RELS,'new_files':sorted(additions),
        'vulkan_production_build':False,'f43dev_apk_modified':False},sort_keys=True))
if __name__=='__main__':main()
