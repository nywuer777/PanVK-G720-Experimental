// SPDX-License-Identifier: GPL-2.0-or-later
// P28 portable GPU timeline state model. A scheduled upload is not a completed upload.
#pragma once
#include <cstdint>
namespace BachataP28 {
enum class PollStatus : uint8_t {
    InvalidTicket, StaleImage, NotSubmitted, GpuPending, Completed
};
struct Ticket {
    uint64_t timeline_tick=0;
    uint64_t image_uid=0;
    uint64_t backing_tag=0;
    uint32_t generation=0;
    uint32_t mip_levels=0;
    uint32_t array_layers=0;
    bool active=false;
};
constexpr PollStatus PollState(Ticket& ticket, uint64_t current_tick,
        bool timeline_signaled, uint64_t image_uid, uint64_t backing_tag,
        uint32_t journal_generation, bool journal_submitted) {
    if (!ticket.active || !ticket.timeline_tick || !ticket.generation)
        return PollStatus::InvalidTicket;
    if (image_uid != ticket.image_uid || backing_tag != ticket.backing_tag ||
        journal_generation != ticket.generation || !journal_submitted) {
        ticket.active=false;
        return PollStatus::StaleImage;
    }
    // CurrentTick advances ONLY when the scheduler records a submission.
    if (current_tick <= ticket.timeline_tick) return PollStatus::NotSubmitted;
    if (!timeline_signaled) return PollStatus::GpuPending;
    ticket.active=false;
    return PollStatus::Completed;
}
}
