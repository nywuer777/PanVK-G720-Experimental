#!/usr/bin/env python3
"""P29: fail-closed build gate for pinned public Bachata GLIBC ARM64 core.

This does not turn a public core build into an installable F43DEV V2 runtime.
No APK or original native binary is modified by this tool.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

PIN = 'be6bc2e9c60799e071dd2fafa6216e8d80ec619c'
REQUIRED_BLOBS = {
    'src/video_core/texture_cache/image.h': '6af58cbbece05a32aafd1a8a3f93c6b775f9ee9c',
    'src/video_core/texture_cache/image.cpp': 'a227c5d8d0c460a35c29df2cbb964eca61d1dfa3',
    'src/video_core/texture_cache/image_view.cpp': '28f6e17e34b7e950f3234c8bc3abd72b46f032bf',
    'src/video_core/renderer_vulkan/vk_rasterizer.cpp': '99db69505bd3b5e34e5e49251a9b94955f51f081',
    'CMakeLists.txt': 'e56c54a142c5c1dbee1818574dfaf20ae4724408',
}
SOURCE_FILES = (
    'p24_compatibility.hpp', 'p25_runtime_binding_gate.hpp',
    'p26_alias_dispatch_gate.hpp', 'p26_bcn_decoder.hpp',
    'p26_upload_attestation.hpp', 'p27_shader_dependency.hpp',
    'p27_upload_plan.hpp', 'p27_vk_decoded_upload.hpp',
    'p27_vk_decoded_upload.cpp', 'p28_async_ticket.hpp',
    'p28_vk_async_upload.hpp', 'p28_vk_async_upload.cpp',
    'port_renderer_p25.py', 'port_renderer_p26.py',
    'port_renderer_p27.py', 'port_renderer_p28.py',
)
EXPECTED_ELF = 'runtime/build/shadps4-arm64-stage/bin/shadps4-arm64'


class GateFailure(Exception):
    pass


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def run_cmd(args, *, cwd=None, log=None, timeout=None):
    p = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, text=True, errors='replace',
                       timeout=timeout, check=False)
    if log is not None:
        # Do not record environment variables or commands carrying secrets.
        log.write_text(p.stdout[-10_000_000:])
    if p.returncode:
        raise GateFailure(f'COMMAND_FAILED:{Path(args[0]).name}:{p.returncode}')
    return p.stdout.strip()


def verify_kit(kit: Path) -> dict:
    if not kit.is_dir():
        raise GateFailure('SOURCE_KIT_MISSING')
    missing = sorted(name for name in SOURCE_FILES if not (kit/name).is_file())
    if missing:
        raise GateFailure('SOURCE_KIT_INCOMPLETE:'+','.join(missing))
    bad = []
    for file in kit.glob('*.py'):
        try:
            compile(file.read_bytes(), str(file), 'exec')
        except SyntaxError:
            bad.append(file.name)
    if bad:
        raise GateFailure('SOURCE_KIT_INVALID_PYTHON:'+','.join(sorted(bad)))
    port = (kit/'port_renderer_p28.py').read_text()
    if PIN not in port and 'EXPECTED_UPSTREAM' not in port:
        raise GateFailure('SOURCE_PIN_NOT_PRESENT')
    if 'IMAGE_SHA_PIN' not in port or '--write' not in port:
        raise GateFailure('SOURCE_PORT_GATES_MISSING')
    return {name: digest_file(kit/name) for name in SOURCE_FILES}


def verify_checkout(root: Path) -> None:
    if not (root/'.git').exists():
        raise GateFailure('NOT_A_GIT_CHECKOUT')
    if run_cmd(['git', 'rev-parse', 'HEAD'], cwd=root) != PIN:
        raise GateFailure('WRONG_SOURCE_REVISION')
    # Fail on tracked edits and foreign untracked files in the target source dirs.
    if run_cmd(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=root):
        raise GateFailure('DIRTY_CHECKOUT')
    for name, expected in REQUIRED_BLOBS.items():
        actual = run_cmd(['git','hash-object',name], cwd=root)
        if actual != expected:
            raise GateFailure('SOURCE_BLOB_MISMATCH:'+name)
    if not (root/'runtime/scripts/build-shadps4-arm64.sh').is_file():
        raise GateFailure('BUILD_SCRIPT_MISSING')
    if not (root/'externals/dear_imgui/misc/fonts/binary_to_compressed_c.cpp').is_file():
        raise GateFailure('SUBMODULES_MISSING')


def verify_elf(elf: Path, output: Path) -> dict:
    if not elf.is_file() or elf.stat().st_size < 100_000:
        raise GateFailure('BUILT_ELF_MISSING_OR_EMPTY')
    header = run_cmd(['readelf','-h',str(elf)],log=output/'elf-header.txt')
    phdr = run_cmd(['readelf','-l',str(elf)],log=output/'elf-program.txt')
    dynamic = run_cmd(['readelf','-d',str(elf)],log=output/'elf-dynamic.txt')
    if not re.search(r'Class:\s+ELF64',header) or not re.search(r'Machine:\s+AArch64',header):
        raise GateFailure('WRONG_ELF_ARCHITECTURE')
    if '/lib/ld-linux-aarch64.so.1' not in phdr:
        raise GateFailure('WRONG_ELF_INTERPRETER')
    if 'Shared library: [libc.so.6]' not in dynamic:
        raise GateFailure('WRONG_GLIBC_LINKAGE')
    return {'size_bytes':elf.stat().st_size,'sha256':digest_file(elf),
            'architecture':'AArch64 ELF64','interpreter':'/lib/ld-linux-aarch64.so.1'}


def execute(*, kit: Path, root: Path | None, output: Path,
            build: bool=False, preflight_only: bool=False) -> dict:
    if build and preflight_only:
        raise GateFailure('INCOMPATIBLE_MODE')
    output.mkdir(parents=True,exist_ok=True)
    report = {'schema':'bachata-f43dev-p29-build-gate-v1',
              'source_revision':PIN,'kit_validated':False,
              'source_checkout_verified':False,'p28_port_applied':False,
              'full_core_compile_attempted':False,'full_core_compile_passed':False,
              'outlast_fixed':False,'minecraft_fixed':False,
              'f43dev_apk_modified':False,'real_device_tested':False,
              'status':'IN_PROGRESS'}
    try:
        report['kit_files_sha256']=verify_kit(kit)
        report['kit_validated']=True
        if preflight_only:
            report['status']='OFFLINE_PREFLIGHT_ONLY'
            return report
        if root is None:
            raise GateFailure('SOURCE_CHECKOUT_REQUIRED')
        verify_checkout(root)
        report['source_checkout_verified']=True
        port = kit/'port_renderer_p28.py'
        out = output/'p28-port.diff'
        run_cmd([sys.executable,str(port),'--source-root',str(root),
                 '--out',str(out),'--write'],log=output/'apply.log')
        report['p28_port_applied']=True
        run_cmd(['git','diff','--check'],cwd=root,log=output/'diff-check.log')
        if not (root/'src/video_core/renderer_vulkan/p28_vk_async_upload.cpp').is_file():
            raise GateFailure('ADAPTER_NOT_STAGED')
        if not build:
            report['status']='SOURCE_PATCHED_NOT_COMPILED'
            return report
        report['full_core_compile_attempted']=True
        try:
            run_cmd(['bash','runtime/scripts/build-shadps4-arm64.sh'], cwd=root,
                    log=output/'build.log')
            report['elf']=verify_elf(root/EXPECTED_ELF,output)
            report['full_core_compile_passed']=True
            report['status']='PUBLIC_CORE_GLIBC_COMPILED_NOT_F43DEV'
        except subprocess.TimeoutExpired:
            raise GateFailure('BUILD_TIMEOUT')
        return report
    except (GateFailure, subprocess.CalledProcessError, OSError) as e:
        report['status']='BLOCKED'
        report['failure_code']=str(e).split('\n')[0][:250]
        return report
    finally:
        (output/'P29_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--kit',type=Path,default=Path(__file__).parent)
    p.add_argument('--source-root',type=Path)
    p.add_argument('--output',type=Path,default=Path('p29-result'))
    p.add_argument('--preflight-only',action='store_true')
    p.add_argument('--build',action='store_true')
    a=p.parse_args()
    result=execute(kit=a.kit.resolve(),root=a.source_root.resolve() if a.source_root else None,
                   output=a.output.resolve(),build=a.build,preflight_only=a.preflight_only)
    print(json.dumps({k:v for k,v in result.items() if k!='kit_files_sha256'},sort_keys=True))
    return 0 if result['status'] in ('OFFLINE_PREFLIGHT_ONLY','SOURCE_PATCHED_NOT_COMPILED',
                                     'PUBLIC_CORE_GLIBC_COMPILED_NOT_F43DEV') else 2


if __name__ == '__main__':
    sys.exit(main())
