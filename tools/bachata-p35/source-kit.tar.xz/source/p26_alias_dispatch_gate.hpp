// SPDX-License-Identifier: GPL-2.0-or-later
// P26: a policy for staged copies, NOT a GPU execution or shader rewrite.
#pragma once
#include "p25_runtime_binding_gate.hpp"
#include <cstdint>
namespace BachataP26 {
using BachataP25::HazardKind;
// The shader recompiler must supply a verified contract, never a guess based on range overlap.
enum class ReadDependency : uint8_t { Unknown, EntryStateOnly, ReadsIntermediateWrites };
enum class AtomicOrdering : uint8_t { Unknown, None, CrossInvocationOrCrossDispatch };
struct DispatchEvidence {
    ReadDependency read_dependency = ReadDependency::Unknown;
    AtomicOrdering atomic_ordering = AtomicOrdering::Unknown;
    bool overlapping_storage_writers = false;
    bool shader_uses_dynamic_alias_indices = false;
    bool full_sampled_subresources_copied = false;
    bool snapshot_is_distinct_gpu_allocation = false;
    bool transfer_copy_scheduled_before_dispatch = false;
    bool transfer_write_to_shader_read_barrier = false;
    bool sampled_descriptors_rebound_to_snapshot = false;
    bool original_storage_bindings_preserved = false;
    bool storage_layout_access_and_queue_ownership_preserved = false;
    bool sample_and_storage_format_compatible = false;
};
enum class DispatchAction : uint8_t {
    NoConflict, BlockInvalid, BlockUnknownSemantics, BlockUnsupportedAtomicAliasing,
    BlockUnsupportedStorageAliasing, BlockMissingSnapshotMechanism,
    SnapshotPlanWithProofOnly
};
struct DispatchDecision {
    DispatchAction action;
    bool may_dispatch;
    bool must_preserve_original_storage;
};
constexpr DispatchDecision DecideDispatch(HazardKind hazard, const DispatchEvidence& e) {
    if(hazard == HazardKind::None) return {DispatchAction::NoConflict,true,false};
    if(hazard == HazardKind::InvalidRange || hazard == HazardKind::TooManyDescriptors)
        return {DispatchAction::BlockInvalid,false,true};
    if(e.atomic_ordering == AtomicOrdering::Unknown ||
       e.read_dependency == ReadDependency::Unknown ||
       e.shader_uses_dynamic_alias_indices)
        return {DispatchAction::BlockUnknownSemantics,false,true};
    if(e.atomic_ordering != AtomicOrdering::None ||
       e.read_dependency == ReadDependency::ReadsIntermediateWrites)
        return {DispatchAction::BlockUnsupportedAtomicAliasing,false,true};
    if(hazard == HazardKind::WriteWriteOverlap || e.overlapping_storage_writers)
        return {DispatchAction::BlockUnsupportedStorageAliasing,false,true};
    if(!(e.full_sampled_subresources_copied && e.snapshot_is_distinct_gpu_allocation &&
         e.transfer_copy_scheduled_before_dispatch && e.transfer_write_to_shader_read_barrier &&
         e.sampled_descriptors_rebound_to_snapshot && e.original_storage_bindings_preserved &&
         e.storage_layout_access_and_queue_ownership_preserved &&
         e.sample_and_storage_format_compatible))
        return {DispatchAction::BlockMissingSnapshotMechanism,false,true};
    // A *verified plan*, not proof that Vulkan GPU executed correctly. Must separately test.
    return {DispatchAction::SnapshotPlanWithProofOnly,true,true};
}
} // namespace BachataP26
