#!/usr/bin/env python3
"""P33 candidate: activate BC1/BC3 linear host-format fallback in pinned public GLIBC core.

This is NOT the private F43DEV runtime. Tiled BCn and robust aliasing stay unmodified.
This candidate intentionally uses a completion wait for correctness; not performance-ready.
"""
from pathlib import Path
import argparse, difflib, hashlib, json, shutil, subprocess, sys
sys.path.insert(0, str(Path(__file__).parent))
import port_renderer_p28 as p28
import port_renderer_p25 as p25

TC='src/video_core/texture_cache/texture_cache.cpp'
IMAGE='src/video_core/texture_cache/image.cpp'
HEADER='src/video_core/texture_cache/image.h'
ROOT_FILES=list(dict.fromkeys([*p28.RELS, TC]))
EXTRA='src/video_core/renderer_vulkan/p33_bcn_linear_policy.hpp'

def once(source, old, new, tag):
    n=source.count(old)
    if n!=1: raise ValueError(f'P33_{tag}_ANCHOR_{n}')
    return source.replace(old,new,1)

def transform(inputs):
    # The preceding transformations must be the exact reviewed P28 port.
    result=p28.transform({key: inputs[key] for key in p28.RELS})
    header=result[HEADER]
    header=once(header, '#include "video_core/renderer_vulkan/p26_upload_attestation.hpp"',
        '#include "video_core/renderer_vulkan/p26_upload_attestation.hpp"\n'
        '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"', 'include')
    header=once(header,'    ImageInfo info;',
        '    ImageInfo info;\n'
        '    // Public-core linear BCn fallback. Guest format remains compressed.\n'
        '    bool p33_linear_bcn_fallback = false;\n'
        '    BachataP33::Format p33_format = BachataP33::Format::Unsupported;\n'
        '    bool p33_srgb = false;', 'image_fields')
    result[HEADER]=header
    image=result[IMAGE]
    image=once(image,
        '    constexpr auto tiling = vk::ImageTiling::eOptimal;\n'
        '    const auto supported_format = instance->GetSupportedFormat(info.pixel_format, format_features);',
        '''    // P33: only directly addressable LINEAR BC1/BC3 guest images may use CPU
    // decoding. Never reinterpret GPU-tiled blocks or silently mutate guest format.
    const auto p33_select = [](vk::Format f) -> BachataP33::Format {
        switch (f) {
        case vk::Format::eBc1RgbUnormBlock:
        case vk::Format::eBc1RgbSrgbBlock: return BachataP33::Format::Bc1Rgb;
        case vk::Format::eBc1RgbaUnormBlock:
        case vk::Format::eBc1RgbaSrgbBlock: return BachataP33::Format::Bc1Rgba;
        case vk::Format::eBc3UnormBlock:
        case vk::Format::eBc3SrgbBlock: return BachataP33::Format::Bc3;
        default: return BachataP33::Format::Unsupported;
        }
    };
    p33_format = p33_select(info.pixel_format);
    p33_srgb = info.pixel_format == vk::Format::eBc1RgbSrgbBlock ||
        info.pixel_format == vk::Format::eBc1RgbaSrgbBlock ||
        info.pixel_format == vk::Format::eBc3SrgbBlock;
    const vk::Format p33_rgba = p33_srgb ? vk::Format::eR8G8B8A8Srgb :
        vk::Format::eR8G8B8A8Unorm;
    const auto gate = BachataP33::Eligible(BachataP33::Input{
        .format=p33_format, .srgb=p33_srgb,
        .tiled=bool(info.props.is_tiled) ||
            info.array_mode != AmdGpu::ArrayMode::ArrayLinearAligned,
        .volume=bool(info.props.is_volume) || info.type != AmdGpu::ImageType::Color2D,
        .image_format_supported=instance->IsFormatSupported(info.pixel_format,format_features),
        .rgba_host_supported=instance->IsFormatSupported(p33_rgba,format_features),
        .width=info.size.width, .height=info.size.height,
        .mips=info.resources.levels, .layers=info.resources.layers,
        .samples=info.num_samples, .guest_bits=info.num_bits,
    });
    p33_linear_bcn_fallback = gate == BachataP33::Gate::Eligible;
    if (p33_linear_bcn_fallback) {
        // VK_IMAGE_CREATE_BLOCK_TEXEL_VIEW_COMPATIBLE_BIT may not be set on
        // an uncompressed host RGBA image. Retain mutable-format semantics.
        flags &= ~vk::ImageCreateFlagBits::eBlockTexelViewCompatible;
        LOG_WARNING(Render_Vulkan, "P33_BCN_LINEAR_HOST_RGBA_SELECTED levels={} srgb={}",
                    info.resources.levels, p33_srgb ? 1 : 0);
    }
    constexpr auto tiling = vk::ImageTiling::eOptimal;
    const auto supported_format = p33_linear_bcn_fallback ? p33_rgba :
        instance->GetSupportedFormat(info.pixel_format, format_features);''',
        'host_format')
    result[IMAGE]=image
    cache=inputs[TC]
    cache=once(cache, '#include "video_core/texture_cache/tile_manager.h"',
        '#include "video_core/texture_cache/tile_manager.h"\n'
        '#include "video_core/renderer_vulkan/p27_upload_plan.hpp"\n'
        '#include "video_core/renderer_vulkan/p27_vk_decoded_upload.hpp"\n'
        '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"\n'
        '#include "video_core/buffer_cache/buffer.h"\n'
        '#include <bit>\n#include <memory>\n#include <vector>', 'cache_include')
    # Do not touch other TextureCache methods; insert ONLY inside RefreshImage.
    start=cache.index('void TextureCache::RefreshImage(Image& image) {')
    end=cache.index('vk::Sampler TextureCache::GetSampler(',start)
    segment=cache[start:end]
    segment=once(segment, '    const u32 num_layers = image.info.resources.layers;',
        '''    if (image.p33_linear_bcn_fallback) {
        // This is the ONLY supported active route. No blind upload of compressed
        // data into the host RGBA allocation if validation fails.
        ASSERT_MSG(image.info.guest_address && image.info.resources.layers == 1 &&
                   !image.info.props.is_tiled && !image.info.props.is_volume,
                   "P33 BCn linear fallback cannot read tiled or invalid guest memory");
        ASSERT_MSG(False(image.flags & ImageFlagBits::GpuModified),
                   "P33 linear BCn fallback cannot overwrite GPU-modified image");
        const auto p33_fmt = image.p33_format == BachataP33::Format::Bc3
            ? BachataP26::BcnFormat::BC3
            : image.p33_format == BachataP33::Format::Bc1Rgba
                ? BachataP26::BcnFormat::BC1_RGBA : BachataP26::BcnFormat::BC1_RGB;
        const BachataP33::Input p33_input{
            .format=image.p33_format, .srgb=image.p33_srgb,
            .tiled=false, .volume=false,
            .image_format_supported=false, .rgba_host_supported=true,
            .width=image.info.size.width, .height=image.info.size.height,
            .mips=image.info.resources.levels, .layers=1, .samples=1,
            .guest_bits=image.info.num_bits,
        };
        std::vector<BachataP27::CompressedSubresource> subs;
        subs.reserve(image.info.resources.levels);
        const auto* guest = std::bit_cast<const u8*>(image.info.guest_address);
        for (u32 mip=0; mip<image.info.resources.levels; ++mip) {
            const auto& layout=image.info.mips_layout[mip];
            const auto check=BachataP33::CheckMip(p33_input,
                {layout.offset,layout.size,layout.pitch,layout.height},
                image.info.guest_size,mip);
            ASSERT_MSG(check.gate == BachataP33::Gate::Eligible,
                       "P33 BCn linear image has invalid pitch or bounded mip layout");
            subs.push_back(BachataP27::CompressedSubresource{
                .mip=mip, .layer=0,
                .width=std::max(1u,image.info.size.width>>mip),
                .height=std::max(1u,image.info.size.height>>mip),
                .row_stride=check.row_stride,
                .blocks=std::span<const u8>(guest+layout.offset,layout.size),
            });
        }
        const auto plan=BachataP27::BuildPlan(p33_fmt,image.p33_srgb,
            image.info.size.width,image.info.size.height,
            image.info.resources.levels,1,subs);
        ASSERT_MSG(plan.status==BachataP27::PlanStatus::Ok && !plan.staging.empty(),
                   "P33 BCn linear decode or staging layout was rejected");
        // A completion wait is intentional for first correctness bring-up:
        // ImageView's P25 attestation may not pass before GPU completion.
        // P28 async rework needs a view-safe completion callback before opt-in.
        Buffer staging(instance,scheduler,MemoryUsage::Upload,0,ReadFlags,
                       plan.staging.size());
        const unsigned generation=image.backing->p26_upload_journal.generation+1;
        ASSERT_MSG(generation != 0, "P33 BCn upload journal generation overflow");
        const auto result=BachataP27::UploadDecodedToRgba(plan,image,staging,instance,
                                                           scheduler,generation);
        ASSERT_MSG(result == BachataP27::UploadResult::Uploaded,
                   "P33 BCn linear Vulkan upload or completion proof failed");
        image.flags &= ~ImageFlagBits::Dirty;
        LOG_WARNING(Render_Vulkan, "P33_BCN_LINEAR_ACTIVE uploaded levels={} srgb={}",
                    image.info.resources.levels,image.p33_srgb ? 1 : 0);
        return;
    }

    const u32 num_layers = image.info.resources.layers;''',
        'refresh_hook')
    result[TC]=cache[:start]+segment+cache[end:]
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path('p33-port.diff'))
    p.add_argument('--write',action='store_true');p.add_argument('--synthetic-fixture',action='store_true')
    a=p.parse_args()
    if not a.synthetic_fixture:
        git=lambda *args:subprocess.run(['git','-C',str(a.source_root),*args],capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD')!=p25.EXPECTED_UPSTREAM: raise ValueError('P33_SOURCE_REVISION_DRIFT')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P33_DIRTY_TRACKED_TREE')
        for rel,digest in p28.IMAGE_SHA_PIN.items():
            if git('hash-object',rel)!=digest:raise ValueError('P33_SOURCE_SHA_DRIFT:'+rel)
    original={k:(a.source_root/k).read_text() for k in ROOT_FILES}
    updated=transform(original)
    addition={f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
              for name in (*p28.p27.HEADERS,*p28.P28_FILES,'p33_bcn_linear_policy.hpp')}
    for dest,source in addition.items():
        if not source.is_file():raise ValueError('P33_MISSING_LOCAL_SOURCE:'+dest)
        if (a.source_root/dest).exists():raise ValueError('P33_DESTINATION_ALREADY_EXISTS:'+dest)
    diff=''.join(''.join(difflib.unified_diff(original[k].splitlines(True),updated[k].splitlines(True),
                       fromfile='a/'+k,tofile='b/'+k)) for k in ROOT_FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(diff)
    if a.write:
        for k,v in updated.items():(a.source_root/k).write_text(v)
        for k,src in addition.items():
            target=a.source_root/k;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,target)
    print(json.dumps({'schema':'P33_PUBLIC_SOURCE_LINEAR_BCN_CANDIDATE','source':p25.EXPECTED_UPSTREAM,
        'write':a.write,'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),
        'linear_bcn_hooked':True,'tiled_bcn_supported':False,
        'minecraft_alias_fixed':False,'f43dev_apk_built':False,
        'full_core_compile_passed':False,'files':ROOT_FILES},sort_keys=True))
if __name__=='__main__':main()
