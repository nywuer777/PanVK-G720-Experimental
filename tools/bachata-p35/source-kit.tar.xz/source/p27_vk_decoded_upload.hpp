// SPDX-License-Identifier: GPL-2.0-or-later
// Source integration API. This header is compiled only with the pinned public
// shadPS4 core / Vulkan SDK; portable C++ tests cover its planner separately.
#pragma once
#include "video_core/renderer_vulkan/p27_upload_plan.hpp"
namespace VideoCore {struct Image; class Buffer;}
namespace Vulkan {class Instance; class Scheduler;}
namespace BachataP27 {
enum class UploadResult : unsigned char { Uploaded, BlockedInvalidPlan, BlockedBacking,
                                         BlockedStaging, BlockedVulkanFeatures };
// Caller owns the *already allocated RGBA8* destination and mapped upload buffer.
// This function is NOT wired to the original F43DEV private decoded-BCn route.
// Real transfer uses the upstream Image::Upload and Scheduler::Finish API.
// Complete source-facing entry: decode BC1/BC3 into the validated staging
// plan, then upload only to an explicit RGBA8 destination image.
UploadResult DecodeAndUploadBcn(BcnFormat format, bool srgb,
    uint32_t width,uint32_t height,uint32_t levels,uint32_t layers,
    std::span<const CompressedSubresource> input,
    VideoCore::Image& image,VideoCore::Buffer& staging,
    const Vulkan::Instance& instance,Vulkan::Scheduler& scheduler,unsigned generation);
UploadResult UploadDecodedToRgba(const PlanResult& plan, VideoCore::Image& image,
    VideoCore::Buffer& staging, const Vulkan::Instance& instance,
    Vulkan::Scheduler& scheduler, unsigned generation);
}
