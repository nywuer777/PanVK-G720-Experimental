#!/usr/bin/env python3
"""P34: integrate conditional 1D-tiled BCn GPU detile/readback -> P33 RGBA Vulkan upload.

Only public pinned core. CPU fallback intentionally synchronous in this correctness phase.
No Minecraft safety assertions are suppressed. No APK or private core modification.
"""
from pathlib import Path
import argparse,difflib,hashlib,json,shutil,subprocess,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p33 as p33
import port_renderer_p25 as p25

def once(text,old,new,tag):
    if text.count(old)!=1: raise ValueError(f'P34_{tag}_ANCHOR_{text.count(old)}')
    return text.replace(old,new,1)

EXTRA='src/video_core/renderer_vulkan/p34_tiled_bcn_policy.hpp'
def transform(inputs):
    output=p33.transform(inputs)
    hp='src/video_core/texture_cache/image.h'
    output[hp]=once(output[hp],
      '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"',
      '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"\n'
      '#include "video_core/renderer_vulkan/p34_tiled_bcn_policy.hpp"','include')
    output[hp]=once(output[hp],
      '    bool p33_linear_bcn_fallback = false;',
      '    bool p33_linear_bcn_fallback = false;\n'
      '    bool p34_tiled_bcn_fallback = false;', 'field')
    im='src/video_core/texture_cache/image.cpp'
    output[im]=once(output[im],
      '    p33_linear_bcn_fallback = gate == BachataP33::Gate::Eligible;\n'
      '    if (p33_linear_bcn_fallback) {',
      '''    p33_linear_bcn_fallback = gate == BachataP33::Gate::Eligible;
    // This path is valid only for the existing 1D-tiled thin GPU detiler.
    // Unknown/macro/thick tiled formats remain on the original renderer path.
    const BachataP34::Input tiled_input{
        .format=p33_format, .is_tiled=bool(info.props.is_tiled),
        .exactly_1d_tiled_thin1=info.array_mode == AmdGpu::ArrayMode::Array1DTiledThin1,
        .volume=bool(info.props.is_volume) || info.type != AmdGpu::ImageType::Color2D,
        .host_bcn_supported=instance->IsFormatSupported(info.pixel_format,format_features),
        .host_rgba_supported=instance->IsFormatSupported(p33_rgba,format_features),
        .width=info.size.width,.height=info.size.height,
        .mips=info.resources.levels,.layers=info.resources.layers,
        .samples=info.num_samples,.guest_bits=info.num_bits,
        .guest_bytes=info.guest_size,
    };
    p34_tiled_bcn_fallback = BachataP34::Eligible(tiled_input)==BachataP34::Status::Eligible;
    if (p34_tiled_bcn_fallback) {
        LOG_WARNING(Render_Vulkan,"P34_BCN_1D_TILED_RGBA_SELECTED levels={} bytes={}",
                    info.resources.levels,info.guest_size);
    }
    if (p33_linear_bcn_fallback || p34_tiled_bcn_fallback) {''','host_selection')
    output[im]=once(output[im],
      'const auto supported_format = p33_linear_bcn_fallback ? p33_rgba :',
      'const auto supported_format = (p33_linear_bcn_fallback || p34_tiled_bcn_fallback) ? p33_rgba :',
      'format_selection')
    tc='src/video_core/texture_cache/texture_cache.cpp'
    cache=output[tc]
    cache=once(cache,
      '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"',
      '#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"\n'
      '#include "video_core/renderer_vulkan/p34_tiled_bcn_policy.hpp"\n'
      '#include <vk_mem_alloc.h>',
      'cache_include')
    cache=once(cache,
      '    if (image.p33_linear_bcn_fallback) {',
      '    if (image.p33_linear_bcn_fallback || image.p34_tiled_bcn_fallback) {',
      'branch')
    cache=once(cache,
      '                   !image.info.props.is_tiled && !image.info.props.is_volume,',
      '                   (image.p33_linear_bcn_fallback || image.p34_tiled_bcn_fallback) &&\n'
      '                   !image.info.props.is_volume,',
      'assert_format')
    cache=once(cache,
      '        const auto* guest = std::bit_cast<const u8*>(image.info.guest_address);',
      '''        const auto* guest = std::bit_cast<const u8*>(image.info.guest_address);
        std::unique_ptr<Buffer> tiled_readback;
        if (image.p34_tiled_bcn_fallback) {
            // P34_GPUTILE_DETILE_READBACK: the source is a GPU-computed linear
            // BCn block stream. Never decode the original tiled CPU pointer.
            const BachataP34::Input tiled_input{
                .format=image.p33_format,.is_tiled=true,
                .exactly_1d_tiled_thin1=image.info.array_mode==AmdGpu::ArrayMode::Array1DTiledThin1,
                .volume=false,.host_bcn_supported=false,.host_rgba_supported=true,
                .width=image.info.size.width,.height=image.info.size.height,
                .mips=image.info.resources.levels,.layers=1,.samples=1,
                .guest_bits=image.info.num_bits,.guest_bytes=image.info.guest_size,
            };
            ASSERT_MSG(BachataP34::Eligible(tiled_input)==BachataP34::Status::Eligible,
                       "P34 detile eligibility changed after image allocation");
            ASSERT_MSG((image.info.guest_size / (image.info.num_bits / 8u)) % 64u == 0,
                       "P34 detile shader dispatch would truncate partial workgroup");
            for (u32 mip=0; mip<image.info.resources.levels; ++mip) {
                const auto& m=image.info.mips_layout[mip];
                ASSERT_MSG(BachataP34::ValidateMip(tiled_input,
                   {m.offset,m.size,m.pitch,m.height},mip)==BachataP34::Status::Eligible,
                   "P34 compressed mip layout invalid after detiling");
            }
            scheduler.EndRendering();
            const auto [input_buffer,input_offset]=
                buffer_cache.ObtainBufferForImage(image.info.guest_address,image.info.guest_size);
            if (auto barrier=input_buffer->GetBarrier(vk::AccessFlagBits2::eShaderRead,
                                  vk::PipelineStageFlagBits2::eComputeShader)) {
                scheduler.CommandBuffer().pipelineBarrier2(vk::DependencyInfo{
                    .bufferMemoryBarrierCount=1,.pBufferMemoryBarriers=&barrier.value(),
                });
            }
            const auto [detiled_buffer,detiled_offset]=
                tile_manager.DetileImage(input_buffer->Handle(),input_offset,image.info);
            tiled_readback=std::make_unique<Buffer>(instance,scheduler,MemoryUsage::Download,0,
                                                    AllFlags,image.info.guest_size);
            ASSERT_MSG(tiled_readback->Handle() &&
                       tiled_readback->mapped_data.size()>=image.info.guest_size,
                       "P34 detile readback not host-visible");
            const auto cmdbuf=scheduler.CommandBuffer();
            const vk::BufferMemoryBarrier2 to_transfer{
                .srcStageMask=vk::PipelineStageFlagBits2::eComputeShader,
                .srcAccessMask=vk::AccessFlagBits2::eShaderWrite,
                .dstStageMask=vk::PipelineStageFlagBits2::eCopy,
                .dstAccessMask=vk::AccessFlagBits2::eTransferRead,
                .buffer=detiled_buffer,.offset=detiled_offset,.size=image.info.guest_size,
            };
            cmdbuf.pipelineBarrier2(vk::DependencyInfo{
                .bufferMemoryBarrierCount=1,.pBufferMemoryBarriers=&to_transfer,
            });
            const vk::BufferCopy copy{.srcOffset=detiled_offset,.dstOffset=0,
                                     .size=image.info.guest_size};
            cmdbuf.copyBuffer(detiled_buffer,tiled_readback->Handle(),copy);
            const vk::BufferMemoryBarrier2 to_host{
                .srcStageMask=vk::PipelineStageFlagBits2::eCopy,
                .srcAccessMask=vk::AccessFlagBits2::eTransferWrite,
                .dstStageMask=vk::PipelineStageFlagBits2::eHost,
                .dstAccessMask=vk::AccessFlagBits2::eHostRead,
                .buffer=tiled_readback->Handle(),.offset=0,.size=image.info.guest_size,
            };
            cmdbuf.pipelineBarrier2(vk::DependencyInfo{
                .bufferMemoryBarrierCount=1,.pBufferMemoryBarriers=&to_host,
            });
            scheduler.Finish(); // correctness-only; no per-texture FPS claims
            if (!tiled_readback->is_coherent) {
                ASSERT_MSG(vmaInvalidateAllocation(instance.GetAllocator(),
                   tiled_readback->buffer.allocation,0,image.info.guest_size)==VK_SUCCESS,
                   "P34 detile readback memory invalidation failed");
            }
            guest=tiled_readback->mapped_data.data();
            LOG_WARNING(Render_Vulkan,"P34_BCN_1D_TILED_READBACK_OK bytes={}",
                        image.info.guest_size);
        }''',
      'gpu_detile_entry')
    cache=once(cache,
      '        LOG_WARNING(Render_Vulkan, "P33_BCN_LINEAR_ACTIVE uploaded levels={} srgb={}",\n'
      '                    image.info.resources.levels,image.p33_srgb ? 1 : 0);',
      '        LOG_WARNING(Render_Vulkan, "P34_BCN_UPLOAD_ACTIVE path={} levels={} srgb={}",\n'
      '                    image.p34_tiled_bcn_fallback ? "gpu_detile_readback" : "cpu_linear",\n'
      '                    image.info.resources.levels,image.p33_srgb ? 1 : 0);',
      'upload_logging')
    output[tc]=cache
    return output

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-root',required=True,type=Path)
    p.add_argument('--out',default=Path('p34-port.diff'),type=Path)
    p.add_argument('--write',action='store_true')
    p.add_argument('--synthetic-fixture',action='store_true')
    args=p.parse_args()
    if not args.synthetic_fixture:
        def git(*a): return subprocess.run(['git','-C',str(args.source_root),*a],capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD')!=p25.EXPECTED_UPSTREAM:raise ValueError('P34_WRONG_SOURCE_REVISION')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P34_DIRTY_TREE')
        for rel,h in p33.p28.IMAGE_SHA_PIN.items():
            if git('hash-object',rel)!=h:raise ValueError('P34_SHA_DRIFT:'+rel)
    original={key:(args.source_root/key).read_text() for key in p33.ROOT_FILES}
    modified=transform(original)
    additions={f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
               for name in (*p33.p28.p27.HEADERS,*p33.p28.P28_FILES,
                           'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp')}
    for dest,src in additions.items():
        if not src.is_file():raise ValueError('MISSING_SOURCE:'+str(src))
        if (args.source_root/dest).exists():raise ValueError('DEST_ALREADY_EXISTS:'+dest)
    diff=''.join(''.join(difflib.unified_diff(original[k].splitlines(True),modified[k].splitlines(True),
                   fromfile='a/'+k,tofile='b/'+k)) for k in p33.ROOT_FILES)
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(diff)
    if args.write:
        for k,v in modified.items():(args.source_root/k).write_text(v)
        for k,src in additions.items():
            dst=args.source_root/k;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
    print(json.dumps({'schema':'P34_PINNED_PUBLIC_CORE_TILED_BCN_CANDIDATE',
       'source_revision':p25.EXPECTED_UPSTREAM,
       'tiled_1d_detile_readback_hooked':True,'linear_path_retained':True,
       'blocking_gpu_sync':True,'minecraft_fixed':False,'outlast_fixed':False,
       'apk_built':False,'full_compilation_verified':False,
       'patched_files':p33.ROOT_FILES,'patch_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
