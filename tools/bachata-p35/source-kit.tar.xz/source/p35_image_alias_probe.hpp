// SPDX-License-Identifier: GPL-2.0-or-later
// P35: privacy-safe Vulkan image-alias observation, not a synchronization fix.
#pragma once
#include <cstdint>
#include <cstddef>
#include <span>
#include <limits>
namespace BachataP35 {
constexpr std::size_t MaxBindings=64;
enum class Access:std::uint8_t {Sampled, StorageWrite, StorageAtomic};
struct Binding {
    std::uint64_t begin=0;
    std::uint64_t bytes=0;
    Access access=Access::Sampled;
    bool valid=false;
    bool dynamic_mip=false;
};
enum class Hazard:std::uint8_t {
    None, SampleStorage, SampleAtomic, StorageStorage, AtomicStorage,
    InvalidRange, CapacityExceeded, MetadataMismatch
};
struct Result {
    Hazard kind=Hazard::None;
    std::uint32_t lhs=0;
    std::uint32_t rhs=0;
    bool sample_storage_overlap=false;
    bool has_atomic=false;
    bool has_dynamic_mip=false;
    bool can_rewrite_descriptors=false; // permanently FALSE without shader IR proof
};
constexpr bool RangeValid(const Binding& a) {
    return a.bytes>0 && a.begin>0 && a.begin<=std::numeric_limits<std::uint64_t>::max()-a.bytes;
}
constexpr bool Overlap(const Binding& a,const Binding& b) {
    return a.begin < b.begin+b.bytes && b.begin < a.begin+a.bytes;
}
constexpr Result Inspect(std::span<const Binding> b,std::size_t metadata_count) {
    if (b.size()>MaxBindings) return {Hazard::CapacityExceeded};
    if (metadata_count!=b.size()) return {Hazard::MetadataMismatch};
    for(std::size_t i=0;i<b.size();++i){
        if(!b[i].valid)continue;
        if(!RangeValid(b[i]))return {Hazard::InvalidRange,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(i)};
        for(std::size_t j=i+1;j<b.size();++j){
            if(!b[j].valid)continue;
            if(!RangeValid(b[j]))return {Hazard::InvalidRange,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(j)};
            if(!Overlap(b[i],b[j]))continue;
            const bool wi=b[i].access!=Access::Sampled;
            const bool wj=b[j].access!=Access::Sampled;
            if(!wi&&!wj)continue;
            const bool atomic=b[i].access==Access::StorageAtomic||b[j].access==Access::StorageAtomic;
            const bool dynamic=b[i].dynamic_mip||b[j].dynamic_mip;
            const Hazard kind=wi&&wj ? (atomic?Hazard::AtomicStorage:Hazard::StorageStorage)
                                     : (atomic?Hazard::SampleAtomic:Hazard::SampleStorage);
            return {kind,static_cast<std::uint32_t>(i),static_cast<std::uint32_t>(j),
                    wi!=wj,atomic,dynamic,false};
        }
    }
    return {};
}
} // namespace BachataP35
