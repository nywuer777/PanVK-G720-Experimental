// SPDX-License-Identifier: GPL-2.0-or-later
// P25: explicit runtime provenance gate; safe decisions only, no Vulkan side effects.
#pragma once
#include "p24_compatibility.hpp"
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>

namespace BachataP25 {
using BachataP24::GuestMemoryRange;
using BachataP24::PixelFormat;

struct Provenance {
    // These properties must be set by the *real* decoder/allocator after completion.
    bool bcn_decode_completed = false;
    bool decoded_mips_all_uploaded = false;
    bool source_extent_matches_rgba = false;
    bool color_aspect = false;
    bool host_sampled_feature = false;
    bool host_view_format_feature = false;
    bool mutable_create_flag = false;
    bool mutable_view_is_compatible = false;
};

enum class ViewVerdict : uint8_t {
    PassThrough, UseRgba8View, BlockInvalidRange, BlockMissingDecodeEvidence,
    BlockBackingFormat, BlockSrgbMutation, BlockInsufficientVulkanSupport
};

struct ViewInputs {
    PixelFormat guest = PixelFormat::Unknown;
    PixelFormat actual_host_backing = PixelFormat::Unknown;
    bool sampled = false;
    bool storage = false;
    uint32_t base_mip = 0, mip_count = 0, allocated_mips = 0;
    uint32_t base_layer = 0, layer_count = 0, allocated_layers = 0;
    Provenance proof{};
};

struct ViewResult {
    ViewVerdict verdict;
    PixelFormat view_format;
    bool alters_original_selection;
    constexpr bool may_create_view() const {
        return verdict == ViewVerdict::PassThrough || verdict == ViewVerdict::UseRgba8View;
    }
};

constexpr ViewResult PlanBcnView(const ViewInputs& in) {
    // Guard bounds before Vulkan CreateImageView (overflow-safe subtraction).
    if (!in.mip_count || !in.allocated_mips || !in.layer_count || !in.allocated_layers ||
        in.base_mip >= in.allocated_mips ||
        in.mip_count > in.allocated_mips - in.base_mip ||
        in.base_layer >= in.allocated_layers ||
        in.layer_count > in.allocated_layers - in.base_layer) {
        return {ViewVerdict::BlockInvalidRange, PixelFormat::Unknown, false};
    }
    if (!BachataP24::IsBc(in.guest)) {
        return {ViewVerdict::PassThrough, in.actual_host_backing, false};
    }
    // Compressed Vulkan views must not be substituted on a guessed decoded backing.
    if (in.storage || !in.sampled || !BachataP24::IsRgba(in.actual_host_backing)) {
        return {ViewVerdict::BlockBackingFormat, PixelFormat::Unknown, false};
    }
    const auto& p = in.proof;
    if (!p.bcn_decode_completed || !p.decoded_mips_all_uploaded ||
        !p.source_extent_matches_rgba || !p.color_aspect) {
        return {ViewVerdict::BlockMissingDecodeEvidence, PixelFormat::Unknown, false};
    }
    if (!p.host_sampled_feature || !p.host_view_format_feature) {
        return {ViewVerdict::BlockInsufficientVulkanSupport, PixelFormat::Unknown, false};
    }
    const auto desired = BachataP24::IsSrgb(in.guest) ? PixelFormat::Rgba8Srgb
                                                      : PixelFormat::Rgba8Unorm;
    if (desired != in.actual_host_backing &&
        !(p.mutable_create_flag && p.mutable_view_is_compatible)) {
        return {ViewVerdict::BlockSrgbMutation, PixelFormat::Unknown, false};
    }
    return {ViewVerdict::UseRgba8View, desired, desired != in.actual_host_backing};
}

enum class DescriptorAccess : uint8_t { Sample, StorageWrite, StorageAtomic };
struct Descriptor {
    GuestMemoryRange guest{};
    DescriptorAccess access = DescriptorAccess::Sample;
    bool has_valid_image = true;
};
enum class HazardKind : uint8_t { None, ReadWriteOverlap, WriteWriteOverlap, InvalidRange, TooManyDescriptors };
struct HazardRecord { HazardKind kind = HazardKind::None; uint32_t left = 0, right = 0; };

// Static capacity ensures the hot path cannot silently truncate resource lists.
template <size_t Capacity = 64> constexpr HazardRecord FindFirstHazard(const Descriptor* desc, size_t count) {
    if (count > Capacity) return {HazardKind::TooManyDescriptors, 0, 0};
    if (count && !desc) return {HazardKind::InvalidRange, 0, 0};
    for (size_t i = 0; i < count; ++i) {
        if (!desc[i].has_valid_image) continue;
        if (!BachataP24::ValidRange(desc[i].guest)) {
            return {HazardKind::InvalidRange, static_cast<uint32_t>(i), static_cast<uint32_t>(i)};
        }
        for (size_t j = i + 1; j < count; ++j) {
            if (!desc[j].has_valid_image) continue;
            if (!BachataP24::ValidRange(desc[j].guest)) {
                return {HazardKind::InvalidRange, static_cast<uint32_t>(i), static_cast<uint32_t>(j)};
            }
            if (!BachataP24::Overlap(desc[i].guest, desc[j].guest)) continue;
            const bool write_i = desc[i].access != DescriptorAccess::Sample;
            const bool write_j = desc[j].access != DescriptorAccess::Sample;
            if (write_i && write_j) return {HazardKind::WriteWriteOverlap, static_cast<uint32_t>(i), static_cast<uint32_t>(j)};
            if (write_i != write_j) return {HazardKind::ReadWriteOverlap, static_cast<uint32_t>(i), static_cast<uint32_t>(j)};
        }
    }
    return {};
}

// Access ordering across shader invocations is not determined by address overlap alone.
// Snapshot/transfer barriers must never be claimed complete by this detector.
constexpr bool NeedsShaderSemanticProof(HazardKind k) {
    return k == HazardKind::ReadWriteOverlap || k == HazardKind::WriteWriteOverlap;
}
} // namespace BachataP25
