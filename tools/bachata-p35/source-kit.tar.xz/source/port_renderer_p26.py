#!/usr/bin/env python3
"""Source-only P26 extension of the *pinned* P25 public-core port.

May emit diff / write to a clone with exact expected revision; does not claim integration
with the unmatched private F43DEV core. No shader rewrite, no forced format hacks.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import shutil
import subprocess
import port_renderer_p25 as p25

RELS = ['src/video_core/texture_cache/image.h',
        'src/video_core/texture_cache/image_view.cpp',
        'src/video_core/renderer_vulkan/vk_rasterizer.cpp']


def replace_one(text, old, new, label):
    if text.count(old) != 1:
        raise ValueError(f'{label}: expected unique anchor got {text.count(old)}')
    return text.replace(old, new, 1)


def transform(original):
    patched = p25.transform(dict(original))
    h=patched[RELS[0]]
    h=replace_one(h, '#include "video_core/renderer_vulkan/p25_runtime_binding_gate.hpp"',
        '#include "video_core/renderer_vulkan/p25_runtime_binding_gate.hpp"\n'
        '#include "video_core/renderer_vulkan/p26_upload_attestation.hpp"', 'p26 journal include')
    h=replace_one(h, 'BachataP25::Provenance p25_decode_proof{};',
        'BachataP26::UploadJournal p26_upload_journal{};', 'p26 journal field')
    patched[RELS[0]]=h
    view=patched[RELS[1]]
    view=replace_one(view, 'auto proof = image.backing->p25_decode_proof;',
        'auto proof = image.backing->p26_upload_journal.proof();', 'p26 journal view gate')
    patched[RELS[1]]=view
    rast=patched[RELS[2]]
    rast='#include "video_core/renderer_vulkan/p26_alias_dispatch_gate.hpp"\n' + rast
    target='''    if (p25_hazard.kind != BachataP25::HazardKind::None) {
        // No addresses, image contents or private arguments are emitted.'''
    replacement='''    if (p25_hazard.kind != BachataP25::HazardKind::None) {
        // P26 status is conservative: shader semantics unknown unless supplied by
        // a *verified* shader/dispatch analysis. This has NO GPU side effects.
        const auto p26_decision = BachataP26::DecideDispatch(p25_hazard.kind, {});
        LOG_WARNING(Render_Vulkan, "P26_ALIAS_POLICY action={} gpu_rewrite=0",
                    static_cast<unsigned>(p26_decision.action));
        // No addresses, image contents or private arguments are emitted.'''
    rast=replace_one(rast,target,replacement,'p26 alias audit')
    patched[RELS[2]]=rast
    return patched


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root', type=Path, required=True)
    ap.add_argument('--out',type=Path,default=Path('p26-port.diff'))
    ap.add_argument('--write',action='store_true')
    ap.add_argument('--synthetic-fixture',action='store_true')
    args=ap.parse_args()
    if not args.synthetic_fixture:
        head=subprocess.run(['git','-C',str(args.source_root),'rev-parse','HEAD'],check=True,
                            text=True,capture_output=True).stdout.strip()
        if head != p25.EXPECTED_UPSTREAM:raise ValueError('WRONG_SOURCE_REVISION')
    orig={path:(args.source_root/path).read_text() for path in RELS}
    patch=transform(orig)
    additions={
       f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
       for name in ('p24_compatibility.hpp','p25_runtime_binding_gate.hpp',
          'p26_bcn_decoder.hpp','p26_alias_dispatch_gate.hpp','p26_upload_attestation.hpp')}
    for dest in additions:
        if (args.source_root/dest).exists():raise ValueError(f'EXISTING_TARGET_BLOCKED {dest}')
    diff=''.join(''.join(difflib.unified_diff(orig[path].splitlines(True),patch[path].splitlines(True),
          fromfile='a/'+path,tofile='b/'+path)) for path in RELS)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(diff)
    if args.write:
        for name,src in patch.items():(args.source_root/name).write_text(src)
        for dest,src in additions.items():
            out=args.source_root/dest;out.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,out)
    print(json.dumps({'schema':'bachata-p26-source-only','source_commit':p25.EXPECTED_UPSTREAM,
         'dry_run':not args.write,'source_edits':RELS,'headers':sorted(additions),
         'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),
         'full_core_compiled':False,'private_f43dev_apk_modified':False},sort_keys=True))

if __name__=='__main__':main()
