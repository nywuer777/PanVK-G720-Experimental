// SPDX-License-Identifier: GPL-2.0-or-later
// No caller may mark a Vulkan backing decoded using only a CPU decode success.
#pragma once
#include "p25_runtime_binding_gate.hpp"
#include <array>
#include <cstdint>
namespace BachataP26 {
// Bounded journal for single-layer test cases; real renderer must support all layers.
struct UploadJournal {
    enum class State : uint8_t { Fresh, CpuDecoded, UploadSubmitted, UploadCompleted, Invalidated };
    State state = State::Fresh;
    uint32_t generation = 0;
    uint32_t level_count = 0;
    uint32_t level_mask = 0;
    bool rgba_extent_ok = false;
    bool color_aspect_ok = false;
    bool sampled_format_feature_ok = false;
    bool compatible_view_format_feature_ok = false;
    bool mutable_flag = false;
    bool compatible_mutable_view = false;
    bool began(uint32_t levels, uint32_t new_generation) {
        if (levels == 0 || levels > 16 || new_generation <= generation) return false;
        generation = new_generation;
        level_count = levels;
        level_mask = 0;
        rgba_extent_ok = color_aspect_ok = sampled_format_feature_ok =
            compatible_view_format_feature_ok = mutable_flag = compatible_mutable_view = false;
        state = State::Fresh;
        return true;
    }
    bool decoded_level(uint32_t level) {
        if (state != State::Fresh && state != State::CpuDecoded) return false;
        if (level >= level_count) return false;
        level_mask |= (1u << level);
        state = State::CpuDecoded;
        return true;
    }
    bool all_mips_decoded() const {
        return (state == State::CpuDecoded || state == State::UploadSubmitted ||
                state == State::UploadCompleted) &&
            level_count > 0 && level_mask == ((1u << level_count)-1);
    }
    bool submitted(bool dimension_verified, bool color_aspect_verified) {
        if (!all_mips_decoded() || !dimension_verified || !color_aspect_verified)
            return false;
        rgba_extent_ok = dimension_verified;
        color_aspect_ok = color_aspect_verified;
        state=State::UploadSubmitted;
        return true;
    }
    bool completed_after_gpu_fence(bool transfer_completed, bool is_sampled,
                  bool supported_host, bool supported_view, bool is_mutable,
                  bool compatible_mutation) {
        if (state != State::UploadSubmitted || !transfer_completed || !is_sampled) return false;
        sampled_format_feature_ok = supported_host;
        compatible_view_format_feature_ok = supported_view;
        mutable_flag = is_mutable;
        compatible_mutable_view = compatible_mutation;
        state=State::UploadCompleted;
        return true;
    }
    void invalidate() { state=State::Invalidated; level_mask=0; }
    BachataP25::Provenance proof() const {
        const bool complete = state == State::UploadCompleted && all_mips_decoded();
        return {.bcn_decode_completed=complete,
                .decoded_mips_all_uploaded=complete,
                .source_extent_matches_rgba=complete && rgba_extent_ok,
                .color_aspect=complete && color_aspect_ok,
                .host_sampled_feature=complete && sampled_format_feature_ok,
                .host_view_format_feature=complete && compatible_view_format_feature_ok,
                .mutable_create_flag=complete && mutable_flag,
                .mutable_view_is_compatible=complete && compatible_mutable_view};
    }
};
} // namespace BachataP26
