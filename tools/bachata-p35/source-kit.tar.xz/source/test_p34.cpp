#include "p34_tiled_bcn_policy.hpp"
#include <cassert>
#include <iostream>
#include <limits>
using namespace BachataP34;
int main(){
 unsigned assertions=0;
 auto check=[&](bool ok){assert(ok);++assertions;};
 Input in{.format=BachataP33::Format::Bc1Rgba,.is_tiled=true,
   .exactly_1d_tiled_thin1=true,.volume=false,.host_bcn_supported=false,
   .host_rgba_supported=true,.width=64,.height=64,.mips=2,.layers=1,
   .samples=1,.guest_bits=64,.guest_bytes=8192};
 check(Eligible(in)==Status::Eligible);
 check(ValidateMip(in,{0,4096,64,64},0)==Status::Eligible);
 check(ValidateMip(in,{4096,1024,32,32},1)==Status::Eligible);
 check(ValidateMip(in,{8100,200,64,64},0)==Status::InvalidMip);
 check(ValidateMip(in,{0,8,64,64},0)==Status::InvalidMip);
 check(ValidateMip(in,{0,4096,4,64},0)==Status::InvalidMip);
 check(ValidateMip(in,{0,4096,64,4},0)==Status::InvalidMip);
 check(ValidateMip(in,{0,4096,64,64},2)==Status::InvalidMip);
 in.is_tiled=false;check(Eligible(in)==Status::UnsupportedTiling);in.is_tiled=true;
 in.exactly_1d_tiled_thin1=false;check(Eligible(in)==Status::UnsupportedTiling);in.exactly_1d_tiled_thin1=true;
 in.volume=true;check(Eligible(in)==Status::UnsupportedTiling);in.volume=false;
 in.host_bcn_supported=true;check(Eligible(in)==Status::HostUnavailable);in.host_bcn_supported=false;
 in.host_rgba_supported=false;check(Eligible(in)==Status::HostUnavailable);in.host_rgba_supported=true;
 in.samples=2;check(Eligible(in)==Status::Shape);in.samples=1;
 in.layers=2;check(Eligible(in)==Status::Shape);in.layers=1;
 in.width=0;check(Eligible(in)==Status::Shape);in.width=64;
 in.width=16385;check(Eligible(in)==Status::Shape);in.width=64;
 in.height=16385;check(Eligible(in)==Status::Shape);in.height=64;
 in.mips=17;check(Eligible(in)==Status::Shape);in.mips=2;
 in.guest_bits=128;check(Eligible(in)==Status::WrongFormat);in.guest_bits=64;
 in.format=BachataP33::Format::Unsupported;check(Eligible(in)==Status::WrongFormat);in.format=BachataP33::Format::Bc1Rgb;
 in.guest_bytes=8*63;check(Eligible(in)==Status::ScratchTooSmall);in.guest_bytes=512+8;check(Eligible(in)==Status::ScratchTooSmall);in.guest_bytes=8192;
 in.guest_bytes=256u*1024u*1024u+1;check(Eligible(in)==Status::ScratchTooSmall);in.guest_bytes=8192;
 in.format=BachataP33::Format::Bc3;in.guest_bits=128;check(Eligible(in)==Status::Eligible);
 in.guest_bytes=512;check(Eligible(in)==Status::ScratchTooSmall);in.guest_bytes=8192;
 for(auto f:{BachataP33::Format::Bc1Rgb,BachataP33::Format::Bc1Rgba,BachataP33::Format::Bc3}){
   in.format=f;in.guest_bits=f==BachataP33::Format::Bc3?128:64;
   check(Eligible(in)==Status::Eligible);
   check(ValidateMip(in,{0,8192,64,64},0)==Status::Eligible);
 }
 std::cout<<"P34_TILED_BCN_POLICY_PASS assertions="<<assertions<<'\n';
}
