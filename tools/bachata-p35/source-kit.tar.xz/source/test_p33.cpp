#include "p33_bcn_linear_policy.hpp"
#include <cassert>
#include <iostream>
#include <limits>
using namespace BachataP33;
int main(){
 unsigned tests=0;
 const auto check=[&](bool b){assert(b);++tests;};
 Input in{.format=Format::Bc1Rgba,.image_format_supported=false,.rgba_host_supported=true,
         .width=8,.height=8,.mips=3,.layers=1,.samples=1,.guest_bits=64};
 check(Eligible(in)==Gate::Eligible);
 check(CheckMip(in,{0,32,8,8},56,0).gate==Gate::Eligible);
 check(CheckMip(in,{32,8,4,4},56,1).gate==Gate::Eligible);
 check(CheckMip(in,{40,8,4,4},56,2).gate==Gate::Eligible);
 check(CheckMip(in,{0,8,8,8},56,0).gate==Gate::InvalidLayout);
 check(CheckMip(in,{0,32,4,8},56,0).gate==Gate::InvalidLayout);
 check(CheckMip(in,{50,8,8,8},56,0).gate==Gate::InvalidLayout);
 check(CheckMip(in,{0,32,8,8},56,4).gate==Gate::InvalidLayout);
 for(auto format: {Format::Bc1Rgb,Format::Bc1Rgba,Format::Bc3}) {
    in.format=format; in.guest_bits=(format==Format::Bc3?128:64);
    check(Eligible(in)==Gate::Eligible);
 }
 in.format=Format::Bc3;in.guest_bits=128;
 check(CheckMip(in,{0,64,8,8},88,0).gate==Gate::Eligible);
 in.tiled=true;check(Eligible(in)==Gate::TiledOrVolume);in.tiled=false;
 in.volume=true;check(Eligible(in)==Gate::TiledOrVolume);in.volume=false;
 in.layers=2;check(Eligible(in)==Gate::Shape);in.layers=1;
 in.image_format_supported=true;check(Eligible(in)==Gate::HostUnavailable);in.image_format_supported=false;
 in.rgba_host_supported=false;check(Eligible(in)==Gate::HostUnavailable);in.rgba_host_supported=true;
 in.guest_bits=64;check(Eligible(in)==Gate::Bytes);in.guest_bits=128;
 in.format=Format::Unsupported;check(Eligible(in)==Gate::UnsupportedFormat);in.format=Format::Bc3;
 in.width=0;check(Eligible(in)==Gate::Shape);in.width=8;
 in.width=16385;check(Eligible(in)==Gate::Shape);in.width=8;
 in.mips=17;check(Eligible(in)==Gate::Shape);in.mips=3;
 in.samples=4;check(Eligible(in)==Gate::Shape);in.samples=1;
 check(CheckMip(in,{std::numeric_limits<size_t>::max()-3,16,8,8},40,0).gate==Gate::InvalidLayout);
 check(CheckMip(in,{0,64,std::numeric_limits<uint32_t>::max(),8},100,0).gate==Gate::InvalidLayout);
 std::cout<<"P33_LINEAR_BCN_POLICY_PASS checks="<<tests<<"\n";
}
