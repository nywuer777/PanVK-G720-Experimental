// SPDX-License-Identifier: GPL-2.0-or-later
// P24 source-level prototype for future port into matching GLIBC/FEX core.
// Does NOT modify/replace the running Vulkan renderer.
#pragma once
#include <cstdint>
#include <limits>

namespace BachataP24 {

enum class PixelFormat : uint8_t {
    Unknown, Bc1Unorm, Bc1Srgb, Bc3Unorm, Bc3Srgb, Rgba8Unorm, Rgba8Srgb
};
enum class ViewStatus : uint8_t {
    Ok, InvalidRange, UnknownFormat, NotDecoded, BackingMismatch,
    MutableFormatNotAuthorized, UnsupportedFormat
};
struct DecodedViewRequest {
    PixelFormat guest_format = PixelFormat::Unknown;
    PixelFormat backing_format = PixelFormat::Unknown;
    bool decoded_bcn = false;
    bool sampled_usage = true;
    // VK_IMAGE_CREATE_MUTABLE_FORMAT_BIT, supported view format and VkImageFormatListCreateInfo
    // must ALL have been verified in the production Vulkan implementation.
    bool mutable_compatible_view_confirmed = false;
    uint32_t base_mip = 0;
    uint32_t mip_levels = 0;
    uint32_t available_mip_levels = 0;
    uint32_t base_layer = 0;
    uint32_t layer_count = 0;
    uint32_t available_layers = 0;
};
struct ViewDecision {
    ViewStatus status = ViewStatus::UnsupportedFormat;
    PixelFormat sampled_format = PixelFormat::Unknown;
    uint32_t base_mip = 0;
    uint32_t mip_levels = 0;
    uint32_t base_layer = 0;
    uint32_t layer_count = 0;
    bool requires_reinterpretation = false;
    constexpr bool allowed() const { return status == ViewStatus::Ok; }
};
constexpr bool IsBc(PixelFormat p) {
    return p == PixelFormat::Bc1Unorm || p == PixelFormat::Bc1Srgb ||
           p == PixelFormat::Bc3Unorm || p == PixelFormat::Bc3Srgb;
}
constexpr bool IsSrgb(PixelFormat p) {
    return p == PixelFormat::Bc1Srgb || p == PixelFormat::Bc3Srgb || p == PixelFormat::Rgba8Srgb;
}
constexpr bool IsRgba(PixelFormat p) {
    return p == PixelFormat::Rgba8Unorm || p == PixelFormat::Rgba8Srgb;
}
constexpr ViewDecision ResolveDecodedBcnSampledView(DecodedViewRequest r) {
    ViewDecision out;
    if (!r.mip_levels || !r.available_mip_levels || !r.layer_count || !r.available_layers ||
        r.base_mip >= r.available_mip_levels ||
        r.mip_levels > r.available_mip_levels - r.base_mip ||
        r.base_layer >= r.available_layers ||
        r.layer_count > r.available_layers - r.base_layer) {
        out.status = ViewStatus::InvalidRange;
        return out;
    }
    if (!IsBc(r.guest_format)) { out.status = ViewStatus::UnsupportedFormat; return out; }
    if (!r.sampled_usage) { out.status = ViewStatus::UnsupportedFormat; return out; }
    if (!r.decoded_bcn) { out.status = ViewStatus::NotDecoded; return out; }
    if (!IsRgba(r.backing_format)) { out.status = ViewStatus::BackingMismatch; return out; }
    // Crucially, do NOT view an RGBA-decoded allocation as BCn compressed texels.
    // sRGB and UNORM RGBA8 belong to the same format compatibility class, but
    // switching requires the actual VkImage mutable-format contract.
    const PixelFormat required = IsSrgb(r.guest_format) ? PixelFormat::Rgba8Srgb
                                                       : PixelFormat::Rgba8Unorm;
    if (required != r.backing_format && !r.mutable_compatible_view_confirmed) {
        out.status = ViewStatus::MutableFormatNotAuthorized;
        return out;
    }
    out.status = ViewStatus::Ok;
    out.sampled_format = required;
    out.base_mip = r.base_mip;
    out.mip_levels = r.mip_levels;
    out.base_layer = r.base_layer;
    out.layer_count = r.layer_count;
    out.requires_reinterpretation = required != r.backing_format;
    return out;
}

struct GuestMemoryRange { uint64_t address = 0, size = 0; };
// Half-open interval overlap, rejecting overflow and empty ranges. Never log addresses.
constexpr bool ValidRange(GuestMemoryRange r) {
    return r.size > 0 && r.address <= std::numeric_limits<uint64_t>::max() - r.size;
}
constexpr bool Overlap(GuestMemoryRange a, GuestMemoryRange b) {
    return ValidRange(a) && ValidRange(b) && a.address < b.address + b.size &&
           b.address < a.address + a.size;
}
enum class AliasStatus : uint8_t {
    NoConflict, SnapshotRequired, BlockInvalidRange, BlockNoReadSnapshot,
    BlockUnsupportedStorageAlias
};
struct AliasRequest {
    GuestMemoryRange sampled;
    GuestMemoryRange storage;
    bool sampled_reads = true;
    bool storage_writes = true;
    bool storage_atomics = false;
    bool can_create_independent_read_snapshot = false;
    bool can_schedule_copy_before_draw = false;
    bool can_sync_copy_and_shader_reads = false;
    bool multiple_overlapping_storage_outputs = false;
};
struct AliasDecision {
    AliasStatus status;
    bool needs_pre_draw_read_snapshot;
    bool must_preserve_storage_writes;
    constexpr bool safe_to_continue_without_snapshot() const {
        return status == AliasStatus::NoConflict;
    }
};
constexpr AliasDecision ClassifyStorageImageAlias(AliasRequest r) {
    if (!ValidRange(r.sampled) || !ValidRange(r.storage))
        return {AliasStatus::BlockInvalidRange, false, false};
    if (!r.sampled_reads || (!r.storage_writes && !r.storage_atomics) ||
        !Overlap(r.sampled, r.storage))
        return {AliasStatus::NoConflict, false, r.storage_writes || r.storage_atomics};
    if (r.multiple_overlapping_storage_outputs)
        return {AliasStatus::BlockUnsupportedStorageAlias, false, true};
    if (!r.can_create_independent_read_snapshot || !r.can_schedule_copy_before_draw ||
        !r.can_sync_copy_and_shader_reads)
        return {AliasStatus::BlockNoReadSnapshot, false, true};
    // This is a *plan*, not an implemented Vulkan image snapshot. The renderer
    // must create a distinct image, copy the relevant image data BEFORE the draw,
    // bind sampled descriptors to snapshot and storage descriptors to original,
    // and use synchronization2 with correct layout/queue ownership barriers.
    return {AliasStatus::SnapshotRequired, true, true};
}
}
