#!/usr/bin/env python3
"""P28 asynchronous upload source adapter; pinned public source, no F43DEV APK change.

First applies the P25/P26/P27 transformations to an EXACT upstream checkout,
then registers P28's lifetime-preserving Vulkan upload adapter. Dry-run default.
"""
from pathlib import Path
import argparse, difflib, hashlib, json, shutil, subprocess
import port_renderer_p25 as p25
import port_renderer_p27 as p27

CMAKE='CMakeLists.txt'
RELS=p27.RELS
P28_FILES=('p28_async_ticket.hpp','p28_vk_async_upload.hpp','p28_vk_async_upload.cpp')
IMAGE_SHA_PIN={
 'src/video_core/texture_cache/image.h': '6af58cbbece05a32aafd1a8a3f93c6b775f9ee9c',
 'src/video_core/texture_cache/image.cpp': 'a227c5d8d0c460a35c29df2cbb964eca61d1dfa3',
 'src/video_core/texture_cache/image_view.cpp': '28f6e17e34b7e950f3234c8bc3abd72b46f032bf',
 'src/video_core/renderer_vulkan/vk_rasterizer.cpp': '99db69505bd3b5e34e5e49251a9b94955f51f081',
 'CMakeLists.txt': 'e56c54a142c5c1dbee1818574dfaf20ae4724408',
}

def transform(inputs):
    result=p27.transform(inputs)
    cm=result[CMAKE]
    anchor='               src/video_core/renderer_vulkan/p27_vk_decoded_upload.cpp'
    if cm.count(anchor)!=1: raise ValueError('P28_CMAKE_ANCHOR_MISSING_OR_AMBIGUOUS')
    result[CMAKE]=cm.replace(anchor,
       anchor+'\n               src/video_core/renderer_vulkan/p28_vk_async_upload.cpp',1)
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path('p28-port.diff'))
    p.add_argument('--write',action='store_true')
    p.add_argument('--synthetic-fixture',action='store_true',help='tests only; not release evidence')
    a=p.parse_args()
    if not a.synthetic_fixture:
        head=subprocess.run(['git','-C',str(a.source_root),'rev-parse','HEAD'],
                            capture_output=True,text=True,check=True).stdout.strip()
        if head!=p25.EXPECTED_UPSTREAM:raise ValueError('WRONG_UPSTREAM_REVISION')
        if subprocess.run(['git','-C',str(a.source_root),'status','--porcelain',
           '--untracked-files=no'],capture_output=True,text=True,check=True).stdout.strip():
            raise ValueError('DIRTY_WORKTREE')
        # Ensure the five source files have the reviewed git blob hashes.
        for rel,sha in IMAGE_SHA_PIN.items():
            actual=subprocess.run(['git','-C',str(a.source_root),'hash-object',rel],
                                  capture_output=True,text=True,check=True).stdout.strip()
            if actual!=sha:raise ValueError('SOURCE_FILE_DRIFT:'+rel)
    orig={rel:(a.source_root/rel).read_text() for rel in RELS}
    modified=transform(orig)
    sources=p27.HEADERS+P28_FILES
    additions={f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
               for name in sources}
    for name,src in additions.items():
        if not src.is_file():raise ValueError('MISSING_HEADER_SOURCE:'+str(src))
        if (a.source_root/name).exists():raise ValueError('TARGET_EXISTS:'+name)
    diff=''.join(''.join(difflib.unified_diff(orig[n].splitlines(True),modified[n].splitlines(True),
        fromfile='a/'+n,tofile='b/'+n)) for n in RELS)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(diff)
    if a.write:
        for name,data in modified.items():(a.source_root/name).write_text(data)
        for name,src in additions.items():
            dst=a.source_root/name;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
    print(json.dumps({'schema':'p28-source-port-v1','source_pin':p25.EXPECTED_UPSTREAM,
        'dry_run':not a.write,'files_modified':RELS,'files_added':sorted(additions),
        'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),
        'full_core_compiled':False,'device_tested':False,'apk_modified':False},sort_keys=True))
if __name__=='__main__':main()
