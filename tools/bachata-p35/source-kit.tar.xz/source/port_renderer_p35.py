#!/usr/bin/env python3
"""P35 runtime shader-image alias diagnostics on exact pinned *public* core.

No image or descriptor rewrites, no addresses emitted, no APK produced.
"""
from pathlib import Path
import argparse,difflib,hashlib,json,shutil,subprocess,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p34 as p34
import port_renderer_p25 as p25
R='src/video_core/renderer_vulkan/vk_rasterizer.cpp'
FILES=p34.p33.ROOT_FILES
ADDED='src/video_core/renderer_vulkan/p35_image_alias_probe.hpp'
def once(content,old,new,label):
    n=content.count(old)
    if n!=1:raise ValueError(f'P35_{label}_ANCHOR_{n}')
    return content.replace(old,new,1)

def transform(inputs):
    out=p34.transform(inputs)
    rast=out[R]
    rast=once(rast,'#include "video_core/renderer_vulkan/p26_alias_dispatch_gate.hpp"',
                  '#include "video_core/renderer_vulkan/p26_alias_dispatch_gate.hpp"\n'
                  '#include "video_core/renderer_vulkan/p35_image_alias_probe.hpp"\n'
                  '#include "video_core/staging_diag.h"\n#include <atomic>\n#include <vector>', 'includes')
    anchor='    // Second pass to re-bind images that were updated after binding'
    inserted='''    // P35_ALIAS_ACTIVE_BINDTEXTURES: OFF unless opt-in BACHATA_STAGING_VERBOSE.
    // Bound resource ids and access semantics are gathered from the shader's
    // real descriptor list. Never expose guest addresses, shader binary, tokens,
    // descriptor addresses or texture contents in logs.
    if (VideoCore::StagingVerbose()) {
        struct Intent { bool atomic=false; bool dynamic_mip=false; };
        std::vector<Intent> intents;
        bool overflow=false;
        for (const auto& resource : stage.images) {
            const auto sharp = resource.GetSharp(stage);
            const u32 expanded = sharp.GetDataFmt() == AmdGpu::DataFormat::FormatInvalid
                                     ? 1u : resource.NumBindings(stage);
            if (expanded > BachataP35::MaxBindings ||
                expanded > BachataP35::MaxBindings - intents.size()) {
                overflow=true;
                break;
            }
            for (u32 j=0;j<expanded;++j) {
                intents.emplace_back(Intent{
                    .atomic=resource.is_atomic,
                    .dynamic_mip=resource.mip_fallback_mode==
                        Shader::MipStorageFallbackMode::DynamicIndex,
                });
            }
        }
        std::array<BachataP35::Binding,BachataP35::MaxBindings> descriptors{};
        BachataP35::Result result{};
        if (overflow || image_bindings.size()>BachataP35::MaxBindings) {
            result.kind=BachataP35::Hazard::CapacityExceeded;
        } else if (intents.size()!=image_bindings.size()) {
            result.kind=BachataP35::Hazard::MetadataMismatch;
        } else {
            for (size_t i=0;i<image_bindings.size();++i) {
                const auto& [img_id, img_desc]=image_bindings[i];
                if(!img_id)continue;
                const auto& bound=texture_cache.GetImage(img_id);
                const bool atomic=intents[i].atomic;
                const bool write=img_desc.type==VideoCore::TextureCache::BindingType::Storage;
                descriptors[i]={
                    .begin=static_cast<std::uint64_t>(bound.info.guest_address),
                    .bytes=static_cast<std::uint64_t>(bound.info.guest_size),
                    .access=atomic ? BachataP35::Access::StorageAtomic :
                            write ? BachataP35::Access::StorageWrite :
                                    BachataP35::Access::Sampled,
                    .valid=true,.dynamic_mip=intents[i].dynamic_mip,
                };
            }
            result=BachataP35::Inspect(std::span<const BachataP35::Binding>(
                descriptors.data(),image_bindings.size()),intents.size());
        }
        if(result.kind!=BachataP35::Hazard::None) {
            static std::atomic<u32> observations{0};
            const u32 seq=observations.fetch_add(1,std::memory_order_relaxed);
            if (seq<16 || seq%256==0) {
                LOG_WARNING(Render_Vulkan,
                    "P35_ALIAS_INTENT kind={} pair={} {} atomic={} dynamicMip={} "
                    "floatAtomicFeature={} descriptorRewrite=0 sampleStorageOverlap={}",
                    static_cast<unsigned>(result.kind),result.lhs,result.rhs,
                    result.has_atomic ? 1 : 0,result.has_dynamic_mip ? 1 : 0,
                    stage.uses_image_atomic_float_min_max ? 1 : 0,
                    result.sample_storage_overlap ? 1 : 0);
            }
        }
    }
'''
    rast=once(rast,anchor,inserted+anchor,'active_alias_probe')
    out[R]=rast
    return out

def main():
    arg=argparse.ArgumentParser()
    arg.add_argument('--source-root',type=Path,required=True)
    arg.add_argument('--out',type=Path,default=Path('p35-port.diff'))
    arg.add_argument('--write',action='store_true')
    arg.add_argument('--synthetic-fixture',action='store_true')
    a=arg.parse_args()
    if not a.synthetic_fixture:
        def git(*args):return subprocess.run(['git','-C',str(a.source_root),*args],capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD')!=p25.EXPECTED_UPSTREAM:raise ValueError('P35_WRONG_REVISION')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P35_DIRTY_TREE')
        for rel,sha in p34.p33.p28.IMAGE_SHA_PIN.items():
            if git('hash-object',rel)!=sha:raise ValueError('P35_PINNED_SOURCE_DRIFT:'+rel)
    src={p:(a.source_root/p).read_text() for p in FILES}
    dst=transform(src)
    additions={f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
               for name in (*p34.p33.p28.p27.HEADERS,*p34.p33.p28.P28_FILES,
                            'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                            'p35_image_alias_probe.hpp')}
    for path,f in additions.items():
        if not f.is_file() or (a.source_root/path).exists():raise ValueError('P35_NEW_HEADER_BLOCKED:'+path)
    diff=''.join(''.join(difflib.unified_diff(src[k].splitlines(True),dst[k].splitlines(True),
          fromfile='a/'+k,tofile='b/'+k)) for k in FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(diff)
    if a.write:
        for k,v in dst.items():(a.source_root/k).write_text(v)
        for path,f in additions.items():
            dest=a.source_root/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
    print(json.dumps({'schema':'P35_ALIAS_OBSERVATION_ONLY',
       'source_revision':p25.EXPECTED_UPSTREAM,'build_executed':False,
       'bindtextures_instrumented':True,'gpu_state_modified':False,
       'opt_in_staging_verbose':True,'private_addresses_logged':False,
       'outlast_fixed':False,'minecraft_fixed':False,'apk_built':False,
       'diff_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
