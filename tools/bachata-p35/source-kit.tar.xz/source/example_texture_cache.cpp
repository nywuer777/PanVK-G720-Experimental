#include "video_core/texture_cache/tile_manager.h"
#include "video_core/renderer_vulkan/p27_upload_plan.hpp"
#include "video_core/renderer_vulkan/p27_vk_decoded_upload.hpp"
#include "video_core/renderer_vulkan/p33_bcn_linear_policy.hpp"
#include "video_core/buffer_cache/buffer.h"
#include <bit>
#include <memory>
#include <vector>
void TextureCache::RefreshImage(Image& image) {
    if (image.p33_linear_bcn_fallback) {
        // This is the ONLY supported active route. No blind upload of compressed
        // data into the host RGBA allocation if validation fails.
        ASSERT_MSG(image.info.guest_address && image.info.resources.layers == 1 &&
                   !image.info.props.is_tiled && !image.info.props.is_volume,
                   "P33 BCn linear fallback cannot read tiled or invalid guest memory");
        ASSERT_MSG(False(image.flags & ImageFlagBits::GpuModified),
                   "P33 linear BCn fallback cannot overwrite GPU-modified image");
        const auto p33_fmt = image.p33_format == BachataP33::Format::Bc3
            ? BachataP26::BcnFormat::BC3
            : image.p33_format == BachataP33::Format::Bc1Rgba
                ? BachataP26::BcnFormat::BC1_RGBA : BachataP26::BcnFormat::BC1_RGB;
        const BachataP33::Input p33_input{
            .format=image.p33_format, .srgb=image.p33_srgb,
            .tiled=false, .volume=false,
            .image_format_supported=false, .rgba_host_supported=true,
            .width=image.info.size.width, .height=image.info.size.height,
            .mips=image.info.resources.levels, .layers=1, .samples=1,
            .guest_bits=image.info.num_bits,
        };
        std::vector<BachataP27::CompressedSubresource> subs;
        subs.reserve(image.info.resources.levels);
        const auto* guest = std::bit_cast<const u8*>(image.info.guest_address);
        for (u32 mip=0; mip<image.info.resources.levels; ++mip) {
            const auto& layout=image.info.mips_layout[mip];
            const auto check=BachataP33::CheckMip(p33_input,
                {layout.offset,layout.size,layout.pitch,layout.height},
                image.info.guest_size,mip);
            ASSERT_MSG(check.gate == BachataP33::Gate::Eligible,
                       "P33 BCn linear image has invalid pitch or bounded mip layout");
            subs.push_back(BachataP27::CompressedSubresource{
                .mip=mip, .layer=0,
                .width=std::max(1u,image.info.size.width>>mip),
                .height=std::max(1u,image.info.size.height>>mip),
                .row_stride=check.row_stride,
                .blocks=std::span<const u8>(guest+layout.offset,layout.size),
            });
        }
        const auto plan=BachataP27::BuildPlan(p33_fmt,image.p33_srgb,
            image.info.size.width,image.info.size.height,
            image.info.resources.levels,1,subs);
        ASSERT_MSG(plan.status==BachataP27::PlanStatus::Ok && !plan.staging.empty(),
                   "P33 BCn linear decode or staging layout was rejected");
        // A completion wait is intentional for first correctness bring-up:
        // ImageView's P25 attestation may not pass before GPU completion.
        // P28 async rework needs a view-safe completion callback before opt-in.
        Buffer staging(instance,scheduler,MemoryUsage::Upload,0,ReadFlags,
                       plan.staging.size());
        const unsigned generation=image.backing->p26_upload_journal.generation+1;
        ASSERT_MSG(generation != 0, "P33 BCn upload journal generation overflow");
        const auto result=BachataP27::UploadDecodedToRgba(plan,image,staging,instance,
                                                           scheduler,generation);
        ASSERT_MSG(result == BachataP27::UploadResult::Uploaded,
                   "P33 BCn linear Vulkan upload or completion proof failed");
        image.flags &= ~ImageFlagBits::Dirty;
        LOG_WARNING(Render_Vulkan, "P33_BCN_LINEAR_ACTIVE uploaded levels={} srgb={}",
                    image.info.resources.levels,image.p33_srgb ? 1 : 0);
        return;
    }

    const u32 num_layers = image.info.resources.layers;
}
vk::Sampler TextureCache::GetSampler(foo) {}
