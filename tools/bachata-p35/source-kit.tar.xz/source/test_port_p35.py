import sys, unittest, tempfile, subprocess, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_port_p33 import P33Port
import port_renderer_p35 as p35
ROOT=Path(__file__).resolve().parent
class P35Port(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  t=P33Port();t.setUpClass();cls.fixture=t.f
 def test_has_active_shader_route(self):
  r=p35.transform(self.fixture)['src/video_core/renderer_vulkan/vk_rasterizer.cpp']
  for mark in ('P35_ALIAS_ACTIVE_BINDTEXTURES','stage.images','image_bindings',
      'resource.is_atomic','stage.uses_image_atomic_float_min_max',
      'BachataP35::Inspect','VideoCore::StagingVerbose()','P35_ALIAS_INTENT'):
   self.assertIn(mark,r)
 def test_no_address_or_shader_content_log(self):
  r=p35.transform(self.fixture)['src/video_core/renderer_vulkan/vk_rasterizer.cpp']
  marker=r.index('"P35_ALIAS_INTENT kind=')
  chunk=r[marker:marker+520]
  for secret in ('guest_address','stage.pgm_hash','Base()','userdata','img_desc'):
   self.assertNotIn(secret,chunk)
 def test_no_image_or_descriptor_rewrite(self):
  before=p35.p34.transform(self.fixture)
  after=p35.transform(self.fixture)
  self.assertEqual(before['src/video_core/texture_cache/texture_cache.cpp'],
                   after['src/video_core/texture_cache/texture_cache.cpp'])
  self.assertEqual(before['src/video_core/texture_cache/image_view.cpp'],
                   after['src/video_core/texture_cache/image_view.cpp'])
  self.assertEqual(before['src/video_core/texture_cache/image.cpp'],
                   after['src/video_core/texture_cache/image.cpp'])
 def test_no_mutation(self):
  f=self.fixture.copy();p35.transform(self.fixture);self.assertEqual(f,self.fixture)
 def test_double_apply_fail_closed(self):
  with self.assertRaises(ValueError):p35.transform(p35.transform(self.fixture))
 def test_missing_anchor_fail_closed(self):
  f=self.fixture.copy();f[p35.R]='bad source'
  with self.assertRaises(ValueError):p35.transform(f)
 def test_extra_anchor_rejected(self):
  f=self.fixture.copy();f[p35.R]=f[p35.R]*2
  with self.assertRaises(ValueError):p35.transform(f)
 def test_synthetic_apply_once(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)
   for rel,body in self.fixture.items():
    f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
   cmd=[sys.executable,str(ROOT/'port_renderer_p35.py'),'--source-root',str(root),
        '--out',str(root/'p35.diff'),'--synthetic-fixture']
   result=subprocess.run(cmd,text=True,capture_output=True,check=True)
   parsed=json.loads(result.stdout)
   self.assertTrue(parsed['bindtextures_instrumented']);self.assertFalse(parsed['gpu_state_modified'])
   self.assertEqual((root/p35.R).read_text(),self.fixture[p35.R]);
   subprocess.run(cmd+['--write'],text=True,capture_output=True,check=True)
   self.assertIn('P35_ALIAS_INTENT',(root/p35.R).read_text())
   self.assertTrue((root/p35.ADDED).is_file())
   self.assertNotEqual(subprocess.run(cmd+['--write'],text=True,capture_output=True).returncode,0)
 def test_no_false_fix_claims(self):
  s=(ROOT/'port_renderer_p35.py').read_text()
  self.assertIn("'outlast_fixed':False",s)
  self.assertIn("'minecraft_fixed':False",s)
  for unsafe in ('apktool','apksigner','HOST_IDENTITY_ACCEPT_ANY','robustImageAccess2',
                 'bypass_assertions','--bachata-saf-token'):
   self.assertNotIn(unsafe,s)
 def test_runtime_rate_limit(self):
  s=p35.transform(self.fixture)[p35.R]
  self.assertIn('seq<16 || seq%256==0',s)
  self.assertIn('descriptorRewrite=0',s)
 def test_retains_p34_upload(self):
  s=p35.transform(self.fixture)['src/video_core/texture_cache/texture_cache.cpp']
  self.assertIn('P34_GPUTILE_DETILE_READBACK',s)
  self.assertIn('BachataP27::UploadDecodedToRgba',s)
 def test_header_warns_no_descriptor_rewrites(self):
  s=(ROOT/'p35_image_alias_probe.hpp').read_text()
  self.assertIn('can_rewrite_descriptors=false',s)
  self.assertIn('std::span<const Binding>',s)
if __name__=='__main__':unittest.main(verbosity=2)
