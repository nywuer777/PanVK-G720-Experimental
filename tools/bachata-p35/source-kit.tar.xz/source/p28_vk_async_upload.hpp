// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
#include "video_core/renderer_vulkan/p27_upload_plan.hpp"
#include "video_core/renderer_vulkan/p28_async_ticket.hpp"
#include <memory>
namespace VideoCore { struct Image; class Buffer; }
namespace Vulkan { class Instance; class Scheduler; }
namespace BachataP28 {
enum class StartStatus : unsigned char { Queued, InvalidPlan, IncompatibleBacking,
    InvalidStaging, UnsupportedFeatures, GenerationConflict };
struct Started {
    StartStatus status=StartStatus::InvalidPlan;
    Ticket ticket{};
};
// Takes exclusive staging ownership; scheduler holds the memory alive until the
// recorded GPU timeline tick completes. Do not access the moved staging buffer.
Started RecordDecodedUpload(const BachataP27::PlanResult& plan,
    VideoCore::Image& image, std::shared_ptr<VideoCore::Buffer> staging,
    const Vulkan::Instance& instance, Vulkan::Scheduler& scheduler,
    uint32_t generation);
// Caller supplies a LIVE image. This function never waits/flushes or submits.
// It deliberately does not capture an Image* inside a deferred callback.
PollStatus PollDecodedUpload(Ticket& ticket, VideoCore::Image& image,
    Vulkan::Scheduler& scheduler);
}
