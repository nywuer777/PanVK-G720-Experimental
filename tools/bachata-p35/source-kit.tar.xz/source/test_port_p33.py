import sys, unittest, tempfile, subprocess, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p25 as p25
import port_renderer_p33 as p33
ROOT=Path(__file__).resolve().parent
class P33Port(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.f={
    'src/video_core/texture_cache/image.h':'#pragma once\n'+p25.OLD_IMAGE_HEADER+'\n    ImageInfo info;\n    void Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer, u64 offset);\n',
    'src/video_core/texture_cache/image_view.cpp':'#include "video_core/texture_cache/image.h"\n'+p25.OLD_VIEW_HEAD+'\n',
    'src/video_core/renderer_vulkan/vk_rasterizer.cpp':'#include <array>\n'+p25.OLD_RASTER_ANCHOR+'\n',
    'src/video_core/texture_cache/image.cpp':'''void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,
                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {}
void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,
                   u64 offset) {
    SetBackingSamples(info.num_samples, false);
        .size = info.guest_size,
        .size = info.guest_size,
}
void Image::Download(xxx) {}
    constexpr auto tiling = vk::ImageTiling::eOptimal;
    const auto supported_format = instance->GetSupportedFormat(info.pixel_format, format_features);
''',
    'CMakeLists.txt':'               src/video_core/renderer_vulkan/vk_rasterizer.cpp\n',
    'src/video_core/texture_cache/texture_cache.cpp':'''#include "video_core/texture_cache/tile_manager.h"
void TextureCache::RefreshImage(Image& image) {
    const u32 num_layers = image.info.resources.layers;
}
vk::Sampler TextureCache::GetSampler(foo) {}
'''
  }
 def test_no_fallback_without_host_support(self):
  s=p33.transform(self.f)['src/video_core/texture_cache/image.cpp']
  self.assertIn('instance->IsFormatSupported(p33_rgba,format_features)',s)
  self.assertIn('flags &= ~vk::ImageCreateFlagBits::eBlockTexelViewCompatible',s)
 def test_active_upload_in_refresh(self):
  s=p33.transform(self.f)['src/video_core/texture_cache/texture_cache.cpp']
  self.assertIn('BachataP27::UploadDecodedToRgba',s)
  self.assertIn('BachataP33::CheckMip',s)
  self.assertIn('image.flags &= ~ImageFlagBits::Dirty;',s)
 def test_no_tiled_read(self):
  s=p33.transform(self.f)['src/video_core/texture_cache/texture_cache.cpp']
  self.assertIn('!image.info.props.is_tiled',s)
  self.assertIn('ImageFlagBits::GpuModified',s)
 def test_retains_guards(self):
  d=p33.transform(self.f)
  self.assertIn('P25 decoded BCn sampled view blocked',d['src/video_core/texture_cache/image_view.cpp'])
  self.assertIn('P26_ALIAS_POLICY',d['src/video_core/renderer_vulkan/vk_rasterizer.cpp'])
 def test_exceptions_on_reapply(self):
  with self.assertRaises(ValueError):p33.transform(p33.transform(self.f))
 def test_duplicate_anchors(self):
  f=self.f.copy();f['src/video_core/texture_cache/texture_cache.cpp']*=2
  with self.assertRaises(ValueError):p33.transform(f)
 def test_not_modify_inputs(self):
  old=self.f.copy();p33.transform(self.f);self.assertEqual(old,self.f)
 def test_write_fixture(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td)
   for k,v in self.f.items():
    f=root/k;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v)
   cmd=[sys.executable,str(ROOT/'port_renderer_p33.py'),'--source-root',str(root),
        '--out',str(root/'port.diff'),'--synthetic-fixture']
   r=subprocess.run(cmd,check=True,capture_output=True,text=True)
   self.assertTrue(json.loads(r.stdout)['linear_bcn_hooked'])
   self.assertEqual((root/'src/video_core/texture_cache/image.cpp').read_text(),self.f['src/video_core/texture_cache/image.cpp'])
   subprocess.run(cmd+['--write'],check=True,capture_output=True,text=True)
   self.assertTrue((root/'src/video_core/renderer_vulkan/p33_bcn_linear_policy.hpp').exists())
   self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True).returncode,0)
 def test_no_changed_settings(self):
  s=(ROOT/'port_renderer_p33.py').read_text()
  for key in ['--bachata-saf-token','NDEBUG','robustImageAccess2', 'resize_resolution']:
   self.assertNotIn(key,s)
 def test_pinned_source(self):self.assertEqual(p25.EXPECTED_UPSTREAM,'be6bc2e9c60799e071dd2fafa6216e8d80ec619c')
if __name__=='__main__':unittest.main(verbosity=2)
