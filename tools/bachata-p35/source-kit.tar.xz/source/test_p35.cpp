#include "p35_image_alias_probe.hpp"
#include <cassert>
#include <iostream>
#include <array>
#include <limits>
using namespace BachataP35;
int main(){
 unsigned n=0;
 auto check=[&](bool v){assert(v);++n;};
 auto r=[](std::uint64_t a,std::uint64_t b,Access x,bool d=false){
  return Binding{a,b,x,true,d};
 };
 std::array<Binding,2> a{r(100,200,Access::Sampled),r(200,200,Access::StorageWrite)};
 auto d=Inspect(a,2);check(d.kind==Hazard::SampleStorage);check(d.sample_storage_overlap);
 check(!d.can_rewrite_descriptors);check(!d.has_atomic);check(!d.has_dynamic_mip);
 a[0]=r(100,100,Access::Sampled);d=Inspect(a,2);check(d.kind==Hazard::None);
 a[0]=r(100,200,Access::Sampled);a[1]=r(200,200,Access::StorageAtomic);
 d=Inspect(a,2);check(d.kind==Hazard::SampleAtomic);check(d.has_atomic);
 a[0].dynamic_mip=true;d=Inspect(a,2);check(d.has_dynamic_mip);
 a[0]=r(100,200,Access::StorageWrite);d=Inspect(a,2);check(d.kind==Hazard::AtomicStorage);
 a[1].access=Access::StorageWrite;d=Inspect(a,2);check(d.kind==Hazard::StorageStorage);
 a[0].access=Access::Sampled;a[1].access=Access::Sampled;
 d=Inspect(a,2);check(d.kind==Hazard::None);
 a[0].begin=0;d=Inspect(a,2);check(d.kind==Hazard::InvalidRange);
 a[0]=r(std::numeric_limits<std::uint64_t>::max()-5,20,Access::Sampled);
 d=Inspect(a,2);check(d.kind==Hazard::InvalidRange);
 a[0]=r(100,200,Access::Sampled);a[1]=r(200,200,Access::StorageWrite);
 d=Inspect(a,1);check(d.kind==Hazard::MetadataMismatch);
 d=Inspect(std::span<const Binding>(a.data(),0),0);check(d.kind==Hazard::None);
 std::array<Binding,65> many{};d=Inspect(many,many.size());check(d.kind==Hazard::CapacityExceeded);
 a[0].valid=false;d=Inspect(a,2);check(d.kind==Hazard::None);
 a[0]=r(100,200,Access::StorageAtomic);a[1].valid=false;
 d=Inspect(a,2);check(d.kind==Hazard::None);
 check(!RangeValid(Binding{0,100,Access::Sampled,true,false}));
 check(!RangeValid(Binding{10,0,Access::Sampled,true,false}));
 check(RangeValid(Binding{10,1,Access::Sampled,true,false}));
 check(Overlap(r(10,15,Access::Sampled),r(24,3,Access::StorageWrite)));
 check(!Overlap(r(10,14,Access::Sampled),r(24,3,Access::StorageWrite)));
 // Preserve half-open disjointness and a wide-overlap case with no addresses emitted.
 for(unsigned i=1;i<33;++i){
   a[0]=r(100,100+i,Access::Sampled);a[1]=r(200,200,Access::StorageWrite);
   check(Inspect(a,2).kind==Hazard::SampleStorage);
 }
 std::cout << "P35_ALIAS_INTENT_PASS assertions=" << n << "\n";
}
