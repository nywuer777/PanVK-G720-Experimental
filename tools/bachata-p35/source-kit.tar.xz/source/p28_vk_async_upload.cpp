// SPDX-License-Identifier: GPL-2.0-or-later
// Public-core adapter. NOT wired to private F43DEV BCn fallback.
#include "video_core/renderer_vulkan/p28_vk_async_upload.hpp"
#include "video_core/texture_cache/image.h"
#include "video_core/buffer_cache/buffer.h"
#include "video_core/renderer_vulkan/vk_scheduler.h"
#include "video_core/renderer_vulkan/vk_instance.h"
#include <vk_mem_alloc.h>
#include <algorithm>
#include <bit>
#include <cstring>
#include <limits>
#include <utility>
#include <vector>

namespace BachataP28 {
Started RecordDecodedUpload(const BachataP27::PlanResult& plan,
        VideoCore::Image& image, std::shared_ptr<VideoCore::Buffer> staging,
        const Vulkan::Instance& instance, Vulkan::Scheduler& scheduler,
        uint32_t generation) {
    using namespace BachataP27;
    if (plan.status != PlanStatus::Ok || plan.regions.empty() ||
        !plan.mip_levels || plan.mip_levels>16 || !plan.array_layers ||
        !generation || plan.regions.size()!=size_t(plan.mip_levels)*plan.array_layers)
        return {StartStatus::InvalidPlan,{}};
    if (!image.backing) return {StartStatus::IncompatibleBacking,{}};
    const auto& ci=image.backing->image.image_ci;
    const vk::Format rgba=plan.srgb ? vk::Format::eR8G8B8A8Srgb : vk::Format::eR8G8B8A8Unorm;
    if (ci.format!=rgba || ci.mipLevels!=plan.mip_levels ||
        ci.arrayLayers!=plan.array_layers || ci.imageType!=vk::ImageType::e2D ||
        ci.extent.depth!=1 || ci.samples!=vk::SampleCountFlagBits::e1 ||
        !(ci.usage & vk::ImageUsageFlagBits::eTransferDst) ||
        !(ci.usage & vk::ImageUsageFlagBits::eSampled) ||
        !image.GetImage() || image.info.num_samples!=1 ||
        image.backing->num_samples!=1 ||
        image.aspect_mask!=vk::ImageAspectFlagBits::eColor)
        return {StartStatus::IncompatibleBacking,{}};
    // Passing a shared staging resource from the caller would allow it to be
    // overwritten before GPU completion. Require a unique owner, moved in.
    if (!staging || staging.use_count()!=1 || !staging->Handle() ||
        staging->usage!=VideoCore::MemoryUsage::Upload ||
        staging->mapped_data.size()<plan.staging.size() ||
        staging->SizeBytes()<plan.staging.size())
        return {StartStatus::InvalidStaging,{}};
    if (!instance.IsFormatSupported(rgba,
           vk::FormatFeatureFlagBits2::eSampledImage | vk::FormatFeatureFlagBits2::eTransferDst))
        return {StartStatus::UnsupportedFeatures,{}};
    auto& journal=image.backing->p26_upload_journal;
    if (generation<=journal.generation ||
        journal.state==BachataP26::UploadJournal::State::UploadSubmitted)
        return {StartStatus::GenerationConflict,{}};
    std::vector<vk::BufferImageCopy> copies;
    copies.reserve(plan.regions.size());
    std::vector<bool> seen(size_t(plan.mip_levels)*plan.array_layers,false);
    for (const auto& sub:plan.regions) {
        if (sub.mip>=ci.mipLevels || sub.layer>=ci.arrayLayers ||
            sub.width!=std::max(1u,ci.extent.width>>sub.mip) ||
            sub.height!=std::max(1u,ci.extent.height>>sub.mip) ||
            sub.offset%4 || sub.bytes!=size_t(sub.width)*sub.height*4 ||
            sub.offset>plan.staging.size() ||
            sub.bytes>plan.staging.size()-sub.offset)
            return {StartStatus::InvalidPlan,{}};
        const size_t idx=size_t(sub.layer)*plan.mip_levels+sub.mip;
        if (seen[idx]) return {StartStatus::InvalidPlan,{}};
        seen[idx]=true;
        copies.push_back(vk::BufferImageCopy{
            .bufferOffset=sub.offset,
            .bufferRowLength=0, .bufferImageHeight=0,
            .imageSubresource={.aspectMask=vk::ImageAspectFlagBits::eColor,
                .mipLevel=sub.mip,.baseArrayLayer=sub.layer,.layerCount=1},
            .imageOffset={0,0,0},.imageExtent={sub.width,sub.height,1},
        });
    }
    // This is a fast path for a caller that already allocated the exact RGBA
    // image and prepared validated decoded bytes. No BCn reinterpretation.
    std::memcpy(staging->mapped_data.data(),plan.staging.data(),plan.staging.size());
    if (!staging->is_coherent &&
        vmaFlushAllocation(instance.GetAllocator(),staging->buffer.allocation,0,
                           plan.staging.size())!=VK_SUCCESS)
        return {StartStatus::InvalidStaging,{}};
    // Image::Upload invalidates previous provenance (P27). All possible
    // reject conditions above occur BEFORE recording Vulkan commands.
    image.Upload(copies,staging->Handle(),0,plan.staging.size());
    if (!journal.began(plan.mip_levels,generation))
        return {StartStatus::GenerationConflict,{}};
    for (uint32_t mip=0;mip<plan.mip_levels;++mip)
        if (!journal.decoded_level(mip)) {
            journal.invalidate();
            return {StartStatus::InvalidPlan,{}};
        }
    if (!journal.submitted(true,true)) {
        journal.invalidate();
        return {StartStatus::InvalidPlan,{}};
    }
    // No Flush() or Finish(): the current command buffer is allowed to join
    // the renderer's normal submission batch. The scheduler owns staging
    // until the associated timeline tick completes.
    const uint64_t tick=scheduler.CurrentTick();
    if (!tick) { journal.invalidate(); return {StartStatus::InvalidPlan,{}}; }
    scheduler.DeferOperation([keep_alive=std::move(staging)]() mutable {
        keep_alive.reset();
    });
    return {StartStatus::Queued, Ticket{
        .timeline_tick=tick,.image_uid=image.image_uid,
        .backing_tag=std::bit_cast<uint64_t>(static_cast<VkImage>(image.GetImage())),
        .generation=generation,.mip_levels=plan.mip_levels,
        .array_layers=plan.array_layers,.active=true,
    }};
}
PollStatus PollDecodedUpload(Ticket& ticket, VideoCore::Image& image,
                             Vulkan::Scheduler& scheduler) {
    if (!ticket.active || !ticket.timeline_tick) return PollStatus::InvalidTicket;
    if (!image.backing) {ticket.active=false;return PollStatus::StaleImage;}
    auto& journal=image.backing->p26_upload_journal;
    // No IsFree call on an unsubmitted tick. IsFree is a non-waiting
    // timeline query; it is not a replacement for QueueSubmit.
    const bool submitted=scheduler.CurrentTick()>ticket.timeline_tick;
    const auto status=PollState(ticket,scheduler.CurrentTick(),
        submitted && scheduler.IsFree(ticket.timeline_tick),image.image_uid,
        std::bit_cast<uint64_t>(static_cast<VkImage>(image.GetImage())),journal.generation,
        journal.state==BachataP26::UploadJournal::State::UploadSubmitted);
    if (status==PollStatus::Completed) {
        const auto& ci=image.backing->image.image_ci;
        const bool mutable_flag=bool(ci.flags & vk::ImageCreateFlagBits::eMutableFormat);
        // The original P26 proof demands mutable compatibility; a destination
        // whose format is already the exact RGBA format has no alternate view.
        const bool same_rgba=ci.format==vk::Format::eR8G8B8A8Unorm ||
                             ci.format==vk::Format::eR8G8B8A8Srgb;
        if (!journal.completed_after_gpu_fence(true,true,true,true,
            mutable_flag,same_rgba)) {
            journal.invalidate();return PollStatus::StaleImage;
        }
    }
    return status;
}
}
