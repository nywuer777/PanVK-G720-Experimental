// SPDX-License-Identifier: GPL-2.0-or-later
// P27 actual Vulkan-call boundary for a caller-provided RGBA image and upload buffer.
#include "video_core/renderer_vulkan/p27_vk_decoded_upload.hpp"
#include "video_core/texture_cache/image.h"
#include "video_core/buffer_cache/buffer.h"
#include "video_core/renderer_vulkan/vk_scheduler.h"
#include "video_core/renderer_vulkan/vk_instance.h"
#include <vk_mem_alloc.h>
#include <cstring>
#include <algorithm>
#include <vector>
#include <limits>
namespace BachataP27 {
UploadResult DecodeAndUploadBcn(BcnFormat format, bool srgb,
    uint32_t width,uint32_t height,uint32_t levels,uint32_t layers,
    std::span<const CompressedSubresource> input,
    VideoCore::Image& image,VideoCore::Buffer& staging,
    const Vulkan::Instance& instance,Vulkan::Scheduler& scheduler,unsigned generation) {
    const auto plan=BuildPlan(format,srgb,width,height,levels,layers,input);
    if(plan.status!=PlanStatus::Ok) return UploadResult::BlockedInvalidPlan;
    return UploadDecodedToRgba(plan,image,staging,instance,scheduler,generation);
}
UploadResult UploadDecodedToRgba(const PlanResult& plan, VideoCore::Image& image,
    VideoCore::Buffer& staging, const Vulkan::Instance& instance,
    Vulkan::Scheduler& scheduler, unsigned generation) {
    if (plan.status!=PlanStatus::Ok || plan.regions.empty() ||
        plan.mip_levels>16 || !generation) return UploadResult::BlockedInvalidPlan;
    if (!image.backing) return UploadResult::BlockedBacking;
    const auto& ci=image.backing->image.image_ci;
    const auto needed_format=plan.srgb ? vk::Format::eR8G8B8A8Srgb : vk::Format::eR8G8B8A8Unorm;
    if (ci.format != needed_format || ci.mipLevels != plan.mip_levels ||
        ci.arrayLayers != plan.array_layers || ci.imageType!=vk::ImageType::e2D ||
        ci.extent.depth!=1 || ci.samples!=vk::SampleCountFlagBits::e1 ||
        !(ci.usage & vk::ImageUsageFlagBits::eTransferDst) ||
        !(ci.usage & vk::ImageUsageFlagBits::eSampled) ||
        !image.GetImage() || image.backing->num_samples != image.info.num_samples ||
        image.info.num_samples != 1) return UploadResult::BlockedBacking;
    if (staging.mapped_data.size() < plan.staging.size() ||
        staging.SizeBytes() < plan.staging.size() || !staging.Handle() ||
        staging.usage != VideoCore::MemoryUsage::Upload)
        return UploadResult::BlockedStaging;
    if (!instance.IsFormatSupported(needed_format,
             vk::FormatFeatureFlagBits2::eSampledImage | vk::FormatFeatureFlagBits2::eTransferDst))
        return UploadResult::BlockedVulkanFeatures;
    // Validate the exact allocation and subresource coverage before touching GPU resources.
    DestinationProof proof{};
    proof.destination_rgba8=true; proof.exact_srgb_match=true;
    proof.transfer_dst_usage=true; proof.sampled_image_feature=true;
    proof.color_aspect=image.aspect_mask==vk::ImageAspectFlagBits::eColor;
    proof.external_staging_buffer_sufficient=true; proof.external_staging_buffer_mapped=true;
    proof.dimension_and_subresource_match=true;
    if (plan.regions.size()!=static_cast<size_t>(plan.mip_levels)*plan.array_layers)
        return UploadResult::BlockedInvalidPlan;
    std::vector<vk::BufferImageCopy> copies; copies.reserve(plan.regions.size());
    for (const auto& sub:plan.regions) {
        if (sub.offset%4 || sub.mip>=ci.mipLevels || sub.layer>=ci.arrayLayers ||
            sub.width!=std::max(1u,ci.extent.width>>sub.mip) ||
            sub.height!=std::max(1u,ci.extent.height>>sub.mip) ||
            sub.bytes!=static_cast<size_t>(sub.width)*sub.height*4 ||
            sub.offset>plan.staging.size() || sub.bytes>plan.staging.size()-sub.offset)
            return UploadResult::BlockedInvalidPlan;
        copies.push_back(vk::BufferImageCopy{
            .bufferOffset=sub.offset, .bufferRowLength=0, .bufferImageHeight=0,
            .imageSubresource={.aspectMask=vk::ImageAspectFlagBits::eColor,
                              .mipLevel=sub.mip,.baseArrayLayer=sub.layer,.layerCount=1},
            .imageOffset={0,0,0},
            .imageExtent={sub.width,sub.height,1},
        });
    }
    if(!MaySubmit(plan,proof)) return UploadResult::BlockedInvalidPlan;
    // Reject reuse of the active generation BEFORE any GPU action.
    if (generation<=image.backing->p26_upload_journal.generation)
        return UploadResult::BlockedInvalidPlan;
    std::memcpy(staging.mapped_data.data(),plan.staging.data(),plan.staging.size());
    if (!staging.is_coherent && vmaFlushAllocation(instance.GetAllocator(),
            staging.buffer.allocation,0,plan.staging.size()) != VK_SUCCESS) {
        return UploadResult::BlockedStaging;
    }
    // Real Vulkan command recording occurs in Image::Upload. That routine
    // invalidates any prior attestation and may touch the selected backing.
    image.Upload(copies, staging.Handle(), 0, plan.staging.size());
    auto& journal=image.backing->p26_upload_journal;
    if (!journal.began(plan.mip_levels,generation)) return UploadResult::BlockedInvalidPlan;
    for (unsigned i=0;i<plan.mip_levels;++i) {
        if (!journal.decoded_level(i)) {journal.invalidate();return UploadResult::BlockedInvalidPlan;}
    }
    if (!journal.submitted(true,true)) {journal.invalidate();return UploadResult::BlockedInvalidPlan;}
    // Intentionally waits for GPU completion in this *laboratory* path, not
    // suitable for per-texture production. Replace with async timeline tickets.
    scheduler.Finish();
    const bool mutable_create=static_cast<bool>(ci.flags & vk::ImageCreateFlagBits::eMutableFormat);
    if (!journal.completed_after_gpu_fence(true,true,true,true,
        mutable_create,true)) {
        journal.invalidate(); return UploadResult::BlockedInvalidPlan;
    }
    return UploadResult::Uploaded;
}
}
