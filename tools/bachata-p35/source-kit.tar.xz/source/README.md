# Bachata F43DEV V2 — P35 (fonte experimental)

A P35 acrescenta ao `Rasterizer::BindTextures()` do **core público ARM64/GLIBC** uma instrumentação para o conflito de imagens amostradas e imagens de armazenamento que pode afetar Minecraft. A fonte exata permanece fixada no commit `be6bc2e9c60799e071dd2fafa6216e8d80ec619c` de `zenithblue-oss/shadps4-arm64`. O alvo privado F43DEV instalado na P23 não foi modificado.

`p35_image_alias_probe.hpp` classifica memória sobreposta em intervalos semiabertos, rejeita tamanhos/endereços inválidos e não fornece autorização para reescrever descritores. A fonte observa `Shader::ImageResource::is_atomic`, o modo mip dinâmico e a classificação read/write derivada de `ImageDesc`. Os logs usam somente tipo, índices internos e flags booleanos, sem endereços ou dados do jogo; são opt-in via `BACHATA_STAGING_VERBOSE` e limitados a 16 eventos iniciais mais 1 a cada 256.

**Não corrige o Minecraft.** Um snapshot copiaria um estado de entrada, mas não preservaria dependências atômicas e de escrita entre invocações. A solução segura ainda exige uma prova de semântica no shader recompiler e integração Vulkan específica. Também não modifica o Outlast, apenas preserva a implementação P34 do caminho BCn 1D-tiled.

## Execução

`python3 -m unittest discover -s . -p 'test_port_p3*.py' -v`

`g++ -std=c++20 -O2 -Wall -Wextra -Werror test_p35.cpp -o p35-test && ./p35-test`

`python3 port_renderer_p35.py --source-root /caminho/clone/atual --out p35.diff --write` requer `HEAD` exato e arquivos com hashes fixados. `--synthetic-fixture` só serve para testes. A compilação GLIBC em runner e validação no Mali-G720 continuam gates independentes.
