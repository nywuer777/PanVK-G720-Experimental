void Image::Transit(vk::ImageLayout dst_layout, vk::AccessFlags2 dst_mask,
                    std::optional<SubresourceRange> range, vk::CommandBuffer cmdbuf /*= {}*/) {
    constexpr vk::AccessFlags2 writes = vk::AccessFlagBits2::eShaderWrite |
        vk::AccessFlagBits2::eColorAttachmentWrite |
        vk::AccessFlagBits2::eDepthStencilAttachmentWrite |
        vk::AccessFlagBits2::eTransferWrite;
    if (backing && (dst_mask & writes)) backing->p26_upload_journal.invalidate();}
void Image::Upload(std::span<const vk::BufferImageCopy> upload_copies, vk::Buffer buffer,
                   u64 offset, u64 decoded_source_bytes) {
    // Every general upload invalidates prior decoded-BCn provenance.
    if (backing) backing->p26_upload_journal.invalidate();
    const u64 upload_source_bytes = decoded_source_bytes ? decoded_source_bytes : info.guest_size;
    SetBackingSamples(info.num_samples, false);
        .size = upload_source_bytes,
        .size = upload_source_bytes,
}
void Image::Download(xxx) {}
    // P33: only directly addressable LINEAR BC1/BC3 guest images may use CPU
    // decoding. Never reinterpret GPU-tiled blocks or silently mutate guest format.
    const auto p33_select = [](vk::Format f) -> BachataP33::Format {
        switch (f) {
        case vk::Format::eBc1RgbUnormBlock:
        case vk::Format::eBc1RgbSrgbBlock: return BachataP33::Format::Bc1Rgb;
        case vk::Format::eBc1RgbaUnormBlock:
        case vk::Format::eBc1RgbaSrgbBlock: return BachataP33::Format::Bc1Rgba;
        case vk::Format::eBc3UnormBlock:
        case vk::Format::eBc3SrgbBlock: return BachataP33::Format::Bc3;
        default: return BachataP33::Format::Unsupported;
        }
    };
    p33_format = p33_select(info.pixel_format);
    p33_srgb = info.pixel_format == vk::Format::eBc1RgbSrgbBlock ||
        info.pixel_format == vk::Format::eBc1RgbaSrgbBlock ||
        info.pixel_format == vk::Format::eBc3SrgbBlock;
    const vk::Format p33_rgba = p33_srgb ? vk::Format::eR8G8B8A8Srgb :
        vk::Format::eR8G8B8A8Unorm;
    const auto gate = BachataP33::Eligible(BachataP33::Input{
        .format=p33_format, .srgb=p33_srgb,
        .tiled=bool(info.props.is_tiled) ||
            info.array_mode != AmdGpu::ArrayMode::ArrayLinearAligned,
        .volume=bool(info.props.is_volume) || info.type != AmdGpu::ImageType::Color2D,
        .image_format_supported=instance->IsFormatSupported(info.pixel_format,format_features),
        .rgba_host_supported=instance->IsFormatSupported(p33_rgba,format_features),
        .width=info.size.width, .height=info.size.height,
        .mips=info.resources.levels, .layers=info.resources.layers,
        .samples=info.num_samples, .guest_bits=info.num_bits,
    });
    p33_linear_bcn_fallback = gate == BachataP33::Gate::Eligible;
    if (p33_linear_bcn_fallback) {
        // VK_IMAGE_CREATE_BLOCK_TEXEL_VIEW_COMPATIBLE_BIT may not be set on
        // an uncompressed host RGBA image. Retain mutable-format semantics.
        flags &= ~vk::ImageCreateFlagBits::eBlockTexelViewCompatible;
        LOG_WARNING(Render_Vulkan, "P33_BCN_LINEAR_HOST_RGBA_SELECTED levels={} srgb={}",
                    info.resources.levels, p33_srgb ? 1 : 0);
    }
    constexpr auto tiling = vk::ImageTiling::eOptimal;
    const auto supported_format = p33_linear_bcn_fallback ? p33_rgba :
        instance->GetSupportedFormat(info.pixel_format, format_features);
