// SPDX-License-Identifier: GPL-2.0-or-later
// P27: checked BC1/BC3 mip/layer decoding and 4-byte-aligned Vulkan transfer plan.
#pragma once
#include "p26_bcn_decoder.hpp"
#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>
#include <algorithm>
#include <limits>
namespace BachataP27 {
using BachataP26::BcnFormat;
using BachataP26::DecodeStatus;
struct CompressedSubresource {
    uint32_t mip=0, layer=0, width=0, height=0;
    size_t row_stride=0;
    std::span<const uint8_t> blocks{};
};
struct CopyRegion { size_t offset=0, bytes=0; uint32_t mip=0, layer=0, width=0, height=0; };
enum class PlanStatus : uint8_t { Ok, InvalidShape, DuplicateSubresource, MissingSubresource,
                                  MalformedBlocks, BudgetExceeded };
struct PlanResult {
    PlanStatus status=PlanStatus::InvalidShape;
    DecodeStatus decode_status=DecodeStatus::Ok;
    std::vector<uint8_t> staging{};
    std::vector<CopyRegion> regions{};
    bool srgb=false;
    uint32_t mip_levels=0, array_layers=0;
};
// A fail-closed API. Every layer*mip must be supplied exactly once; input spans
// are read only while this function executes. No Vulkan resource is created.
inline PlanResult BuildPlan(BcnFormat format, bool srgb, uint32_t width, uint32_t height,
                            uint32_t mips, uint32_t layers,
                            std::span<const CompressedSubresource> subs) {
    PlanResult r{};
    if (!BachataP26::ValidFormat(format) || !width || !height || width>16384 ||
        height>16384 || !mips || mips>16 || !layers || layers>64 ||
        subs.size() != static_cast<size_t>(mips)*layers)
        return r;
    r.srgb=srgb; r.mip_levels=mips; r.array_layers=layers;
    std::vector<const CompressedSubresource*> ordered(static_cast<size_t>(mips)*layers);
    for (const auto& s:subs) {
        if (s.mip>=mips || s.layer>=layers) return r;
        const size_t i=static_cast<size_t>(s.layer)*mips+s.mip;
        if (ordered[i]) {r.status=PlanStatus::DuplicateSubresource;return r;}
        const uint32_t w=std::max(1u,width>>s.mip), h=std::max(1u,height>>s.mip);
        if (s.width!=w || s.height!=h) return r;
        ordered[i]=&s;
    }
    for (const auto* s:ordered) if (!s) {r.status=PlanStatus::MissingSubresource;return r;}
    constexpr size_t cap=BachataP26::MaxDecodedBytesPerChain;
    for (const auto* s:ordered) {
        size_t pixels=0, bytes=0;
        if (!BachataP26::CheckedMul(s->width,s->height,pixels) ||
            !BachataP26::CheckedMul(pixels,4,bytes) || bytes>cap || r.staging.size()>cap-bytes) {
            r.status=PlanStatus::BudgetExceeded;return {r.status};
        }
        // 4-byte offset aligned; all rgba8 subresources are multiples of four bytes.
        const size_t off=r.staging.size();
        r.staging.resize(off+bytes);
        const auto status=BachataP26::DecodeLevel(format,s->blocks,s->width,s->height,
            s->row_stride,std::span<uint8_t>(r.staging.data()+off,bytes));
        if(status!=DecodeStatus::Ok) {return {PlanStatus::MalformedBlocks,status};}
        r.regions.push_back({off,bytes,s->mip,s->layer,s->width,s->height});
    }
    r.status=PlanStatus::Ok;
    return r;
}
// Preconditions for an already allocated 2D/2D-array Vulkan destination. A
// decoded BCn block layout must NEVER be copied into a BCn-format VkImage.
struct DestinationProof {
    bool destination_rgba8=false;
    bool exact_srgb_match=false;
    bool transfer_dst_usage=false;
    bool sampled_image_feature=false;
    bool dimension_and_subresource_match=false;
    bool color_aspect=true;
    bool external_staging_buffer_sufficient=false;
    bool external_staging_buffer_mapped=false;
};
constexpr bool MaySubmit(const PlanResult& plan,const DestinationProof& d) {
    return plan.status==PlanStatus::Ok && !plan.regions.empty() &&
        d.destination_rgba8 && d.exact_srgb_match && d.transfer_dst_usage &&
        d.sampled_image_feature && d.dimension_and_subresource_match &&
        d.color_aspect && d.external_staging_buffer_sufficient &&
        d.external_staging_buffer_mapped;
}
}
