// SPDX-License-Identifier: GPL-2.0-or-later
// P26: portable BC1/BC3 texel decoder. No Vulkan views, image uploads or GPU-side effects.
#pragma once
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>
#include <vector>

namespace BachataP26 {
enum class BcnFormat : uint8_t { BC1_RGB, BC1_RGBA, BC3 };
enum class DecodeStatus : uint8_t { Ok, EmptyExtent, ExtentTooLarge, BadStride, TruncatedInput, SmallOutput, UnsupportedMipChain, UnsupportedFormat };
struct DecodedMip { uint32_t width, height; std::vector<uint8_t> rgba; };
struct MipResult { DecodeStatus status; std::vector<DecodedMip> mips; };
constexpr size_t MaxDecodedBytesPerMip = 256ull*1024*1024;
constexpr size_t MaxDecodedBytesPerChain = 256ull*1024*1024;

constexpr bool ValidFormat(BcnFormat f) { return f == BcnFormat::BC1_RGB || f == BcnFormat::BC1_RGBA || f == BcnFormat::BC3; }
constexpr size_t BlockSize(BcnFormat format) { return format == BcnFormat::BC3 ? 16u : 8u; }
constexpr bool CheckedMul(size_t a, size_t b, size_t& out) {
    if (b && a > std::numeric_limits<size_t>::max() / b) return false;
    out = a * b;
    return true;
}
constexpr uint8_t Expand5(unsigned v) { return static_cast<uint8_t>((v << 3) | (v >> 2)); }
constexpr uint8_t Expand6(unsigned v) { return static_cast<uint8_t>((v << 2) | (v >> 4)); }
inline std::array<uint8_t, 4> Unpack565(uint16_t x) {
    return {Expand5((x >> 11) & 31), Expand6((x >> 5) & 63), Expand5(x & 31), 255};
}
inline uint16_t Read16(const uint8_t* p) { return static_cast<uint16_t>(p[0] | (uint16_t(p[1]) << 8)); }
inline uint32_t Read32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}
inline std::array<std::array<uint8_t, 4>, 4> ColorPalette(const uint8_t* p, BcnFormat format) {
    const uint16_t c0 = Read16(p), c1 = Read16(p+2);
    std::array<std::array<uint8_t, 4>, 4> palette{Unpack565(c0), Unpack565(c1), {}, {}};
    const bool four_color = format == BcnFormat::BC3 || c0 > c1;
    for (int color = 0; color < 3; ++color) {
        const unsigned a = palette[0][color], b = palette[1][color];
        palette[2][color] = static_cast<uint8_t>(four_color ? (2*a+b)/3 : (a+b)/2);
        palette[3][color] = static_cast<uint8_t>(four_color ? (a+2*b)/3 : 0);
    }
    palette[2][3] = 255;
    palette[3][3] = !four_color && format == BcnFormat::BC1_RGBA ? 0 : 255;
    return palette;
}
inline std::array<uint8_t, 8> AlphaPalette(const uint8_t* p) {
    std::array<uint8_t, 8> alpha{p[0], p[1], 0, 0, 0, 0, 0, 0};
    const unsigned a = p[0], b = p[1];
    if (a > b) {
        for (unsigned i=1; i<=6; ++i) alpha[i+1] = static_cast<uint8_t>(((7-i)*a+i*b)/7);
    } else {
        for (unsigned i=1; i<=4; ++i) alpha[i+1] = static_cast<uint8_t>(((5-i)*a+i*b)/5);
        alpha[6] = 0; alpha[7] = 255;
    }
    return alpha;
}

// Input is a contiguous BC mip level, with optional row-stride padding between block rows.
// Color bytes preserve sRGB encoding; the caller must select the appropriate sRGB Vulkan view
// ONLY after the decoded output has been uploaded to a verified RGBA backing image.
inline DecodeStatus DecodeLevel(BcnFormat format, std::span<const uint8_t> compressed,
                                uint32_t width, uint32_t height, size_t input_block_row_stride,
                                std::span<uint8_t> output) {
    if (!ValidFormat(format)) return DecodeStatus::UnsupportedFormat;
    if (!width || !height) return DecodeStatus::EmptyExtent;
    // Conservative explicit cap and arithmetic guards to avoid bad allocations.
    if (width > 16384 || height > 16384) return DecodeStatus::ExtentTooLarge;
    const size_t bx = (static_cast<size_t>(width)+3)/4;
    const size_t by = (static_cast<size_t>(height)+3)/4;
    size_t min_row, output_needed, rows_bytes;
    if (!CheckedMul(bx, BlockSize(format), min_row) ||
        !CheckedMul(static_cast<size_t>(width), height, output_needed) ||
        !CheckedMul(output_needed, 4, output_needed) ||
        output_needed > MaxDecodedBytesPerMip) return DecodeStatus::ExtentTooLarge;
    if (input_block_row_stride < min_row) return DecodeStatus::BadStride;
    if (by > 1 && !CheckedMul(by - 1, input_block_row_stride, rows_bytes)) return DecodeStatus::BadStride;
    if (by <= 1) rows_bytes = 0;
    if (rows_bytes > compressed.size() || min_row > compressed.size()-rows_bytes)
        return DecodeStatus::TruncatedInput;
    if (output.size() < output_needed) return DecodeStatus::SmallOutput;
    for (size_t yb = 0; yb < by; ++yb) {
        for (size_t xb = 0; xb < bx; ++xb) {
            const uint8_t* block = compressed.data() + yb*input_block_row_stride + xb*BlockSize(format);
            const uint8_t* colors = block + (format == BcnFormat::BC3 ? 8 : 0);
            const auto pal = ColorPalette(colors, format);
            const uint32_t selectors = Read32(colors+4);
            std::array<uint8_t, 8> alphas{};
            uint64_t alpha_selectors = 0;
            if (format == BcnFormat::BC3) {
                alphas = AlphaPalette(block);
                for (unsigned i=0;i<6;++i) alpha_selectors |= uint64_t(block[2+i]) << (8*i);
            }
            for (unsigned yy=0; yy<4; ++yy) {
                const size_t y = yb*4 + yy;
                if (y >= height) continue;
                for (unsigned xx=0; xx<4; ++xx) {
                    const size_t x = xb*4 + xx;
                    if (x >= width) continue;
                    const unsigned texel=yy*4+xx;
                    const auto& rgba=pal[(selectors>>(texel*2))&3u];
                    const size_t off=(y*width+x)*4;
                    for (unsigned c=0;c<3;++c) output[off+c]=rgba[c];
                    output[off+3]=format==BcnFormat::BC3 ?
                        alphas[(alpha_selectors>>(texel*3))&7u] : rgba[3];
                }
            }
        }
    }
    return DecodeStatus::Ok;
}

// Read all requested levels from tightly packed BC blocks. Fully atomic success: no partial
// output is returned if any mip is missing or invalid. Level counts must be consistent.
inline MipResult DecodeMipChain(BcnFormat format, std::span<const uint8_t> compressed,
                                uint32_t width, uint32_t height, uint32_t levels) {
    if (!ValidFormat(format)) return {DecodeStatus::UnsupportedFormat, {}};
    if (!width || !height) return {DecodeStatus::EmptyExtent, {}};
    if (!levels || levels>15) return {DecodeStatus::UnsupportedMipChain, {}};
    if (width>16384 || height>16384) return {DecodeStatus::ExtentTooLarge, {}};
    MipResult result{DecodeStatus::Ok, {}};
    size_t in_pos=0, decoded_total=0;
    for (uint32_t mip=0; mip<levels; ++mip) {
        const size_t bx=(size_t(width)+3)/4, by=(size_t(height)+3)/4;
        size_t row, bytes, pixels;
        if (!CheckedMul(bx, BlockSize(format), row) || !CheckedMul(row,by,bytes) ||
            !CheckedMul(width,height,pixels) || !CheckedMul(pixels,4,pixels) || pixels > MaxDecodedBytesPerMip ||
            decoded_total > MaxDecodedBytesPerChain - pixels)
            return {DecodeStatus::ExtentTooLarge, {}};
        decoded_total += pixels;
        if (in_pos>compressed.size() || bytes>compressed.size()-in_pos)
            return {DecodeStatus::TruncatedInput, {}};
        DecodedMip out{width,height,std::vector<uint8_t>(pixels)};
        auto status=DecodeLevel(format,compressed.subspan(in_pos,bytes),width,height,row,out.rgba);
        if(status != DecodeStatus::Ok) return {status,{}};
        result.mips.push_back(std::move(out));
        in_pos += bytes;
        width=std::max(1u,width/2); height=std::max(1u,height/2);
    }
    return result;
}
} // namespace BachataP26
