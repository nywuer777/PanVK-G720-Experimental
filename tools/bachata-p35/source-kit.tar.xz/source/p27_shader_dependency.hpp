// SPDX-License-Identifier: GPL-2.0-or-later
// P27: conservative *single-basic-block* shader IR dependency summary.
// This has no right to mark an unknown multi-invocation alias safe.
#pragma once
#include "p26_alias_dispatch_gate.hpp"
#include <cstdint>
#include <span>
namespace BachataP27 {
enum class ImageOp : uint8_t { SampledRead, StorageRead, StorageWrite,
                               StorageAtomic, MemoryBarrier, Unknown };
struct Op { ImageOp operation; uint32_t resource_id; bool dynamic_image_index=false; };
struct ShaderEvidence {
    bool single_basic_block=false;
    bool no_loops_or_calls=false;
    bool single_invocation_or_proven_disjoint_writes=false;
    bool no_hidden_writes_or_indirect_alias=false;
};
struct DependencySummary {
    BachataP26::ReadDependency reads=BachataP26::ReadDependency::Unknown;
    BachataP26::AtomicOrdering atomics=BachataP26::AtomicOrdering::Unknown;
    bool verified=false;
};
inline DependencySummary Analyze(std::span<const Op> ops,const ShaderEvidence& e,
                                 uint32_t sampled_id,uint32_t storage_id) {
    using namespace BachataP26;
    // No invocation-level proof -> don't claim snapshot safe, even if all
    // sampled operations precede storage stores in lexical order.
    if (!e.single_basic_block || !e.no_loops_or_calls ||
        !e.single_invocation_or_proven_disjoint_writes ||
        !e.no_hidden_writes_or_indirect_alias || ops.empty()) return {};
    bool wrote=false,read=false;
    for (const auto& op:ops) {
        if (op.dynamic_image_index || op.operation==ImageOp::Unknown ||
            op.operation==ImageOp::MemoryBarrier) return {};
        if (op.resource_id==storage_id && op.operation==ImageOp::StorageAtomic)
            return {ReadDependency::Unknown,AtomicOrdering::CrossInvocationOrCrossDispatch,false};
        if (op.resource_id==storage_id && op.operation==ImageOp::StorageWrite) wrote=true;
        if (op.resource_id==sampled_id && op.operation==ImageOp::SampledRead) {
            if(wrote) return {ReadDependency::ReadsIntermediateWrites,AtomicOrdering::None,true};
            read=true;
        }
    }
    if (!read || !wrote) return {};
    return {ReadDependency::EntryStateOnly,AtomicOrdering::None,true};
}
}
