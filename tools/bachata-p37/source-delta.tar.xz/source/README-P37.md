# Bachata F43DEV V2 — P37 / basic-block shader image ordering provenance

Source-only target: `zenithblue-oss/shadps4-arm64@be6bc2e9c60799e071dd2fafa6216e8d80ec619c`. This is not the private F43DEV runtime. No APK or custom PanVK build is modified.

## Changes

- After IR resource sharp tracking and before `PatchImageArgs`, each basic block is scanned in source instruction order. Handles in ImageSampleRaw pack the sampler in their upper 16 bits, which are correctly masked before indexing the images list.
- `ImageQuery*` are ignored (metadata-only). `ImageRead` and `ImageSampleRaw` are plain reads, `ImageWrite` is write; all recognized image atomics are read-modify-write events, not separate plain reads.
- Same-block hazards tracked: WAR (read then write), RAW (write then read), WAW, mixed atomic/plain, multiple atomics. Multiple distinct blocks accessing a binding set `CrossBlockUnknown` without inventing control flow or GPU happens-before relations.
- Any unresolved/improper binding or overflow is marked incomplete. The classification is stored in `Shader::ImageResource` and logged only with the opt-in `BACHATA_STAGING_VERBOSE` diagnostics in `Rasterizer::BindTextures`, with bounded rate and **no guest addresses, shader hashes or content**.
- The diagnostic does **not** insert barriers, rewrite descriptors, NOP assertions, construct snapshots, or alter shader behavior.

## Validation

Run `python3 -m unittest discover -s . -p 'test_port_p3*.py' -q` in source directory. Compile `test_p37.cpp` with a C++20 compiler, optionally ASan/UBSan. The GitHub workflow additionally checks the upstream revision, applies the combined patches and attempts the full AArch64/GLIBC cross-build.

## Release gate

- Minecraft robust-image alias remains unsafe to rewrite without per-invocation/per-workgroup synchronization semantics. The P37 block-local evidence is **not** this proof.
- Outlast BCn is not validated on Mali-G720 with the installed F43DEV core.
- P23 signed APK remains untouched. No device APK is produced here. Keep its original 215157194 bytes SHA-256 `2806f93e9f4346dda5c796462c3d916fb021e2dc942fa2e7366dc78c265c62b6`.
