#include "p37_ir_sequence.hpp"
#include <cassert>
#include <cstdio>
using namespace BachataP37;
int main(){
    unsigned n=0;
    auto ck=[&](bool b){ assert(b);++n; };
    State a{};
    ck(Update(a,Access::Query));ck(a.instruction_count==0);ck(a.mask==None);
    ck(Update(a,Access::PlainRead));ck(Update(a,Access::Write));ck((a.mask&WriteAfterRead)!=0);
    ck((a.mask&ReadAfterWrite)==0);ck(Update(a,Access::PlainRead));ck((a.mask&ReadAfterWrite)!=0);
    ck(Update(a,Access::Write));ck((a.mask&WriteAfterWrite)!=0);
    State atom{};ck(Update(atom,Access::Atomic));ck(atom.mask==None);
    ck(Update(atom,Access::Atomic));ck((atom.mask&AtomicChain)!=0);ck((atom.mask&MixedAtomicPlain)==0);
    ck(Update(atom,Access::PlainRead));ck((atom.mask&MixedAtomicPlain)!=0);
    State atom2{};ck(Update(atom2,Access::PlainRead));ck(Update(atom2,Access::Atomic));ck((atom2.mask&MixedAtomicPlain)!=0);
    State atom3{};ck(Update(atom3,Access::Write));ck(Update(atom3,Access::Atomic));ck((atom3.mask&MixedAtomicPlain)!=0);
    Evidence e{};std::array<State,MaxImages> local{};
    ck(Record(e,0,8,Access::PlainRead,local));ck(Record(e,0,8,Access::Write,local));
    ck((AuditMask(e,8)&WriteAfterRead)!=0);ck((AuditMask(e,8)&CrossBlockUnknown)==0);
    local={};ck(Record(e,1,8,Access::PlainRead,local));ck((AuditMask(e,8)&CrossBlockUnknown)!=0);
    ck((AuditMask(e,8)&ReadAfterWrite)==0); // cannot derive order ACROSS blocks
    ck(Record(e,1,7,Access::Atomic,local));ck(AuditMask(e,7)==None);
    ck(!Record(e,1,64,Access::PlainRead,local));ck(e.invalid);ck((e.global_mask&InvalidBinding)!=0);
    Evidence e2{};local={};ck(Record(e2,0,0,Access::Atomic,local));ck(Record(e2,0,0,Access::PlainRead,local));
    ck((AuditMask(e2,0)&MixedAtomicPlain)!=0);
    ck(!AuthorizesImageRewrite(e2));ck(!AuthorizesBarrierInsertion(e2));
    local={};e2={};ck(Record(e2,0,63,Access::PlainRead,local));ck(AuditMask(e2,63)==None);
    State saturation{};saturation.instruction_count=UINT32_MAX;
    ck(!Update(saturation,Access::Write));ck((saturation.mask&CountSaturated)!=0);
    for(std::uint32_t i=0;i<256;++i){
      State s{};Update(s,Access::PlainRead);Update(s,Access::Write);
      ck((s.mask&WriteAfterRead)!=0); ck((s.mask&ReadAfterWrite)==0);
      Update(s,Access::Atomic);ck((s.mask&MixedAtomicPlain)!=0);
    }
    std::printf("P37_IR_LOCAL_SEQUENCE_PASS checks=%u\n",n);
}
