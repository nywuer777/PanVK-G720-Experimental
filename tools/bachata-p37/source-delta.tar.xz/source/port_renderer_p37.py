#!/usr/bin/env python3
"""P37 basic-block-local shader image ordering provenance; public core pinned.

No cross-block ordering inference, no shader/descriptor/synchronization rewrites.
"""
import argparse,difflib,hashlib,json,shutil,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p36 as p36
import port_renderer_p25 as p25

TRACK=p36.TRACK
RESOURCE=p36.RESOURCE
RASTER=p36.RASTER
ROOT_FILES=p36.ROOT_FILES
HEADER='src/shader_recompiler/ir/p37_ir_sequence.hpp'

def once(text,old,new,key):
    n=text.count(old)
    if n!=1:raise ValueError(f'P37_{key}_ANCHOR_COUNT_{n}')
    return text.replace(old,new,1)

ORDER_PASS='''    // P37_IR_BASIC_BLOCK_SEQUENCE: after all handles have become descriptor indexes,
    // BEFORE PatchImageArgs rewrites ImageSampleRaw and ImageRead instructions.
    // Classify order only inside a single block. No CFG/inter-invocation ordering proof.
    BachataP37::Evidence p37_evidence{};
    std::uint32_t p37_block_ordinal=0;
    for (IR::Block* const block : program.blocks) {
        std::array<BachataP37::State,BachataP37::MaxImages> p37_local{};
        for (IR::Inst& inst : block->Instructions()) {
            if (!IsImageInstruction(inst)) continue;
            BachataP37::Access access=BachataP37::Access::Query;
            switch(inst.GetOpcode()) {
            case IR::Opcode::ImageRead:
            case IR::Opcode::ImageSampleRaw:
                access=BachataP37::Access::PlainRead;
                break;
            case IR::Opcode::ImageWrite:
                access=BachataP37::Access::Write;
                break;
            default:
                if(IsImageAtomicInstruction(inst)) access=BachataP37::Access::Atomic;
                break;
            }
            if (access==BachataP37::Access::Query) continue;
            // FMask rewrites and unsupported instruction forms fail closed; do
            // not assume that non-immediate handles have a known binding.
            if (!inst.Arg(0).IsImmediate()) {
                p37_evidence.invalid=true;
                p37_evidence.global_mask|=BachataP37::InvalidBinding;
                continue;
            }
            const std::uint32_t raw=inst.Arg(0).U32();
            // ResourceTrackingPass packs sampler id into top 16 bits only
            // for ImageSampleRaw; all other image accesses have plain indexes.
            const std::uint32_t binding=inst.GetOpcode()==IR::Opcode::ImageSampleRaw
                ? (raw & 0xffffu) : raw;
            if(binding>=info.images.size()) {
                p37_evidence.invalid=true;
                p37_evidence.global_mask|=BachataP37::InvalidBinding;
                continue;
            }
            BachataP37::Record(p37_evidence,p37_block_ordinal,binding,access,p37_local);
        }
        if (p37_block_ordinal==UINT32_MAX-1) {
            p37_evidence.invalid=true;
            p37_evidence.global_mask|=BachataP37::InvalidBinding;
            break;
        }
        ++p37_block_ordinal;
    }
    for (std::size_t i=0;i<info.images.size();++i) {
        info.images[i].p37_order_mask=BachataP37::AuditMask(p37_evidence,i);
        info.images[i].p37_order_untrusted=p37_evidence.invalid;
    }

'''
RUNTIME_LOG='''    // P37_BASIC_BLOCK_ORDER_DIAG: diagnostic only, never infer Vulkan
    // synchronization correctness or runtime cross-block execution ordering.
    if (VideoCore::StagingVerbose()) {
        std::uint32_t p37_order_mask=0;
        bool p37_untrusted=false;
        for (const auto& image_res : stage.images) {
            p37_order_mask|=image_res.p37_order_mask;
            p37_untrusted|=image_res.p37_order_untrusted;
        }
        if (p37_order_mask!=0 || p37_untrusted) {
            static std::atomic<u32> p37_observations{0};
            const u32 seq=p37_observations.fetch_add(1,std::memory_order_relaxed);
            if (seq<16 || seq%256==0) {
                LOG_WARNING(Render_Vulkan,
                    "P37_IR_ORDER mask={} incomplete={} crossBlock={} "
                    "localRAW={} localWAR={} localWAW={} atomicMix={} "
                    "hasHappensBeforeProof=0 barrierInsert=0 snapshotAllowed=0",
                    p37_order_mask,p37_untrusted ? 1 : 0,
                    (p37_order_mask&BachataP37::CrossBlockUnknown) ? 1 : 0,
                    (p37_order_mask&BachataP37::ReadAfterWrite) ? 1 : 0,
                    (p37_order_mask&BachataP37::WriteAfterRead) ? 1 : 0,
                    (p37_order_mask&BachataP37::WriteAfterWrite) ? 1 : 0,
                    (p37_order_mask&BachataP37::MixedAtomicPlain) ? 1 : 0);
            }
        }
    }
'''

def transform(inputs):
    out=p36.transform(inputs)
    res=out[RESOURCE]
    res=once(res,'    bool is_plain_read{};\n    bool is_sampled{};',
             '    bool is_plain_read{};\n    bool is_sampled{};\n'
             '    // P37: basic-block-local order only. No cross-block happens-before proof.\n'
             '    u32 p37_order_mask{};\n    bool p37_order_untrusted{};', 'resource_order_fields')
    out[RESOURCE]=res
    track=out[TRACK]
    track=once(track,'#include "shader_recompiler/ir/program.h"',
               '#include "shader_recompiler/ir/program.h"\n'
               '#include "shader_recompiler/ir/p37_ir_sequence.hpp"', 'ir_include')
    track=once(track,'    // Pass 2: Patch instruction args',ORDER_PASS+'    // Pass 2: Patch instruction args','ir_after_binding_pass')
    out[TRACK]=track
    rast=out[RASTER]
    rast=once(rast,'#include "video_core/renderer_vulkan/p36_resource_intent.hpp"',
               '#include "video_core/renderer_vulkan/p36_resource_intent.hpp"\n'
               '#include "shader_recompiler/ir/p37_ir_sequence.hpp"', 'raster_include')
    rast=once(rast,'    // Second pass to re-bind images that were updated after binding',
              RUNTIME_LOG+'    // Second pass to re-bind images that were updated after binding',
              'runtime_diagnostic')
    out[RASTER]=rast
    return out

def main():
    args=argparse.ArgumentParser()
    args.add_argument('--source-root',type=Path,required=True)
    args.add_argument('--out',type=Path,default=Path('p37-port.diff'))
    args.add_argument('--write',action='store_true')
    args.add_argument('--synthetic-fixture',action='store_true')
    a=args.parse_args()
    if not a.synthetic_fixture:
        def git(*xs):return subprocess.run(['git','-C',str(a.source_root),*xs],check=True,text=True,capture_output=True).stdout.strip()
        if git('rev-parse','HEAD')!=p25.EXPECTED_UPSTREAM:raise ValueError('P37_WRONG_UPSTREAM_COMMIT')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P37_DIRTY_PUBLIC_SOURCE')
        for rel,sha in {**p36.p35.p34.p33.p28.IMAGE_SHA_PIN,**p36.PIN}.items():
            if git('hash-object',rel)!=sha:raise ValueError('P37_SOURCE_DRIFT:'+rel)
    src={x:(a.source_root/x).read_text() for x in ROOT_FILES}
    dst=transform(src)
    h={f'src/video_core/renderer_vulkan/{name}':Path(__file__).with_name(name)
       for name in (*p36.p35.p34.p33.p28.p27.HEADERS,*p36.p35.p34.p33.p28.P28_FILES,
                    'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                    'p35_image_alias_probe.hpp','p36_resource_intent.hpp')}
    h[HEADER]=Path(__file__).with_name('p37_ir_sequence.hpp')
    for rel,path in h.items():
        if not path.is_file() or (a.source_root/rel).exists():raise ValueError('P37_HEADER_CONFLICT:'+rel)
    diff=''.join(''.join(difflib.unified_diff(src[x].splitlines(True),dst[x].splitlines(True),fromfile='a/'+x,tofile='b/'+x)) for x in ROOT_FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(diff)
    if a.write:
        for rel,value in dst.items():
            f=a.source_root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(value)
        for rel,path in h.items():
            f=a.source_root/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,f)
    print(json.dumps({'phase':'P37_BASIC_BLOCK_SHADER_ORDER_SOURCE_ONLY',
                      'public_revision':p25.EXPECTED_UPSTREAM,
                      'basic_block_order_measured':True,
                      'cross_block_order_known':False,
                      'vulkan_barriers_inserted':False,
                      'texture_snapshots_permitted':False,
                      'minecraft_fixed':False,'outlast_fixed':False,'apk_built':False,
                      'diff_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
