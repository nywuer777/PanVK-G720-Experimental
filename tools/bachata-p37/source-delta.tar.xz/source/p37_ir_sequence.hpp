// SPDX-License-Identifier: GPL-2.0-or-later
// P37: Basic-block-local image access ordering evidence, not a synchronization fix.
#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>

namespace BachataP37 {
constexpr std::size_t MaxImages = 64;
enum class Access : std::uint8_t { Query, PlainRead, Write, Atomic };
enum Mask : std::uint32_t {
    None=0, WriteAfterRead=1u<<0, ReadAfterWrite=1u<<1,
    WriteAfterWrite=1u<<2, MixedAtomicPlain=1u<<3,
    AtomicChain=1u<<4, CrossBlockUnknown=1u<<5,
    InvalidBinding=1u<<6, CountSaturated=1u<<7
};
struct State {
    bool seen_plain_read{};
    bool seen_write{};
    bool seen_atomic{};
    std::uint32_t mask{};
    std::uint32_t instruction_count{};
};
struct Evidence {
    std::array<State, MaxImages> aggregates{};
    std::array<std::uint32_t, MaxImages> last_block{};
    std::uint32_t global_mask{};
    bool invalid{};
};
constexpr bool Update(State& s, Access op) noexcept {
    if (op == Access::Query) return true; // metadata query is not a texel read
    if (s.instruction_count == UINT32_MAX) { s.mask |= CountSaturated; return false; }
    ++s.instruction_count;
    if (op == Access::PlainRead) {
        if (s.seen_write) s.mask |= ReadAfterWrite;
        if (s.seen_atomic) s.mask |= MixedAtomicPlain;
        s.seen_plain_read = true;
    } else if (op == Access::Write) {
        if (s.seen_plain_read) s.mask |= WriteAfterRead;
        if (s.seen_write) s.mask |= WriteAfterWrite;
        if (s.seen_atomic) s.mask |= MixedAtomicPlain;
        s.seen_write = true;
    } else { // Atomic is indivisible read/modify/write, NOT an independent plain read.
        if (s.seen_plain_read || s.seen_write) s.mask |= MixedAtomicPlain;
        if (s.seen_atomic) s.mask |= AtomicChain;
        s.seen_atomic = true;
    }
    return true;
}
// Combine only observed basic blocks. This is NOT a full CFG or inter-invocation happens-before proof.
constexpr bool Record(Evidence& e, std::uint32_t block_ordinal, std::uint32_t binding,
                      Access op, std::array<State,MaxImages>& local) noexcept {
    if (op == Access::Query) return true;
    if (binding >= MaxImages || block_ordinal == UINT32_MAX) {
        e.invalid = true; e.global_mask |= InvalidBinding; return false;
    }
    auto& combined = e.aggregates[binding];
    if (e.last_block[binding] && e.last_block[binding] != block_ordinal+1) {
        combined.mask |= CrossBlockUnknown;
    }
    e.last_block[binding] = block_ordinal+1;
    auto& current = local[binding];
    const bool ok=Update(current,op);
    if (!ok) { e.invalid=true; e.global_mask |= CountSaturated; }
    combined.mask |= current.mask;
    combined.seen_plain_read |= (op==Access::PlainRead);
    combined.seen_write |= (op==Access::Write);
    combined.seen_atomic |= (op==Access::Atomic);
    if(combined.instruction_count==UINT32_MAX) {
        combined.mask |= CountSaturated;e.invalid=true;e.global_mask|=CountSaturated;
    } else ++combined.instruction_count;
    e.global_mask |= combined.mask;
    return ok;
}
constexpr std::uint32_t AuditMask(const Evidence& e, std::size_t binding) noexcept {
    if (binding>=MaxImages) return InvalidBinding;
    return e.aggregates[binding].mask;
}
constexpr bool AuthorizesImageRewrite(const Evidence&) noexcept {return false;}
constexpr bool AuthorizesBarrierInsertion(const Evidence&) noexcept {return false;}
} // namespace BachataP37
