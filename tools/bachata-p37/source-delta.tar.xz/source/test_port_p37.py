import json,subprocess,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p37 as p37
from test_port_p36 import P36PortTest

class P37PortTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        P36PortTest.setUpClass()
        f=P36PortTest.fixture.copy()
        t=f[p37.TRACK]
        f[p37.TRACK]='#include "shader_recompiler/ir/program.h"\n'+t+'\nvoid ResourceTrackingPass() {\n    // Pass 2: Patch instruction args\n}\n'
        cls.fixture=f
    def test_real_opcode_order_and_query_exclusions(self):
        o=p37.transform(self.fixture);t=o[p37.TRACK]
        for term in ['P37_IR_BASIC_BLOCK_SEQUENCE','IsImageInstruction(inst)',
            'IsImageAtomicInstruction(inst)','IR::Opcode::ImageRead','IR::Opcode::ImageSampleRaw',
            'IR::Opcode::ImageWrite','if (access==BachataP37::Access::Query) continue',
            'if (!inst.Arg(0).IsImmediate())','(raw & 0xffffu)',
            'if(binding>=info.images.size())','BachataP37::Record(',
            'p37_order_untrusted=p37_evidence.invalid']:
            self.assertIn(term,t)
    def test_raster_observation_off_by_default(self):
        out=p37.transform(self.fixture)[p37.RASTER]
        for word in ['VideoCore::StagingVerbose()','P37_IR_ORDER','hasHappensBeforeProof=0',
            'barrierInsert=0','snapshotAllowed=0','image_res.p37_order_mask',
            'p37_observations.fetch_add(1']:
            self.assertIn(word,out)
    def test_existing_bc_path_unchanged(self):
        new=p37.transform(self.fixture)
        old=p37.p36.transform(self.fixture)
        for k in ('src/video_core/texture_cache/image.cpp','src/video_core/texture_cache/texture_cache.cpp',
                  'src/video_core/texture_cache/image_view.cpp','CMakeLists.txt'):
            self.assertEqual(new[k],old[k])
    def test_retains_ir_read_flags(self):
        t=p37.transform(self.fixture)[p37.TRACK]
        self.assertIn('image.is_plain_read |= desc.is_plain_read',t)
        self.assertIn('image.is_atomic |= desc.is_atomic',t)
    def test_idempotence_fail_closed(self):
        d=p37.transform(self.fixture)
        with self.assertRaises(ValueError):p37.transform(d)
    def test_missing_resource_anchor(self):
        d=self.fixture.copy();d[p37.RESOURCE]='bad'
        with self.assertRaises(ValueError):p37.transform(d)
    def test_missing_pass_anchor(self):
        d=self.fixture.copy();d[p37.TRACK]=d[p37.TRACK].replace('// Pass 2: Patch instruction args','none')
        with self.assertRaises(ValueError):p37.transform(d)
    def test_multiple_pass_anchors(self):
        d=self.fixture.copy();d[p37.TRACK]+='    // Pass 2: Patch instruction args\n'
        with self.assertRaises(ValueError):p37.transform(d)
    def test_offline_port_dry_run_and_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for k,v in self.fixture.items():
                f=root/k;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v)
            cmd=[sys.executable,str(Path(p37.__file__)),'--synthetic-fixture',
                '--source-root',str(root),'--out',str(root/'p37.diff')]
            output=json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
            self.assertFalse(output['minecraft_fixed']);self.assertFalse(output['cross_block_order_known'])
            self.assertFalse((root/p37.HEADER).exists())
            subprocess.run(cmd+['--write'],capture_output=True,text=True,check=True)
            self.assertTrue((root/p37.HEADER).exists())
            self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True,text=True).returncode,0)
    def test_no_release_assertions(self):
        script=Path(p37.__file__).read_text()
        for s in ["'vulkan_barriers_inserted':False","'texture_snapshots_permitted':False", "'apk_built':False"]:
            self.assertIn(s,script)

if __name__=='__main__': unittest.main()
