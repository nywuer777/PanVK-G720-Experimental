import json, subprocess, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p45 as p45
from test_port_p39 import P39Port

class P45PortTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        P39Port.setUpClass()
        cls.fixture=P39Port.fixture.copy()
        cls.upload=Path(p45.__file__).with_name('p27_vk_decoded_upload.cpp').read_text()
    def test_live_image_view_p44_admission(self):
        code=p45.transform(self.fixture,self.upload)[0][p45.VIEW]
        self.assertIn('P45_BCN_PER_LAYER_VIEW_PROOF',code)
        self.assertIn('BachataP44::Resolve(p45_request)',code)
        self.assertIn('p45_decision.permitted',code)
        self.assertIn('P25 decoded BCn sampled view blocked',code)
        self.assertIn('p45_proofs.data()',code)
    def test_live_backing_metadata(self):
        code=p45.transform(self.fixture,self.upload)[0][p45.HEADER]
        for token in ['BachataP44::CompletedUpload','p45_content_epoch{1}',
                      'p45_generation{}','p45_completed_bc_uploads{}']:
            self.assertIn(token,code)
    def test_invalidates_on_gpu_write_and_guest_upload(self):
        code=p45.transform(self.fixture,self.upload)[0][p45.IMAGE]
        self.assertEqual(code.count('p45_completed_bc_uploads.clear()'),2)
        self.assertEqual(code.count('p45_generation = 0;'),2)
        self.assertEqual(code.count('++backing->p45_content_epoch'),4) # including overflow branch
    def test_records_only_after_completed_fence(self):
        _,source=p45.transform(self.fixture,self.upload)
        self.assertLess(source.index('scheduler.Finish();'),source.index('P45_BCN_LAYER_UPLOAD_COMPLETE'))
        self.assertLess(source.index('journal.completed_after_gpu_fence('),source.index('P45_BCN_LAYER_UPLOAD_COMPLETE'))
        self.assertIn('.layer=sub.layer',source)
        self.assertIn('.content_epoch=p45_b.p45_content_epoch',source)
        self.assertIn('.gpu_fence_completed=true',source)
    def test_other_upstream_changes_preserved(self):
        old=p45.p39.transform(self.fixture)
        new,_=p45.transform(self.fixture,self.upload)
        for file in p45.ROOT_FILES:
            self.assertIn('P39_EXACT_IMAGE_ID_SAMPLED_STORAGE',new[p45.p39.RASTER])
            if file not in [p45.HEADER,p45.IMAGE,p45.VIEW]:
                self.assertEqual(old[file],new[file])
    def test_p45_never_disables_asserts(self):
        _,code=p45.transform(self.fixture,self.upload)
        self.assertIn('P45_BCN_LAYER_UPLOAD_COMPLETE',code)
        self.assertNotIn('#define NDEBUG',code)
    def test_default_gate_rejects_wrong_upstream(self):
        body=Path(p45.__file__).read_text()
        self.assertIn('P45_WRONG_SOURCE_REVISION',body)
        self.assertIn('P45_DIRTY_TRACKED_TREE',body)
        self.assertIn("'private_glibc_modified':False",body)
    def test_fails_closed_duplicate_view_anchor(self):
        f=self.fixture.copy();f[p45.VIEW]+=p45.p39.p38.p37.p36.p35.p34.p33.p28.p27.p26.p25.OLD_VIEW_HEAD
        with self.assertRaises(ValueError):p45.transform(f,self.upload)
    def test_fails_closed_upload_completion_anchor_missing(self):
        with self.assertRaises(ValueError):p45.transform(self.fixture,self.upload.replace('    return UploadResult::Uploaded;','    return UploadResult::BlockedInvalidPlan;'))
    def test_fails_closed_when_reapplying(self):
        a,b=p45.transform(self.fixture,self.upload)
        with self.assertRaises(ValueError):p45.transform(a,b)
    def test_source_only_write_fixture(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for key,v in self.fixture.items():
                f=root/key;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v)
            cmd=[sys.executable,str(Path(p45.__file__)),'--source-root',str(root),
                 '--out',str(root/'p45.diff'),'--synthetic-fixture']
            report=json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
            self.assertFalse(report['private_glibc_modified'])
            self.assertFalse((root/p45.CONTRACT).exists())
            subprocess.run(cmd+['--write'],capture_output=True,text=True,check=True)
            self.assertTrue((root/p45.CONTRACT).exists())
            uploaded=(root/p45.UPLOAD).read_text()
            self.assertIn('P45_BCN_LAYER_UPLOAD_COMPLETE',uploaded)
            self.assertTrue((root/'p45.diff').exists())
            self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True).returncode,0)

if __name__=='__main__':unittest.main()
