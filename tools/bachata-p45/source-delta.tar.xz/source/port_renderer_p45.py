#!/usr/bin/env python3
"""P45: per-layer BCn->RGBA Vulkan sampled-view proof, exact pinned PUBLIC core.

Layer-aware ledger comes from a real decoded upload and completed scheduler fence.
Never substitute public GLIBC for private F43DEV or suppress a validation assert.
"""
from pathlib import Path
import argparse, hashlib, difflib, json, shutil, subprocess, sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p39 as p39
import port_renderer_p25 as p25

HEADER='src/video_core/texture_cache/image.h'
IMAGE='src/video_core/texture_cache/image.cpp'
VIEW='src/video_core/texture_cache/image_view.cpp'
UPLOAD='src/video_core/renderer_vulkan/p27_vk_decoded_upload.cpp'
CONTRACT='src/video_core/renderer_vulkan/p44_bcn_imageview_contract.hpp'
ROOT_FILES=p39.ROOT_FILES

def once(text,old,new,tag):
    count=text.count(old)
    if count != 1: raise ValueError(f'P45_{tag}_ANCHOR_COUNT_{count}')
    return text.replace(old,new,1)

VIEW_PROOF = '''        // P45_BCN_PER_LAYER_VIEW_PROOF: checked against the REAL backing image.
        // This guard is additive to P25 and never permits an invalid guest
        // image, missing tile layout proof or unfinished transfer.
        const auto to_p45_format = [](vk::Format f) -> BachataP44::Format {
            switch (f) {
            case vk::Format::eBc1RgbUnormBlock: return BachataP44::Format::Bc1RgbUnorm;
            case vk::Format::eBc1RgbSrgbBlock: return BachataP44::Format::Bc1RgbSrgb;
            case vk::Format::eBc1RgbaUnormBlock: return BachataP44::Format::Bc1RgbaUnorm;
            case vk::Format::eBc1RgbaSrgbBlock: return BachataP44::Format::Bc1RgbaSrgb;
            case vk::Format::eBc3UnormBlock: return BachataP44::Format::Bc3Unorm;
            case vk::Format::eBc3SrgbBlock: return BachataP44::Format::Bc3Srgb;
            case vk::Format::eR8G8B8A8Unorm: return BachataP44::Format::Rgba8Unorm;
            case vk::Format::eR8G8B8A8Srgb: return BachataP44::Format::Rgba8Srgb;
            default: return BachataP44::Format::Unknown;
            }
        };
        const auto& p45_ci = image.backing->image.image_ci;
        const auto p45_guest = to_p45_format(format);
        const auto p45_backing = to_p45_format(p45_ci.format);
        const auto p45_desired_vk = BachataP44::IsSrgb(p45_guest)
            ? vk::Format::eR8G8B8A8Srgb : vk::Format::eR8G8B8A8Unorm;
        const auto& p45_proofs = image.backing->p45_completed_bc_uploads;
        const BachataP44::Request p45_request{
            .guest=p45_guest, .allocated_backing=p45_backing,
            .sampled=!info.is_storage, .storage=info.is_storage,
            .depth=bool(image.info.props.is_depth),
            .color_aspect=aspect==vk::ImageAspectFlagBits::eColor,
            .sampled_feature=instance.IsFormatSupported(p45_ci.format,
                vk::FormatFeatureFlagBits2::eSampledImage),
            .view_format_feature=instance.IsFormatSupported(p45_desired_vk,
                vk::FormatFeatureFlagBits2::eSampledImage),
            .mutable_format=bool(p45_ci.flags & vk::ImageCreateFlagBits::eMutableFormat),
            .compatible_mutation=p45_ci.format==p45_desired_vk ||
                IsVulkanFormatCompatible(p45_ci.format,p45_desired_vk),
            .guest_is_tiled=bool(image.info.props.is_tiled),
            .width=image.info.size.width, .height=image.info.size.height,
            .allocated_mips=p45_ci.mipLevels,
            .allocated_layers=p45_ci.arrayLayers,
            .samples=static_cast<u32>(image.info.num_samples),
            .base_mip=info.range.base.level, .mip_count=info.range.extent.levels,
            .base_layer=info.range.base.layer, .layer_count=info.range.extent.layers,
            .generation=image.backing->p45_generation,
            .current_content_epoch=image.backing->p45_content_epoch,
            .uploads=p45_proofs.data(), .upload_count=p45_proofs.size(),
        };
        const auto p45_decision = BachataP44::Resolve(p45_request);
        ASSERT_MSG(p45_decision.permitted &&
                   p45_decision.verdict==BachataP44::Verdict::VerifiedDecodedRgbaView,
                   "P45 sampled BCn RGBA view rejected: missing completed layer/mip proof code {}",
                   static_cast<unsigned>(p45_decision.verdict));
'''

PROOF_COMPLETE = '''    // P45_BCN_LAYER_UPLOAD_COMPLETE: after the actual GPU fence and P26
    // completion. Atomically publish per-(mip,layer) evidence for the current
    // content epoch and decoded image backing; never fabricate completion.
    auto& p45_b = *image.backing;
    p45_b.p45_completed_bc_uploads.clear();
    p45_b.p45_generation = generation;
    p45_b.p45_completed_bc_uploads.reserve(plan.regions.size());
    for (const auto& sub : plan.regions) {
        p45_b.p45_completed_bc_uploads.push_back(BachataP44::CompletedUpload{
            .mip=sub.mip, .layer=sub.layer, .width=sub.width, .height=sub.height,
            .generation=generation, .completion_generation=generation,
            .content_epoch=p45_b.p45_content_epoch,
            .decoded_format=plan.srgb ? BachataP44::Format::Rgba8Srgb
                                      : BachataP44::Format::Rgba8Unorm,
            .decoder_succeeded=true, .guest_layout_verified=true,
            .gpu_copy_submitted=true, .gpu_fence_completed=true,
            .color_aspect_verified=bool(image.aspect_mask==vk::ImageAspectFlagBits::eColor),
        });
    }
    LOG_TRACE(Render_Vulkan, "P45_BCN_LAYER_PROOF mips={} layers={} entries={} generation={}",
              plan.mip_levels,plan.array_layers,p45_b.p45_completed_bc_uploads.size(),generation);
'''

def transform(inputs,upload_source):
    out=p39.transform(inputs)
    h=out[HEADER]
    h=once(h,'#include "video_core/renderer_vulkan/p26_upload_attestation.hpp"',
        '#include "video_core/renderer_vulkan/p26_upload_attestation.hpp"\n'
        '#include "video_core/renderer_vulkan/p44_bcn_imageview_contract.hpp"','HEADER_INCLUDE')
    h=once(h,'BachataP26::UploadJournal p26_upload_journal{};',
        'BachataP26::UploadJournal p26_upload_journal{};\n'
        '        // P45 layer-aware completed upload ledger tied to this actual backing.\n'
        '        std::vector<BachataP44::CompletedUpload> p45_completed_bc_uploads{};\n'
        '        u64 p45_content_epoch{1};\n'
        '        u64 p45_generation{};', 'BACKING_FIELDS')
    out[HEADER]=h
    cpp=out[IMAGE]
    cpp=once(cpp,'if (backing && (dst_mask & writes)) backing->p26_upload_journal.invalidate();',
        'if (backing && (dst_mask & writes)) {\n'
        '        backing->p26_upload_journal.invalidate();\n'
        '        backing->p45_completed_bc_uploads.clear();\n'
        '        backing->p45_generation = 0;\n'
        '        if (++backing->p45_content_epoch == 0) ++backing->p45_content_epoch;\n'
        '    }', 'INVALIDATE_WRITE')
    cpp=once(cpp,'if (backing) backing->p26_upload_journal.invalidate();',
        'if (backing) {\n'
        '        backing->p26_upload_journal.invalidate();\n'
        '        backing->p45_completed_bc_uploads.clear();\n'
        '        backing->p45_generation = 0;\n'
        '        if (++backing->p45_content_epoch == 0) ++backing->p45_content_epoch;\n'
        '    }', 'INVALIDATE_UPLOAD')
    out[IMAGE]=cpp
    view=out[VIEW]
    view=once(view,
       '    if (BachataP24::IsBc(p25_guest_format) && BachataP24::IsRgba(p25_host_format)) {',
       '    if (BachataP24::IsBc(p25_guest_format) && BachataP24::IsRgba(p25_host_format)) {\n'
       +VIEW_PROOF,'INJECT_BCN_VIEW')
    out[VIEW]=view
    upload=once(upload_source,'    return UploadResult::Uploaded;',PROOF_COMPLETE+'    return UploadResult::Uploaded;','COMPLETION_ATTESTATION')
    return out, upload


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root',type=Path,required=True)
    ap.add_argument('--out',type=Path,default=Path('p45-source.diff'))
    ap.add_argument('--write',action='store_true')
    ap.add_argument('--synthetic-fixture',action='store_true')
    args=ap.parse_args()
    if not args.synthetic_fixture:
        def git(*part):
            return subprocess.run(['git','-C',str(args.source_root),*part],capture_output=True,text=True,check=True).stdout.strip()
        if git('rev-parse','HEAD') != p25.EXPECTED_UPSTREAM:raise ValueError('P45_WRONG_SOURCE_REVISION')
        if git('status','--porcelain','--untracked-files=no'):raise ValueError('P45_DIRTY_TRACKED_TREE')
    before={p:(args.source_root/p).read_text() for p in ROOT_FILES}
    upload_original=Path(__file__).with_name('p27_vk_decoded_upload.cpp').read_text()
    after,upload=transform(before,upload_original)
    additions={f'src/video_core/renderer_vulkan/{x}':Path(__file__).with_name(x)
         for x in (*p39.p38.p37.p36.p35.p34.p33.p28.p27.HEADERS,
                   *p39.p38.p37.p36.p35.p34.p33.p28.P28_FILES,
                   'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                   'p35_image_alias_probe.hpp','p36_resource_intent.hpp',
                   'p38_interdispatch_barrier.hpp','p39_same_image_layout.hpp')}
    additions[p39.p38.p37.HEADER]=Path(__file__).with_name('p37_ir_sequence.hpp')
    additions[CONTRACT]=Path(__file__).with_name('p44_bcn_imageview_contract.hpp')
    additions[UPLOAD]=None
    for p,src in additions.items():
        if (src is not None and not src.is_file()) or (args.source_root/p).exists():raise ValueError('P45_ADDITION_CONFLICT:'+p)
    delta=''.join(''.join(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in ROOT_FILES)
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(delta)
    if args.write:
        for p,v in after.items():
            f=args.source_root/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(v)
        for p,src in additions.items():
            f=args.source_root/p;f.parent.mkdir(parents=True,exist_ok=True)
            if p==UPLOAD:f.write_text(upload)
            else:shutil.copyfile(src,f)
    print(json.dumps({'schema':'P45_BCN_PER_LAYER_LIVE_SOURCE_VIEW_PROOF',
         'upstream':p25.EXPECTED_UPSTREAM,'write':args.write,
         'view_constructor_checked':True,'per_layer_gpu_fence_ledger':True,
         'upload_and_gpu_write_invalidation':True,
         'private_glibc_modified':False,'apk_built':False,'outlast_fixed':False,
         'diff_sha256':hashlib.sha256(delta.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':main()
