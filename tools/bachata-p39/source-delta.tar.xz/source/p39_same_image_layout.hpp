// SPDX-License-Identifier: GPL-2.0-or-later
// Bachata P39: opt-in descriptor layout consistency for EXACT SAME image id.
// This is NOT an intra-dispatch image race or sampled/storage alias fix.
#pragma once
#include <cstdlib>
#include <cstring>

namespace BachataP39 {
struct Evidence {
    bool same_image_id{};
    bool sampled{};
    bool storage{};
    bool depth{};
    bool attachment{};
    bool needs_rebind{};
};
struct Decision {
    bool use_general{};
    bool include_shader_write_access{};
    bool resolves_intrashader_hazard{};
    bool permits_distinct_image_alias{};
    bool permits_replacing_robust_guard{};
};
inline bool Enabled() noexcept {
    static const bool enabled = []() noexcept {
        const char* e = std::getenv("BACHATA_P39_SAME_IMAGE_LAYOUT");
        return e != nullptr && std::strcmp(e, "1") == 0;
    }();
    return enabled;
}
constexpr Decision Plan(bool opt_in, Evidence e) noexcept {
    const bool consistent = opt_in && e.same_image_id && e.sampled && e.storage &&
        !e.depth && !e.attachment && !e.needs_rebind;
    // GENERAL with shader read/write access makes all views of one VkImage
    // layout-compatible; it does NOT synchronize accesses inside a dispatch.
    return {consistent, consistent, false, false, false};
}
} // namespace BachataP39
