#!/usr/bin/env python3
"""P39 conservative same-ImageId sampled/storage Vulkan descriptor layout gate.

Public shadPS4 pinned commit only. Default OFF; cannot fix alias across
ImageIds, shader RMW hazards, or private F43DEV robust-image blocker.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import port_renderer_p38 as p38
import port_renderer_p25 as p25

RASTER = p38.RASTER
HEADER = 'src/video_core/renderer_vulkan/p39_same_image_layout.hpp'
ROOT_FILES = p38.ROOT_FILES

def once(s, old, new, tag):
    n=s.count(old)
    if n!=1: raise ValueError(f'P39_{tag}_ANCHOR_COUNT_{n}')
    return s.replace(old,new,1)

SCAN = '''    // P39_EXACT_IMAGE_ID_SAMPLED_STORAGE: opt-in, SAME ImageId only.
    // Both view classes must share GENERAL. No address-only alias conjectures,
    // no shader rewrite, no intra-dispatch synchronization and no assert removal.
    if (BachataP39::Enabled()) {
        for (const auto& p39_entry : image_bindings) {
            const auto p39_id = p39_entry.first;
            if (!p39_id) continue;
            bool p39_sampled = false;
            bool p39_storage = false;
            for (const auto& p39_other : image_bindings) {
                if (p39_other.first != p39_id) continue;
                if (p39_other.second.type == VideoCore::TextureCache::BindingType::Storage)
                    p39_storage = true;
                else p39_sampled = true;
            }
            if (!p39_sampled || !p39_storage) continue;
            auto& p39_image = texture_cache.GetImage(p39_id);
            const auto p39_decision = BachataP39::Plan(true, {
                .same_image_id = true,
                .sampled = p39_sampled,
                .storage = p39_storage,
                .depth = bool(p39_image.info.props.is_depth),
                .attachment = bool(p39_image.binding.is_target),
                .needs_rebind = bool(p39_image.binding.needs_rebind),
            });
            if (p39_decision.use_general) {
                p39_image.binding.force_general = 1u;
                if (VideoCore::StagingVerbose()) {
                    static std::atomic<u32> p39_reports{0};
                    const u32 p39_seq = p39_reports.fetch_add(1, std::memory_order_relaxed);
                    if (p39_seq < 16 || p39_seq % 256 == 0) {
                        LOG_WARNING(Render_Vulkan,
                            "P39_SAME_IMAGE_LAYOUT general=1 sampled=1 storage=1 "
                            "sameImageId=1 crossImageAliasFix=0 intrashaderFix=0 "
                            "shaderRewrite=0 snapshot=0");
                    }
                }
            }
        }
    }

'''

ACCESS_OLD='''                              vk::AccessFlagBits2::eShaderRead |
                                  (image.info.props.is_depth'''
ACCESS_NEW='''                              vk::AccessFlagBits2::eShaderRead |
                                  // Opt-in: a GENERAL view shared with storage must
                                  // advertise writes, including when descriptors are
                                  // encountered storage-first then sampled-second.
                                  ((BachataP39::Enabled() && image.binding.force_general &&
                                    !image.binding.is_target)
                                       ? vk::AccessFlagBits2::eShaderWrite
                                       : vk::AccessFlagBits2::eNone) |
                                  (image.info.props.is_depth'''

def transform(src):
    out = p38.transform(src)
    rast = out[RASTER]
    rast = once(rast,
        '#include "video_core/renderer_vulkan/p38_interdispatch_barrier.hpp"',
        '#include "video_core/renderer_vulkan/p38_interdispatch_barrier.hpp"\n'
        '#include "video_core/renderer_vulkan/p39_same_image_layout.hpp"',
        'HEADER_INCLUDE')
    rast = once(rast,
        '    // Second pass to re-bind images that were updated after binding',
        SCAN+'    // Second pass to re-bind images that were updated after binding',
        'BIND_TEXTURES_FIRST_SECOND_PASS')
    rast = once(rast,ACCESS_OLD, ACCESS_NEW,'GENERAL_SHADER_WRITE_MASK')
    out[RASTER] = rast
    return out

def run():
    args=argparse.ArgumentParser()
    args.add_argument('--source-root',type=Path,required=True)
    args.add_argument('--out',type=Path,default=Path('p39.diff'))
    args.add_argument('--write',action='store_true')
    args.add_argument('--synthetic-fixture',action='store_true')
    a=args.parse_args()
    if not a.synthetic_fixture:
        def git(*parts):
            return subprocess.run(['git','-C',str(a.source_root),*parts],
                                  check=True,text=True,capture_output=True).stdout.strip()
        if git('rev-parse','HEAD')!=p25.EXPECTED_UPSTREAM:
            raise ValueError('P39_WRONG_UPSTREAM_COMMIT')
        if git('status','--porcelain','--untracked-files=no'):
            raise ValueError('P39_DIRTY_UPSTREAM')
        pins={**p38.p37.p36.p35.p34.p33.p28.IMAGE_SHA_PIN,
              **p38.p37.p36.PIN,
              p38.RASTER_H:p38.EXPECTED_HEADER_SHA}
        for path,digest in pins.items():
            if git('hash-object',path)!=digest:
                raise ValueError('P39_SOURCE_HASH_DRIFT:'+path)
    original={path:(a.source_root/path).read_text() for path in ROOT_FILES}
    updated=transform(original)
    prior={f'src/video_core/renderer_vulkan/{h}':Path(__file__).with_name(h)
           for h in (*p38.p37.p36.p35.p34.p33.p28.p27.HEADERS,
                     *p38.p37.p36.p35.p34.p33.p28.P28_FILES,
                     'p33_bcn_linear_policy.hpp','p34_tiled_bcn_policy.hpp',
                     'p35_image_alias_probe.hpp','p36_resource_intent.hpp',
                     'p38_interdispatch_barrier.hpp','p39_same_image_layout.hpp')}
    prior[p38.p37.HEADER]=Path(__file__).with_name('p37_ir_sequence.hpp')
    for rel,path in prior.items():
        if not path.is_file() or (a.source_root/rel).exists():
            raise ValueError('P39_HEADER_CONFLICT:'+rel)
    diff=''.join(''.join(difflib.unified_diff(original[p].splitlines(True),updated[p].splitlines(True),
          fromfile='a/'+p,tofile='b/'+p)) for p in ROOT_FILES)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(diff)
    if a.write:
        for rel,body in updated.items():
            f=a.source_root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
        for rel,path in prior.items():
            f=a.source_root/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,f)
    print(json.dumps({'phase':'P39_SAME_IMAGE_ID_DESCRIPTOR_LAYOUT',
        'public_revision':p25.EXPECTED_UPSTREAM,
        'feature_off_by_default':True,
        'same_image_id_mixed_layout_path':True,
        'cross_image_guest_overlap_fixed':False,
        'intra_shader_hazard_fixed':False,
        'robust_image_guard_removed':False,
        'minecraft_fixed':False,'outlast_fixed':False,'apk_produced':False,
        'diff_sha256':hashlib.sha256(diff.encode()).hexdigest()},sort_keys=True))
if __name__=='__main__':run()
