#include "p39_same_image_layout.hpp"
#include <cstdio>
#include <cstdlib>
using namespace BachataP39;
int main() {
    unsigned n=0;
    auto expect=[&](bool condition){if(!condition) std::abort();++n;};
    for(unsigned mask=0;mask<128;++mask) for(unsigned enabled=0;enabled<2;++enabled) {
        Evidence e{.same_image_id=bool(mask&1),.sampled=bool(mask&2),
                   .storage=bool(mask&4),.depth=bool(mask&8),
                   .attachment=bool(mask&16),.needs_rebind=bool(mask&32)};
        Decision p=Plan(enabled,e);
        bool exp=enabled&&e.same_image_id&&e.sampled&&e.storage&&!e.depth&&
                 !e.attachment&&!e.needs_rebind;
        expect(p.use_general==exp);
        expect(p.include_shader_write_access==exp);
        expect(!p.resolves_intrashader_hazard);
        expect(!p.permits_distinct_image_alias);
        expect(!p.permits_replacing_robust_guard);
    }
    expect(Plan(true,{true,true,true,false,false,false}).use_general);
    expect(!Plan(false,{true,true,true,false,false,false}).use_general);
    expect(!Plan(true,{false,true,true,false,false,false}).use_general);
    expect(!Plan(true,{true,true,true,true,false,false}).use_general);
    expect(!Plan(true,{true,true,true,false,true,false}).use_general);
    expect(!Plan(true,{true,true,true,false,false,true}).use_general);
    std::printf("P39_SAME_IMAGE_LAYOUT_POLICY_PASS checks=%u\n",n);
}
