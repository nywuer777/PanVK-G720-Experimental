import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import port_renderer_p39 as p39
from test_port_p38 import P38PortTest

class P39Port(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        P38PortTest.setUpClass()
        cls.fixture=P38PortTest.fixture.copy()
        # The P38 fixture intentionally has no real BindTextures body; add
        # only the exact audited signature of this Vulkan code path.
        original=cls.fixture[p39.RASTER]
        anchor='    // Second pass to re-bind images that were updated after binding'
        assert original.count(anchor)==1
        cls.fixture[p39.RASTER]=original.replace(anchor,anchor+"""
    if ((image.binding.force_general || image.binding.is_target) &&
                !image.info.props.is_depth) {
        image.Transit(vk::ImageLayout::eGeneral,
                              vk::AccessFlagBits2::eShaderRead |
                                  (image.info.props.is_depth
                                       ? vk::AccessFlagBits2::eDepthStencilAttachmentWrite
                                       : vk::AccessFlagBits2::eColorAttachmentWrite),{});
    }
""",1)

    def test_real_active_path(self):
        out=p39.transform(self.fixture)[p39.RASTER]
        for token in ('P39_EXACT_IMAGE_ID_SAMPLED_STORAGE','p39_other.first != p39_id',
                      'BindingType::Storage','p39_image.binding.force_general = 1u',
                      'BachataP39::Plan(true','BachataP39::Enabled()',
                      'vk::AccessFlagBits2::eShaderWrite',
                      'crossImageAliasFix=0','intrashaderFix=0'):
            self.assertIn(token,out)
    def test_preserves_earlier_subsystems(self):
        old=p39.p38.transform(self.fixture)
        new=p39.transform(self.fixture)
        for path in new:
            if path!=p39.RASTER:
                self.assertEqual(old[path],new[path])
        self.assertIn('P38_INTERDISPATCH_SHADER_IMAGE_BARRIER',new[p39.RASTER])
        self.assertIn('P37_BASIC_BLOCK_ORDER_DIAG',new[p39.RASTER])
    def test_no_raw_addresses(self):
        s=p39.transform(self.fixture)[p39.RASTER]
        snippet=s[s.index('P39_EXACT_IMAGE_ID_SAMPLED_STORAGE'):s.index('    // Second pass to re-bind')]
        self.assertNotIn('guest_address',snippet)
        self.assertNotIn('0x',snippet)
        self.assertNotIn('VkImage',snippet)
    def test_no_unconditional_activation(self):
        s=p39.transform(self.fixture)[p39.RASTER]
        self.assertIn('if (BachataP39::Enabled()) {',s)
        self.assertIn('!p39_sampled || !p39_storage',s)
        self.assertIn('p39_image.binding.needs_rebind',s)
    def test_missing_access_anchor_fail_closed(self):
        f=self.fixture.copy()
        f[p39.RASTER]=f[p39.RASTER].replace('vk::AccessFlagBits2::eShaderRead |\n                                  (image.info.props.is_depth','vk::AccessFlagBits2::eShaderRead |\n                                     (image.info.props.is_depth')
        with self.assertRaises(ValueError):p39.transform(f)
    def test_duplicate_access_anchor_fail_closed(self):
        f=self.fixture.copy()
        f[p39.RASTER]+=p39.ACCESS_OLD
        with self.assertRaises(ValueError):p39.transform(f)
    def test_missing_second_pass_fail_closed(self):
        f=self.fixture.copy();f[p39.RASTER]=f[p39.RASTER].replace('    // Second pass to re-bind images that were updated after binding','')
        with self.assertRaises(ValueError):p39.transform(f)
    def test_double_patch_rejected(self):
        with self.assertRaises(ValueError):p39.transform(p39.transform(self.fixture))
    def test_pinned_source_guard(self):
        s=Path(p39.__file__).read_text()
        for word in ('P39_WRONG_UPSTREAM_COMMIT','P39_DIRTY_UPSTREAM','P39_SOURCE_HASH_DRIFT',
                     'P39_HEADER_CONFLICT',"'robust_image_guard_removed':False",
                     "'intra_shader_hazard_fixed':False"):
            self.assertIn(word,s)
    def test_dryrun_write_collision(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name,body in self.fixture.items():
                f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
            cmd=[sys.executable,str(Path(p39.__file__)),'--source-root',str(root),
                 '--out',str(root/'p39.diff'),'--synthetic-fixture']
            data=json.loads(subprocess.run(cmd,capture_output=True,text=True,check=True).stdout)
            self.assertTrue(data['feature_off_by_default']);self.assertFalse(data['minecraft_fixed'])
            self.assertFalse((root/p39.HEADER).exists())
            subprocess.run(cmd+['--write'],capture_output=True,text=True,check=True)
            self.assertTrue((root/p39.HEADER).exists())
            self.assertNotEqual(subprocess.run(cmd+['--write'],capture_output=True).returncode,0)

if __name__=='__main__':unittest.main()
