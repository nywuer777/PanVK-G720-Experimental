# Bachata F43DEV V2 — P33, via BCn linear ATIVA no core público

**Status: CANDIDATE SOURCE, NÃO INSTALÁVEL.** Outlast e Minecraft **não estão confirmados corrigidos**. A P23 assinada com SHA-256 `2806f93e9f4346dda5c796462c3d916fb021e2dc942fa2e7366dc78c265c62b6` permanece intacta.

## Novidade concreta sobre P25–P32
- `port_renderer_p33.py` aplica toda a cadeia P25–P28 e, desta vez, modifica `TextureCache::RefreshImage()` (o caminho **ativo** do renderizador), `Image::Image()` (formato real do backing) e `Image` (proveniência).
- Quando a GPU não dá suporte ao formato BC1/BC3 original e o recurso convidado tem **array linear, Color2D, apenas uma camada, amostragem única e mipmaps válidos**, aloca imagem RGBA8 da classe sRGB correta e usa `BachataP27::BuildPlan`, `UploadDecodedToRgba`, que chama `Image::Upload` do core.
- Rejeita memória tiled, volume, aliasing GPU-modificado, conteúdo truncado, stride incompleto, suporte Vulkan ausente ou qualquer incompatibilidade no destino; **não pula assertivas**.
- O pipeline usa **`Scheduler::Finish()`** nessa primeira fase de correção para que a prova P26 seja válida antes da criação da view: custo potencial alto. O upload assíncrono P28 permanece disponível para revisão futura, mas não foi ativado aqui por não atender ainda à semântica de criação de views P25. Não é otimização de FPS.
- **Minecraft:** ainda não há solução da dependência robust-image/atomic/alias. Nenhum marcador do bloqueio foi removido.
- **BCn tiled** do Outlast não foi resolvido neste ciclo; esta implementação só é elegível para recursos lineares. É indispensável inspecionar os logs de jogo para saber se a via linear se aplica à falha original.

## Como verificar
Com o clone público `zenithblue-oss/shadps4-arm64` no commit `be6bc2e9c60799e071dd2fafa6216e8d80ec619c`, árvore limpa:

```bash
python3 port_renderer_p33.py --source-root /caminho/clone --out p33.diff
python3 port_renderer_p33.py --source-root /caminho/clone --out p33.diff --write
```

`--synthetic-fixture` serve **só para testes**. Não assinar nem substituir o APK P23 com um core público sem validação de identidade ABI, dependências, recursos e jogo em dispositivo.

## Critérios de liberação
1. Compilar a revisão pública ARM64/GLIBC no GitHub Actions, auditar erros e hash do ELF.
2. Validar que a execução passa pelo marcador `P33_BCN_LINEAR_ACTIVE` no jogo afetado; sem marcador, a implementação não tem efeito na falha.
3. Integrar o mecanismo tiled via GPU-readable detile + decodificação segura, se necessário.
4. Resolver o shader Minecraft robust-image/atomic alias de fato, antes de alegar fix.
5. Preservar a identidade do host, assinatura, dados e resolução. Não gerar APK com suposições.
